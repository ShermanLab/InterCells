function linind_molecule_locations = linindclusters(molecule_parameters)

% input      :
% output     :
% called by  :
% calling    :
% description:

% tcr_type_number         = tcr_parameters.type_number;
% molecule_global_density      = molecule_parameters.global_density; % global_ ;
molecule_cluster_density     = molecule_parameters.cluster_density;
molecule_density_of_clusters = molecule_parameters.density_of_clusters;

%%% clusters' locations %%%%%%%%%%%%%%%

% number of clusters
N_molecule_clusters             = round(size_x_microns*size_y_microns*molecule_density_of_clusters);
N_molecule_in_cluster           = 110;
molecule_cluster_radius_microns = sqrt(N_molecule_in_cluster/(molecule_cluster_density*pi));
molecule_cluster_radius         = molecule_cluster_radius_microns*1000/a;

molecule_clusters_centers_x  = ceil(rand(N_molecule_clusters,1)*...
    (centers_x_max - centers_x_min) + centers_x_min);
molecule_clusters_centers_y  = ceil(rand(N_molecule_clusters,1)*...
    (centers_y_max - centers_y_min) + centers_y_min);

linind_molecule_locations    = [];

for m = 1:N_molecule_clusters
    x0 = molecule_clusters_centers_x(m);
    y0 = molecule_clusters_centers_y(m);
    linind_points_in_circle = pointsincircle(x0,y0,...
        molecule_cluster_radius,N_molecule_in_cluster,size_x,size_y,rand_array);

    linind_molecule_locations    = [linind_molecule_locations;linind_points_in_circle];
end 
%%%
%%%
A0 = zeros(size(rand_array));
A0(linind_molecule_locations) = 1;
figure(8)
spy(A0)


end




