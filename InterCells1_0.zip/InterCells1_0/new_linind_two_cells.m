function [new_Cell1,new_Cell2] = new_linind_two_cells(simulation_data,parameters)

%{
For every patch there is one energy value that 
is the sum of attraction repulsion (spring) 
and membrane bending enegry.

step 1 - attemp to jump and excluding jumps to already
occupied patches.
step 1 Cell1: id_   linind_       type_   Z_E_Cell1 to 
              id_newlinindattempt_type_newZ_E_Cell1.
step 1 Cell2: id_   linind_       type_   Z_E_Cell2 to 
              id_newlinindattempt_type_newZ_E_Cell2.
newZ: the membrane height, Z, does not change, 
the membrane height at the new location (linind) 
may be different from the height at old location.

step 2 - calculating new energy at the newlininds
step 2 Cell1 - id_newlinindattempt_type_newZ_E_   Cell1 to 
               id_newlinindattempt_type_newZ_newE_Cell1
step 2 Cell2 - id_newlinindattempt_type_newZ_E_   Cell2 to 
               id_newlinindattempt_type_newZ_newE_Cell2

step 3 - in case that more that one molecule attempted to
jump to the same patch, only the one with the highest 
energy gain will remain.
step 3 Cell1 - id_newlinindattempt_type_newZ_newE_Cell1 to 
               id_newlinind_       type_newZ_newE_Cell1
step 3 Cell2 - id_newlinindattempt_type_newZ_newE_Cell2 to 
               id_newlinind       _type_newZ_newE_Cell2

step 4 - Metropolis criterion. The attempt will be accepted
according to Metropolis criterion.

%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id_linind_type_Z_E_Cell1 = simulation_data.Cell1.molecules;
id_linind_type_Z_E_Cell2 = simulation_data.Cell2.molecules;

% Z1 = simulation_data.Cell1.membrane.Z;
% Z2 = simulation_data.Cell2.membrane.Z;
% DZ = Z2 - Z1;

% step 1 - jump and excluding jumps to already occupied 
% patches and updating Z at the newlinindattempts.
%%% Cell1
id_newlinindattempt_type_newZ_E_Cell1 = ...
    newlinindattempt_newZ_Cell1(simulation_data,parameters);
%%% Cell2
id_newlinindattempt_type_newZ_E_Cell2 = ...
    newlinindattempt_newZ_Cell2(simulation_data,parameters);

simulation_data.Cell1.molecules = id_newlinindattempt_type_newZ_E_Cell1;
simulation_data.Cell2.molecules = id_newlinindattempt_type_newZ_E_Cell2;

%%% step 2 - calculating new energy at the newlininds

[id_newlinindattempt_type_newZ_newE_Cell1,...
 id_newlinindattempt_type_newZ_newE_Cell2] = ...
   Emolecules(simulation_data,parameters);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 3 - in case that more that one molecule attempted
% to jump to the % same patch, only the one with the 
% highest energy gain will be accepted.
%%% Cell1
id_singlenewlinindattempt_type_newZ_newE_Cell1 = ...
    rejectmultiple(id_linind_type_Z_E_Cell1,...
    id_newlinindattempt_type_newZ_newE_Cell1);
%%% Cell2 
id_singlenewlinindattempt_type_newZ_newE_Cell2 = ...
    rejectmultiple(id_linind_type_Z_E_Cell2,...
    id_newlinindattempt_type_newZ_newE_Cell2);

%%% metropolis Cell1 
id_newlinind_type_newZ_newE_Cell1 = metropolis(...
    id_linind_type_Z_E_Cell1,...
    id_singlenewlinindattempt_type_newZ_newE_Cell1,parameters);

%%% metropolis Cell2 
id_newlinind_type_newZ_newE_Cell2 = metropolis(...
    id_linind_type_Z_E_Cell2,...
    id_singlenewlinindattempt_type_newZ_newE_Cell2,parameters);

new_Cell1 = id_newlinind_type_newZ_newE_Cell1;
new_Cell2 = id_newlinind_type_newZ_newE_Cell2;

