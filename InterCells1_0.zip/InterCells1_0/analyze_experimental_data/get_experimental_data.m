function get_experimental_cd3_data()

data_folder_path = 'C:\Users\Owner\Documents\Yair\papers to write\paper simulations';
addpath(data_folder_path);

cd3_path   = [data_folder_path,'\cd3'];
polyL_path = [data_folder_path,'\polyL'];

% dir_cd3   = dir(cd3_path);
% dir_polyL = dir(polyL_path);

% dir_cd3_csv   = dir([cd3_path '/*.csv' ]);
% dir_polyL_csv = dir([polyL_path '/*.csv']);
% dir([cd3_path '/*.csv' ])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% catalog_cd3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd3_M1  = {'M1-488c2.csv','M1-568c2.csv','M1-647c2.csv'};
cd3_M2  = {'M2-488c2.csv','M2-568c2.csv','M2-647c2.csv'};
cd3_M3  = {'M3-488c2.csv','M3-568c2.csv','M3-647c2.csv'};
cd3_M4  = {'M4-488c2.csv','M4-568c2.csv','M4-647c2.csv'};
cd3_M5  = {'M5-488c2.csv','M5-568c2.csv','M5-647c2.csv'};
cd3_M6  = {'M6-488c2.csv','M6-568c2.csv','M6-647c2.csv'};
cd3_M7  = {'M7-488c2.csv','M7-568c2.csv','M7-647c2.csv'};
cd3_M8  = {'M8-488c2.csv','M8-568c2.csv','M8-647c2.csv'};
cd3_M9  = {'M9-488c2.csv','M9-568c2.csv','M9-647c2.csv'};
cd3_M10 = {'M10-488c2.csv','M10-568c2.csv','M10-647c2.csv'};
cd3_M11 = {'M11-48801c2.csv','M11-488c2.csv','M11-568c2.csv'}; %'M11-64701c2.csv','M11-647ac2.csv'
cd3_M12 = {'M12-488c2.csv','M12-568c2.csv','M12-647c2.csv'};
cd3_M13 = {'M13-488c2.csv','M13-568c2.csv','M13-647c2.csv'};
cd3_M14 = {'M14-488c2.csv','M14-568c2.csv','M14-647c2.csv'};
cd3_M15 = {'M15-488c2.csv','M15-568c2.csv','M15-647c2.csv'};
cd3_MEASURMENTS = {cd3_M1 ,cd3_M2 ,cd3_M3 ,cd3_M4 ,cd3_M5,...
                   cd3_M6 ,cd3_M7 ,cd3_M8 ,cd3_M9 ,cd3_M10,...
                   cd3_M11,cd3_M12,cd3_M13,cd3_M14,cd3_M15};    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% catalog_polyL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
polyL_M1  = {'M1-488c2.csv','M1-568c2.csv','M1-647c2.csv'};
polyL_M2  = {'M2-488c2.csv','M2-568c2.csv','M2-647c2.csv'};
polyL_M3  = {'M3-488c2.csv','M3-568c2.csv','M3-647c2.csv'};
polyL_M4  = {'M4-488c2.csv','M4-568c2.csv','M4-647c2.csv'};
polyL_M5  = {'M5-488c2.csv','M5-568c2.csv','M5-647c2.csv'};
polyL_M6  = {'M6-488c2.csv','M6-568c2.csv','M6-647c2.csv'};
polyL_M7  = {'M7-488c2.csv','M7-568c2.csv','M7-647c2.csv'};
polyL_M8  = {'M8-488c2.csv','M8-568c2.csv','M8-647c2.csv'};
polyL_M9  = {'M9-488c2.csv','M9-568c2.csv','M9-647c2.csv'};
polyL_M10 = {'M10-488c2.csv','M10-568c2.csv','M10-647c2.csv'};
polyL_M11 = {'M11-48801c2.csv','M11-488c2.csv','M11-568c2.csv'}; %'M11-64701c2.csv','M11-647ac2.csv'
polyL_M12 = {'M12-488c2.csv','M12-568c2.csv','M12-647c2.csv'};
polyL_M13 = {'M13-488c2.csv','M13-568c2.csv','M13-647c2.csv'};
polyL_M14 = {'M14-488c2.csv','M14-568c2.csv','M14-647c2.csv'};
polyL_M15 = {'M15-488c2.csv','M15-568c2.csv','M15-647c2.csv'};
polyL_MEASURMENTS = {polyL_M1 ,polyL_M2 ,polyL_M3 ,polyL_M4 ,polyL_M5,...
                     polyL_M6 ,polyL_M7 ,polyL_M8 ,polyL_M9 ,polyL_M10,...
                     polyL_M11,polyL_M12,polyL_M13,polyL_M14,polyL_M15}; 
%%% colheaders %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% colheaders1 = {id,frame,x(nm),y(nm),sigma(nm),intensity(photon),...
%     offset(photon),bkgstd(photon),chi2,uncertainty,(nm),detections};
data_path   = cd3_path; %polyL_path; % 
MEASURMENTS = polyL_MEASURMENTS; % cd3_MEASURMENTS; %
crop_number = 1;
m = 5;
save_results = 0;
for measurement_number = m:m;
    
    M_names = MEASURMENTS(measurement_number);
    
    M_tcr   = importdata([data_path,'\',M_names{1}{1}]);
    M_lfa   = importdata([data_path,'\',M_names{1}{2}]);
    M_cd45  = importdata([data_path,'\',M_names{1}{3}]);
    
    tcr_data  = M_tcr.data;
    lfa_data  = M_lfa.data;
    cd45_data = M_cd45.data;
    
    tcr_x  = tcr_data(:,3);
    tcr_y  = tcr_data(:,4);
    lfa_x  = lfa_data(:,3);
    lfa_y  = lfa_data(:,4);
    cd45_x = cd45_data(:,3);
    cd45_y = cd45_data(:,4);
    
    %%% plotting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ms = 1;
    whitebg('white')
    figure(4)
    plot(tcr_x ,tcr_y ,'.','Color',[0 0.7 0],'MarkerSize',ms)
    hold on
    plot(lfa_x, lfa_y ,'.','Color',[0 0 1],'MarkerSize',ms)
    plot(cd45_x,cd45_y,'.','Color',[1 0 0],'MarkerSize',ms)
    
    axis equal; axis tight;
    title(['CD3, M = ',int2str(measurement_number)],'FontSize',16)
    xlabel('X(nm)','FontSize',14); 
    ylabel('Y(nm)','FontSize',14);
    
%     pause
    %%% cropping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     button = 1;
    
%     [px,py] = ginput(2);
    [px,py,button] = ginput(2);
    min_x = min(px(1),px(2));
    max_x = max(px(1),px(2));
    min_y = min(py(1),py(2));
    max_y = max(py(1),py(2));
    
    plot([min_x max_x max_x min_x min_x],[min_y min_y max_y max_y min_y],'k-')
    hold off
    
    tcr_xy  = [tcr_x,tcr_y];
    lfa_xy  = [lfa_x,lfa_y];
    cd45_xy = [cd45_x,cd45_y];
    
    cropped_tcr  = tcr_xy(tcr_xy(:,1) > min_x & tcr_xy(:,1) < max_x &...
                          tcr_xy(:,2) > min_y & tcr_xy(:,2) < max_y,:);
    cropped_lfa  = lfa_xy(lfa_xy(:,1) > min_x & lfa_xy(:,1) < max_x &...
                          lfa_xy(:,2) > min_y & lfa_xy(:,2) < max_y,:);
    cropped_cd45 = cd45_xy(cd45_xy(:,1) > min_x & cd45_xy(:,1) < max_x &...
                           cd45_xy(:,2) > min_y & cd45_xy(:,2) < max_y,:);
    
    pixel_tcr  = unique(ceil(cropped_tcr/10),'rows');                  
    pixel_lfa  = unique(ceil(cropped_lfa/10),'rows'); 
    pixel_cd45 = unique(ceil(cropped_cd45/10),'rows');
    %%% proteins in frame
    
    %%%
    pixel_tcr_x  = pixel_tcr(:,1)  - floor(min_x/10);
    pixel_tcr_y  = pixel_tcr(:,2)  - floor(min_y/10);
    pixel_lfa_x  = pixel_lfa(:,1)  - floor(min_x/10);
    pixel_lfa_y  = pixel_lfa(:,2)  - floor(min_y/10);
    pixel_cd45_x = pixel_cd45(:,1) - floor(min_x/10);
    pixel_cd45_y = pixel_cd45(:,2) - floor(min_y/10);
    
    size_x = max([pixel_tcr_x;pixel_lfa_x;pixel_cd45_x]);
    size_y = max([pixel_tcr_y;pixel_lfa_y;pixel_cd45_y]);
        
    linind_pixel_tcr  = sub2ind([size_x,size_y],pixel_tcr_x,pixel_tcr_y);
    linind_pixel_lfa  = sub2ind([size_x,size_y],pixel_lfa_x,pixel_lfa_y);
    linind_pixel_cd45 = sub2ind([size_x,size_y],pixel_cd45_x,pixel_cd45_y);
    
    linind_cropped_data = cell(1,5);
    linind_cropped_data{1,1} = linind_pixel_tcr;
    linind_cropped_data{1,2} = linind_pixel_lfa;
    linind_cropped_data{1,3} = linind_pixel_cd45;
    linind_cropped_data{1,4} = size_x;
    linind_cropped_data{1,5} = size_y;
    
%     pixel_tcr_x  = pixel_tcr(:,1)  - floor(min_x/10);
%     pixel_tcr_y  = pixel_tcr(:,2)  - floor(min_y/10);
%     pixel_lfa_x  = pixel_lfa(:,1)  - floor(min_x/10);
%     pixel_lfa_y  = pixel_lfa(:,2)  - floor(min_y/10);
%     pixel_cd45_x = pixel_cd45(:,1) - floor(min_x/10);
%     pixel_cd45_y = pixel_cd45(:,2) - floor(min_y/10);
    
    %%% plotting cropped %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    ms = 1;
    figure(5)
    clf
    subplot(1,2,1)
    plot(cropped_tcr(:,1) ,cropped_tcr(:,2) ,'.','Color',[0 0.7 0],'MarkerSize',ms)
    hold on
    plot(cropped_lfa(:,1) ,cropped_lfa(:,2) ,'.','Color',[0 0 1],'MarkerSize',ms)
    plot(cropped_cd45(:,1),cropped_cd45(:,2),'.','Color',[1 0 0],'MarkerSize',ms)
    axis equal; axis tight;
    title(['CD3, M = ',int2str(measurement_number),', Cropped'],'FontSize',16)
    xlabel('X(pixels)','FontSize',14); 
    ylabel('Y(pixels)','FontSize',14);
    
    subplot(1,2,2)
    plot(pixel_tcr_x ,pixel_tcr_y ,'.','Color',[0 0.7 0],'MarkerSize',ms)
    hold on
    plot(pixel_lfa_x ,pixel_lfa_y ,'.','Color',[0 0 1],'MarkerSize',ms)
    plot(pixel_cd45_x,pixel_cd45_y,'.','Color',[1 0 0],'MarkerSize',ms)
    axis equal; axis tight;
    title(['CD3, M = ',int2str(measurement_number),', Cropped, pixeled'],'FontSize',16)
    xlabel('X(pixels)','FontSize',14); 
    ylabel('Y(pixels)','FontSize',14);
    
    probe_density = 1;
    if probe_density
        probe_proteins_density
        
        
    end % probe_density
    
    %% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plot_black = 0;
    for pb = 1:1
    if plot_black
        
%         size_x = max([pixel_tcr_x;pixel_lfa_x;pixel_cd45_x]);
%         size_y = max([pixel_tcr_y;pixel_lfa_y;pixel_cd45_y]);
%         
%         linind_tcr  = sub2ind([size_x,size_y],pixel_tcr_x,pixel_tcr_y);
%         linind_lfa  = sub2ind([size_x,size_y],pixel_lfa_x,pixel_lfa_y);
%         linind_cd45 = sub2ind([size_x,size_y],pixel_cd45_x,pixel_cd45_y);
        
        red_layer   = zeros(size_x,size_y);
        green_layer = zeros(size_x,size_y);
        blue_layer  = zeros(size_x,size_y);
        
        red_layer(linind_pixel_cd45)  = 1;
        green_layer(linind_pixel_tcr) = 1;
        blue_layer(linind_pixel_lfa)  = 1;
        
        sigma = 25;
        hsize = 7*sigma;
        h = fspecial('gaussian', hsize, sigma);
        maxh = max(max(h));
        
        red_layer_g   =  imfilter(red_layer,h,'replicate');
        green_layer_g =  imfilter(green_layer,h,'replicate');
        blue_layer_g  =  imfilter(blue_layer,h,'replicate');
        
%         rgb_image = cat(3,red_layer_g,green_layer_g,blue_layer_g);
        rgb_image = cat(3,(red_layer_g'./max(max(red_layer_g))),...
                        green_layer_g'./max(max(green_layer_g)),...
                         blue_layer_g'./max(max(blue_layer_g)));
        
%         whitebg('black')
        figure(6)
        clf
        image(rgb_image)
        hold on
        ms = 5;
        plot(pixel_tcr_x ,pixel_tcr_y ,'.','Color',[0 0.7 0],'MarkerSize',ms)
        plot(pixel_lfa_x ,pixel_lfa_y ,'.','Color',[0 0 1],'MarkerSize',ms)
        plot(pixel_cd45_x,pixel_cd45_y,'.','Color',[1 0 0],'MarkerSize',ms)
%         plot(tcr_x ,tcr_y ,'.','Color',[0 0.7 0],'MarkerSize',ms)
%         plot(lfa_x ,lfa_y ,'.','Color',[0 0 1],'MarkerSize',ms)
%         plot(cd45_x,cd45_y,'.','Color',[1 0 0],'MarkerSize',ms)
        axis equal; axis tight;
        title(['CD3, M = ',int2str(measurement_number),', Cropped'],'FontSize',16)
        xlabel('X(pixels)','FontSize',14); 
        ylabel('Y(pixels)','FontSize',14);
    end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% cropped data name
    if save_results
        linind_cropped_data_name = ['linind_cropped_data_M',int2str(measurement_number),'_C',int2str(crop_number)];
        %%% save crop
%         save(linind_cropped_data_name,'linind_cropped_data')
    end
end


