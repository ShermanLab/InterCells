% analyse_experimental_data
% file_name = 'linind_cropped_data_cd3_M1_C1';
file_name = 'linind_cropped_data_polyL_M2_C1';
file_contents = load(file_name);
linind_cropped_data = file_contents.linind_cropped_data;

max_R = 100; %50;
EXPERIMENTAL_DILATIONS = experimental_data2dilations(linind_cropped_data,max_R);
EXPERIMENTAL_EROSIONS2 = experimental_data2erosions(linind_cropped_data,max_R);
EXPERIMENTAL_DENSITIES = experimental_data2densities(linind_cropped_data,...
                         EXPERIMENTAL_DILATIONS,EXPERIMENTAL_EROSIONS2);
plot_experimental_densities(EXPERIMENTAL_DENSITIES,max_R);













