% probe_proteins_density
% function probe_proteins_density()
probe_x = [];
probe_y = [];
n_button = 0;
button = 1;
hold on
while button == 1
    n_button = n_button + 1; 
	[xi,yi,button] = ginput(1);
%     probe_x = [probe_x;x1];
%     probe_y = [probe_y;y1];
    plot(xi,yi,'ko')
    probe_x(n_button) = xi;
    probe_y(n_button) = yi;
end
probe_x(n_button+1) = probe_x(1);
probe_y(n_button+1) = probe_y(1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% disp('Left mouse button picks points')
% disp('Right mouse button picks last point')
% button = 1;
% hold on
% while button == 1
%     [xi,yi,button] = ginput(1);
%     plot(xi,yi,'ko')
%     n = n+1;
%     px(n) =  xi;
%     py(n) =  yi;
% end
% polygon_x  = [px, px(1)];
% polygon_y  = [py, py(1)];
% polygon_points = [polygon_x',polygon_y'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    min_probe_x = min(probe_x);
    max_probe_x = max(probe_x);
    min_probe_y = min(probe_y);
    max_probe_y = max(probe_y);
%     min_probe_x = min(probe_x(1),probe_x(2));
%     max_probe_x = max(probe_x(1),probe_x(2));
%     min_probe_y = min(probe_y(1),probe_y(2));
%     max_probe_y = max(probe_y(1),probe_y(2));
    
plot([min_probe_x max_probe_x max_probe_x min_probe_x min_probe_x],[min_probe_y min_probe_y max_probe_y max_probe_y min_probe_y],'k-')
hold off
    
pixel_tcr_xy  = [pixel_tcr_x,pixel_tcr_y];
pixel_lfa_xy  = [lfa_x,lfa_y];
pixel_cd45_xy = [cd45_x,cd45_y];

cropped_probe_tcr  =   pixel_tcr_xy(pixel_tcr_xy(:,1) > min_probe_x & pixel_tcr_xy(:,1)  < max_probe_x &...
                        pixel_tcr_xy(:,2) > min_probe_y & pixel_tcr_xy(:,2)  < max_probe_y,:);
cropped_probe_lfa  =   pixel_lfa_xy(pixel_lfa_xy(:,1) > min_probe_x & pixel_lfa_xy(:,1)  < max_probe_x &...
                        pixel_lfa_xy(:,2) > min_probe_y & pixel_lfa_xy(:,2)  < max_probe_y,:);
cropped_probe_cd45 = pixel_cd45_xy(pixel_cd45_xy(:,1) > min_probe_x & pixel_cd45_xy(:,1) < max_probe_x &...
                       pixel_cd45_xy(:,2) > min_probe_y & pixel_cd45_xy(:,2) < max_probe_y,:);
                       
N_cropped_probe_tcr  = length(cropped_probe_tcr);
N_cropped_probe_lfa  = length(cropped_probe_lfa);
N_cropped_probe_cd45 = length(cropped_probe_cd45);

probe_size_x = max_probe_x - min_probe_x;
probe_size_y = max_probe_y - min_probe_y;
 
local_density_tcr  = N_cropped_probe_tcr /(probe_size_x*probe_size_y); 
local_density_lfa  = N_cropped_probe_lfa /(probe_size_x*probe_size_y);
local_density_cd45 = N_cropped_probe_cd45/(probe_size_x*probe_size_y); 
 
disp(['tcr density = ' , num2str(local_density_tcr)]) 
disp(['lfa density = ' , num2str(local_density_lfa)]) 
disp(['cd45 density = ', num2str(local_density_cd45)])  
 
figure(14)
clf
plot(cropped_probe_tcr(:,1),cropped_probe_tcr(:,2),'g.')
hold on
plot(cropped_probe_lfa(:,1),cropped_probe_lfa(:,2),'b.')
plot(cropped_probe_cd45(:,1),cropped_probe_cd45(:,2),'r.')
hold off
axis([min_probe_x max_probe_x min_probe_y max_probe_y])
axis equal; axis tight
text(min_probe_x+2,min_probe_y+12,['tcr density = ' , num2str(local_density_tcr)]) 
text(min_probe_x+2,min_probe_y+7 ,['lfa density = ' , num2str(local_density_lfa)]) 
text(min_probe_x+2,min_probe_y+2 ,['cd45 density = ', num2str(local_density_cd45)])  












   