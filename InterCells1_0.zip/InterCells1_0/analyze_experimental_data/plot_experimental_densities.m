function plot_experimental_densities(EXPERIMENTAL_DENSITIES,max_R)

DENSITIES22 = EXPERIMENTAL_DENSITIES{1};
DENSITIES23 = EXPERIMENTAL_DENSITIES{2};
DENSITIES24 = EXPERIMENTAL_DENSITIES{3};


max_x = max(max_R);
R = 0:max_R;
max_y = 0.1;



densities22 = DENSITIES22;
densities23 = DENSITIES23;
densities24 = DENSITIES24;

smdensities22 = smooth([densities22{:}],5);
smdensities23 = smooth([densities23{:}],5);
smdensities24 = smooth([densities24{:}],5);

maxdensities22 = find(smdensities22 == max(smdensities22));
maxdensities23 = find(smdensities23 == max(smdensities23));
maxdensities24 = find(smdensities24 == max(smdensities24));
%%%%%%%%%%%%%%%%%%%%%%%%%
%     [xi,yi] = polyxpoly(x1,y1,x2,y2)
hm22 = max(smdensities23)/2;
hm23 = max(smdensities23)/2;
hm24 = max(smdensities24)/2;

[x22i,~] = polyxpoly([0 max_x],[hm22 hm22],R,smdensities23);
[x23i,~] = polyxpoly([0 max_x],[hm23 hm23],R,smdensities23);
[x24i,~] = polyxpoly([0 max_x],[hm24 hm24],R,smdensities24);

fwhm22 = max(x22i) - min(x22i);
fwhm23 = max(x23i) - min(x23i);
fwhm24 = max(x24i) - min(x24i);
%%%%%%%%%%%%%%%%%%%%%%%%%

stddensities22 = std(find(smdensities22 > mean(smdensities22)));
stddensities23 = std(find(smdensities23 > mean(smdensities23)));
stddensities24 = std(find(smdensities24 > mean(smdensities24)));


figure(8)
clf
%%%
plot(R,[densities22{:}],'g-')
hold on
%     plot(R,[densities23{:}],'b-')
%     plot(R,[densities24{:}],'r-')

bar(R,[densities23{:}],'b')
bar(R,[densities24{:}],'r')
alpha(0.5)

plot(R,smdensities22,'g-','LineWidth',2)
plot(R,smdensities23,'b-','LineWidth',2)
plot(R,smdensities24,'r-','LineWidth',2)
hold off
axis([0 max_x 0 max_y])
%     legend('a(r)')
xlabel('Disk radius (pixels)')
ylabel('Density')
% title(['t = ',int2str(t-1)])




















