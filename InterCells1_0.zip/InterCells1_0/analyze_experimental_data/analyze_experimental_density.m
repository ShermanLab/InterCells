% analyze_experimental_density
clear
clc

experimental_DENSITY       = load('polyL_DENSITIES'); %'cd3_DENSITIES'
experimental_TOTAL_DENSITY = load('polyL_TOTAL_DENSITIES'); % 'cd3_TOTAL_DENSITIES'

DENSITIES_data = experimental_DENSITY.DENSITIES;
DENSITIES_tcr  = DENSITIES_data{1};
DENSITIES_lfa  = DENSITIES_data{2};
DENSITIES_cd45 = DENSITIES_data{3};

TOTAL_DENSITIES_data = experimental_TOTAL_DENSITY.TOTAL_DENSITIES;
TOTAL_DENSITIES_tcr  = TOTAL_DENSITIES_data{1};
TOTAL_DENSITIES_lfa  = TOTAL_DENSITIES_data{2};
TOTAL_DENSITIES_cd45 = TOTAL_DENSITIES_data{3};

N_data = size(DENSITIES_tcr,1);
R = 0:size(DENSITIES_tcr,2);
%%% 
mean_DENSITIES_tcr  = mean(DENSITIES_tcr,1);
mean_DENSITIES_lfa  = mean(DENSITIES_lfa,1);
mean_DENSITIES_cd45 = mean(DENSITIES_cd45,1);

std_DENSITIES_tcr  = std(DENSITIES_tcr)/sqrt(N_data);
std_DENSITIES_lfa  = std(DENSITIES_lfa)/sqrt(N_data);
std_DENSITIES_cd45 = std(DENSITIES_cd45)/sqrt(N_data);

%%% 
TOTAL_DENSITIES_tcr_mat  = repmat(TOTAL_DENSITIES_tcr ,1,size(DENSITIES_tcr,2));
TOTAL_DENSITIES_lfa_mat  = repmat(TOTAL_DENSITIES_lfa ,1,size(DENSITIES_lfa,2));
TOTAL_DENSITIES_cd45_mat = repmat(TOTAL_DENSITIES_cd45,1,size(DENSITIES_cd45,2));

normDENSITIES_tcr        = DENSITIES_tcr./TOTAL_DENSITIES_tcr_mat;
normDENSITIES_lfa        = DENSITIES_lfa./TOTAL_DENSITIES_lfa_mat;
normDENSITIES_cd45       = DENSITIES_cd45./TOTAL_DENSITIES_cd45_mat;

mean_normDENSITIES_tcr   = mean(normDENSITIES_tcr,1);
mean_normDENSITIES_lfa   = mean(normDENSITIES_lfa,1);
mean_normDENSITIES_cd45  = mean(normDENSITIES_cd45,1);

std_normDENSITIES_tcr    = std(normDENSITIES_tcr)/sqrt(N_data);
std_normDENSITIES_lfa    = std(normDENSITIES_lfa)/sqrt(N_data);
std_normDENSITIES_cd45   = std(normDENSITIES_cd45)/sqrt(N_data);

%%
figure(14);
subplot(1,2,1)
errorbar(mean_DENSITIES_tcr ,std_DENSITIES_tcr ,'g')
hold on
errorbar(mean_DENSITIES_lfa ,std_DENSITIES_lfa ,'b')
errorbar(mean_DENSITIES_cd45,std_DENSITIES_cd45,'r')
hold off
axis([0 max(R) 0 0.1])

subplot(1,2,2)
errorbar(mean_normDENSITIES_tcr ,std_normDENSITIES_tcr ,'g')
hold on
errorbar(mean_normDENSITIES_lfa ,std_normDENSITIES_lfa ,'b')
errorbar(mean_normDENSITIES_cd45,std_normDENSITIES_cd45,'r')
hold off
axis([0 max(R) 0 5])



