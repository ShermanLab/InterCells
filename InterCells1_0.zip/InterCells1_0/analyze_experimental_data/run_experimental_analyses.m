% run_experimental_analyses
%%% getting experimental data
get_experimental_data;
ALL_DENSITIES   = experimental_density(filenames_type);
LOCAL_DENSITIES = proteins_local_densities(filenames_type);
















