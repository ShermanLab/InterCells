function LOCAL_DENSITIES = proteins_local_densities(filenames_type) %  
% clc
% clear
%%% cd3_filenames
linind_cd3_filenames = {'linind_cropped_data_cd3_M1_C1'
    'linind_cropped_data_cd3_M2_C1'
    'linind_cropped_data_cd3_M3_C1'
    'linind_cropped_data_cd3_M4_C1'
    'linind_cropped_data_cd3_M5_C1'
    'linind_cropped_data_cd3_M6_C1'
    'linind_cropped_data_cd3_M7_C1'
    'linind_cropped_data_cd3_M8_C1'
    'linind_cropped_data_cd3_M9_C1'
    'linind_cropped_data_cd3_M10_C1'
    'linind_cropped_data_cd3_M12_C1'
    'linind_cropped_data_cd3_M13_C1'
    'linind_cropped_data_cd3_M14_C1'
    'linind_cropped_data_cd3_M15_C1'};

linind_polyL_filenames = {'linind_cropped_data_polyL_M1_C1'
    'linind_cropped_data_polyL_M2_C1'
    'linind_cropped_data_polyL_M3_C1'
    'linind_cropped_data_polyL_M3_C2'
    'linind_cropped_data_polyL_M4_C1'
    'linind_cropped_data_polyL_M6_C1'
    'linind_cropped_data_polyL_M6_C2'
    'linind_cropped_data_polyL_M7_C1'
    'linind_cropped_data_polyL_M8_C1'
    'linind_cropped_data_polyL_M8_C2'
    'linind_cropped_data_polyL_M9_C1'
    'linind_cropped_data_polyL_M9_C2'
    'linind_cropped_data_polyL_M10_C1'
    'linind_cropped_data_polyL_M10_C2'
    'linind_cropped_data_polyL_M12_C1'
    'linind_cropped_data_polyL_M13_C1'
    'linind_cropped_data_polyL_M13_C2'
    'linind_cropped_data_polyL_M14_C1'};

% linind_filenames = linind_cd3_filenames; % linind_polyL_filenames; %
linind_filenames = eval(['linind_',filenames_type,'_filenames']); % linind_polyL_filenames; %

save_name  = [filenames_type,'_LOCAL_DENSITIES']; % 'polyL_DENSITIES'; %

N_files        = length(linind_filenames);
max_R          = 20;

LOCAL_DENSITIES      = cell(3,1);
LOCAL_DENSITIES_tcr  = zeros(N_files,max_R+1);
LOCAL_DENSITIES_lfa  = zeros(N_files,max_R+1);
LOCAL_DENSITIES_cd45 = zeros(N_files,max_R+1);

TOTAL_PERIMETERS      = cell(3,1);
TOTAL_PERIMETERS_tcr  = zeros(N_files,1);
TOTAL_PERIMETERS_lfa  = zeros(N_files,1);
TOTAL_PERIMETERS_cd45 = zeros(N_files,1);

plot1 = 1;
for m = 1:1%N_files;
    
    file_name           = linind_filenames{m};
    file_contents       = load(file_name);
    linind_cropped_data = file_contents.linind_cropped_data;

    %%% read data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    linind_tcr  = linind_cropped_data{1};
    linind_lfa  = linind_cropped_data{2};
    linind_cd45 = linind_cropped_data{3};
    size_x      = linind_cropped_data{4};
    size_y      = linind_cropped_data{5};
    
    N_tcr  = length(linind_tcr);
    N_lfa  = length(linind_lfa);
    N_cd45 = length(linind_cd45);
    
       
    if 1
    %%% setting linind points    
    A_tcr  = zeros(size_x,size_y);
    A_lfa  = zeros(size_x,size_y);
    A_cd45 = zeros(size_x,size_y);
    
    A_tcr (linind_tcr)  = 1;
    A_lfa (linind_lfa)  = 1;
    A_cd45(linind_cd45) = 1;
    %%%
    
    tcr_local_densities  = zeros(max_R+1,1);
    lfa_local_densities  = zeros(max_R+1,1);
    cd45_local_densities = zeros(max_R+1,1);
    
    tcr_total_perimeters  = zeros(max_R+1,1);
    lfa_total_perimeters  = zeros(max_R+1,1);
    cd45_total_perimeters = zeros(max_R+1,1);
    
    colormap jet
    for n = 0:max_R
        if n == 0
%             tcr_in1  = sum(sum(A_tcr));
%             lfa_in1  = 0;
%             cd45_in1 = 0;
%             dilation_area1 = sum(sum(A_tcr));
            
            tcr_local_density  = 1;
            lfa_local_density  = 1;
            cd45_local_density = 1;
            
            tcr_local_densities(n+1)  = tcr_local_density;
            lfa_local_densities(n+1)  = lfa_local_density;
            cd45_local_densities(n+1) = cd45_local_density;
        else
            
            r = n;
            disp(r)
            h = (fspecial('disk',r)); % h = ceil(fspecial('disk',r));
            
            %%% placing disks(r) on tcr points
            dilated_A_tcr  = ceil(conv2(A_tcr,h,'same'));
            dilated_A_lfa  = ceil(conv2(A_lfa,h,'same'));
            dilated_A_cd45 = ceil(conv2(A_cd45,h,'same'));
            
            dilation_area_tcr  = sum(sum(dilated_A_tcr));
            dilation_area_lfa  = sum(sum(dilated_A_lfa));
            dilation_area_cd45 = sum(sum(dilated_A_cd45));
            
            
            perim_dilated_A_tcr  = bwmorph(dilated_A_tcr,'remove');
            perim_dilated_A_lfa  = bwmorph(dilated_A_lfa,'remove');
            perim_dilated_A_cd45 = bwmorph(dilated_A_cd45,'remove');
            
            perim_area_tcr  = sum(sum(perim_dilated_A_tcr));
            perim_area_lfa  = sum(sum(perim_dilated_A_lfa));
            perim_area_cd45 = sum(sum(perim_dilated_A_cd45));
            
            tcr_total_perimeters(n+1)  = perim_area_tcr;
            lfa_total_perimeters(n+1)  = perim_area_lfa;
            cd45_total_perimeters(n+1) = perim_area_cd45;
            %%% density calculations
            tcr_local_density  = N_tcr /dilation_area_tcr;
            lfa_local_density  = N_lfa /dilation_area_lfa;
            cd45_local_density = N_cd45/dilation_area_cd45;
            
            tcr_local_densities(n+1)  = tcr_local_density;
            lfa_local_densities(n+1)  = lfa_local_density;
            cd45_local_densities(n+1) = cd45_local_density;
            %         disp(tcr_in_density);
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%% plotting
            if plot1
            %%% for plotting
                figure(17)
                all_A = zeros(size_x,size_y);
                all_A(linind_tcr)     = 1;
                all_A(linind_lfa)     = 3;
                all_A(linind_cd45)    = 5;
                
                all_A = all_A + dilated_A_tcr + dilated_A_lfa + dilated_A_cd45;
                imagesc(all_A)
                axis equal; axis tight
%                 pause%(0.1)
            end % 
        end
    end
    
    end %0
    clc
    
%     LOCAL_DENSITIES_tcr(m,:)  = tcr_local_densities;
%     LOCAL_DENSITIES_lfa(m,:)  = lfa_local_densities;
%     LOCAL_DENSITIES_cd45(m,:) = cd45_local_densities;
%     
%     TOTAL_PERIMETERS_tcr(m)   = tcr_total_perimeters;
%     TOTAL_PERIMETERS_lfa(m)   = lfa_total_perimeters;
%     TOTAL_PERIMETERS_cd45(m)  = cd45_total_perimeters;
    
    %%
    if 1
    figure(13)
    subplot(1,2,1)
    plot(0:max_R,tcr_local_densities ,'g-')
    hold on
    plot(0:max_R,lfa_local_densities ,'b-')
    plot(0:max_R,cd45_local_densities,'r-')
    hold off
%     ylim([0 0.1])
    
    subplot(1,2,2)
    plot(0:max_R,tcr_total_perimeters ,'g-')
    hold on
    plot(0:max_R,lfa_total_perimeters ,'b-')
    plot(0:max_R,cd45_total_perimeters,'r-')
    hold off
%     ylim([0 5])
    end 
end
% LOCAL_DENSITIES{1} = LOCAL_DENSITIES_tcr;
% LOCAL_DENSITIES{2} = LOCAL_DENSITIES_lfa;
% LOCAL_DENSITIES{3} = LOCAL_DENSITIES_cd45;
% 
% TOTAL_PERIMETERS{1}  = TOTAL_PERIMETERS_tcr;
% TOTAL_PERIMETERS{2}  = TOTAL_PERIMETERS_lfa;
% TOTAL_PERIMETERS{3}  = TOTAL_PERIMETERS_cd45;










