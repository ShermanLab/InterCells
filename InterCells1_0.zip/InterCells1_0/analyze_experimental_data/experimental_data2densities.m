function EXPERIMENTAL_DENSITIES = experimental_data2densities(linind_cropped_data,EXPERIMENTAL_DILATIONS,EXPERIMENTAL_EROSIONS2)

linind_tcr  = linind_cropped_data{1};
linind_lfa  = linind_cropped_data{2};
linind_cd45 = linind_cropped_data{3};
size_x      = linind_cropped_data{4};
size_y      = linind_cropped_data{5};

EXPERIMENTAL_DILATION2 = EXPERIMENTAL_DILATIONS{1};
EXPERIMENTAL_EROSION2  = EXPERIMENTAL_EROSIONS2;

EXPERIMENTAL_DENSITIES  = cell(3,1);

dilations2 = EXPERIMENTAL_DILATION2; % EXPERIMENTAL_DILATION2{1}
erosions2  = EXPERIMENTAL_EROSION2; % EXPERIMENTAL_EROSION2{1}

density22 = cell(length(dilations2),1);
density23 = cell(length(dilations2),1);
density24 = cell(length(dilations2),1);

for r_index = 1:length(dilations2)
%     disp(r_index)
    dilation2_r = dilations2{r_index};
    erosion2_r  = erosions2{r_index};
    
    if r_index == 1
        dilation2_r = erosion2_r;
    else
        dilation2_r = union(dilation2_r,erosion2_r);
    end
    
    area_dilation2_r  = length(dilation2_r);
    %%%%%%%%%%%%%%%%%%%%%
    plot1 = 0;
    if plot1
        A = zeros(size_x,size_y);
        A(dilation2_r)  = 1;
        A(linind_tcr) = 2;
        figure(10)
        imagesc(A)
        pause%(0.1)
    end
    
    %%%%%%%%%%%%%%%%%%%%%
    n_2r2 = length(intersect(dilation2_r,linind_tcr));
    n_2r3 = length(intersect(dilation2_r,linind_lfa));
    n_2r4 = length(intersect(dilation2_r,linind_cd45));
    
    density22{r_index} = n_2r2/area_dilation2_r;
    density23{r_index} = n_2r3/area_dilation2_r;
    density24{r_index} = n_2r4/area_dilation2_r;
end

EXPERIMENTAL_DENSITIES{1} = density22;
EXPERIMENTAL_DENSITIES{2} = density23;
EXPERIMENTAL_DENSITIES{3} = density24;












