function EXPERIMENTAL_DILATIONS = experimental_data2dilations(linind_cropped_data,max_R)

linind_tcr  = linind_cropped_data{1};
linind_lfa  = linind_cropped_data{2};
linind_cd45 = linind_cropped_data{3};
size_x      = linind_cropped_data{4};
size_y      = linind_cropped_data{5};


dilations2  = experimental_dilations(linind_tcr,size_x,size_y,max_R);
dilations3  = experimental_dilations(linind_lfa,size_x,size_y,max_R);
dilations4  = experimental_dilations(linind_cd45,size_x,size_y,max_R);

EXPERIMENTAL_DILATIONS    = cell(3,1);
EXPERIMENTAL_DILATIONS{1} = dilations2;
EXPERIMENTAL_DILATIONS{2} = dilations3;
EXPERIMENTAL_DILATIONS{3} = dilations4;





















