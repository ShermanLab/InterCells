% interface_simulation

% input      : none
% output     :
% called by  : none
% calling    :
% description:

clear %all
close all
clc
%%% initializing parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_parameters = defaultparameters();
library            = make_library(default_parameters);
parameters         = default_parameters;

parameters = moltypenames2moltypenumbers(parameters);
% assigns 'type#' instead of molecule name.
% from here the molecules.'name' in 'parameters' do not have specific names.
% the original names are kept in 'library'.

%%% choose cells %%%%%%%%%%%%%%%%%%%%%%
Cell1_name = 'Tcell'; 
Cell2_name = 'Coverslip';
parameters = cellsnames2cellsnumbers(parameters,Cell1_name,Cell2_name);

%%% initial simulation data / temp %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initial_Tcell_data     = test_Tcell_data(default_parameters);
initial_Coverslip_data = test_Coverslip_data(default_parameters);

%%% set initial_simulation_data %%%%%%%
simulation_data.Cell1 = initial_Tcell_data;
simulation_data.Cell2 = initial_Coverslip_data;
simulation_data.iter  = 0;

simulation_data.Cell1.linind_initial_locations = [];
simulation_data.Cell1.initial_locations_array  = initial_Tcell_data.locations_array; 
%zeros(size(simulation_data.Cell1.membrane.Z));

simulation_data.Cell2.linind_initial_locations = [];
simulation_data.Cell2.initial_locations_array  = initial_Coverslip_data.locations_array; 
%zeros(size(simulation_data.Cell1.membrane.Z));

initial_simulation_data = simulation_data;
%%% plot initial_simulation_data %%%%%%
plot_simulation_data(initial_simulation_data,parameters);
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% start gui %%%%%%%%%%%%%%%%%%%%%%%%%
use_gui = 0; 
if use_gui
    out_parameters = ui_main2(parameters,simulation_data);
    parameters     = out_parameters;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% % fix
% plot data (?)
plot_data    = 1;
% save results automaticaly (?)
save_results = 0;
% number of runs
runs         = parameters.global.runs;
N_iterations = parameters.global.simulation_time/parameters.global.iteration_time;

RESULTS_OF_RUNS = cell(runs,1);

%%%%%%%%%%%%%%%%%

% for run1 = 1:runs
%% % 
results_of_run = cell(parameters.global.simulation_time+1,1); %% why 101
iter = 0;
% simulation_data.iter = iter;
% time in seconds
t = ceil(iter/parameters.global.save_rate); % sec
% close all figures 
% close all 


current_linind_experimental_data = [];
%% 
for run1 = 1:runs
    results_of_run{t+1} = simulation_data;
    tic % measures run time
    
    for iter = 1:N_iterations
        t = ceil(iter/parameters.global.save_rate); % sec
        simulation_data.iter = iter;
        simulation_data = updatesimulationdata(simulation_data,...
            current_linind_experimental_data,parameters);
        
        %%% every 'save_rate' iterations %%%%%%%%%%%%%%%%%%
        if mod(iter,parameters.global.save_rate) == 0
            disp(t)
            if plot_data
                plot_simulation_data(simulation_data,parameters)
            end
            results_of_run{t+1} = simulation_data;
        end
    end % iter
    toc
    RESULTS_OF_RUNS(run1) = {results_of_run};
end % runs

%%
%%% set_results_folder
% results_folder = ['C:\Users\Owner\Documents\MATLAB\',...
%     'Weikl_Lipowsky\small_patches\Interface_simulation3\Results'];
% now_str   = datestr(now,'yyyymmddHHMMSS');
% save_name = ['results_',now_str];
% mkdir([results_folder,'\',save_name]);
% % dt = datestr(now, 'yyyy mm dd HH MM SS');

% for run1 = 1:runs

%%% generate_cells %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [parameters,simulation_data] = generate_Cells(parameters);
% [parameters,simulation_data] = generate_Cell1(parameters,'Tcell');






