% run_simulation

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% % fix
% plot data (?)
plot_data    = 1;
% save results automaticaly (?)
save_results = 0;
% number of runs
runs         = parameters.global.runs;
N_iterations = parameters.global.simulation_time/parameters.global.iteration_time;

RESULTS_OF_RUNS = cell(runs,1);

%%%%%%%%%%%%%%%%%

% for run1 = 1:runs
%% % 
results_of_run = cell(parameters.global.simulation_time+1,1); %% why 101
iter = 0;
% simulation_data.iter = iter;
% time in seconds
t = ceil(iter/parameters.global.save_rate); % sec
% close all figures 
% close all 


current_linind_experimental_data = [];
%% 
for run1 = 1:runs
    results_of_run{t+1} = simulation_data;
    tic % measures run time
    
    for iter = 1:N_iterations
        t = ceil(iter/parameters.global.save_rate); % sec
        simulation_data.iter = iter;
        simulation_data = updatesimulationdata(simulation_data,...
            current_linind_experimental_data,parameters);
        
        %%% every 'save_rate' iterations %%%%%%%%%%%%%%%%%%
        if mod(iter,parameters.global.save_rate) == 0
            disp(t)
            if plot_data
                plot_simulation_data(simulation_data,parameters,plotting_options)
            end
            results_of_run{t+1} = simulation_data;
        end
    end % iter
    toc
    RESULTS_OF_RUNS(run1) = {results_of_run};
end % runs

%%
%%% set_results_folder
% results_folder = ['C:\Users\Owner\Documents\MATLAB\',...
%     'Weikl_Lipowsky\small_patches\Interface_simulation3\Results'];
% now_str   = datestr(now,'yyyymmddHHMMSS');
% save_name = ['results_',now_str];
% mkdir([results_folder,'\',save_name]);
% % dt = datestr(now, 'yyyy mm dd HH MM SS');

% for run1 = 1:runs

%%% generate_cells %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [parameters,simulation_data] = generate_Cells(parameters);
% [parameters,simulation_data] = generate_Cell1(parameters,'Tcell');












