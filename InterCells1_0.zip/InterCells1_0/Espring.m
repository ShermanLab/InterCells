function E_spring = Espring(simulation_data,parameters)


















end