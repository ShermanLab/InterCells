function simulation_data = localization_arrays2simulation_data(...
    initial_locations_array1,initial_locations_array2,parameters)


simulation_data.Cell1.initial_locations_array = initial_locations_array1;
simulation_data.Cell2.initial_locations_array = initial_locations_array2;

Z1 = parameters.Cells.Cell1.membrane.Z0;

%%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
linind1_1 = find(initial_locations_array1 == 1);
linind1_2 = find(initial_locations_array1 == 2);
linind1_3 = find(initial_locations_array1 == 3);

typem1_1  =  1*ones(size(linind1_1));
Zm1_1     = Z1*ones(size(linind1_1));
Em1_1     = zeros(size(linind1_1));

typem1_2  =  2*ones(size(linind1_2));
Zm1_2     = Z1*ones(size(linind1_2));
Em1_2     = zeros(size(linind1_2));

typem1_3  =  3*ones(size(linind1_3));
Zm1_3     = Z1*ones(size(linind1_3));
Em1_3     = zeros(size(linind1_3));

%%% type1
id_linind_type_Z_E_Cell1_1(:,2) = linind1_1;
id_linind_type_Z_E_Cell1_1(:,3) = typem1_1;
id_linind_type_Z_E_Cell1_1(:,4) = Zm1_1;
id_linind_type_Z_E_Cell1_1(:,5) = Em1_1;

%%% type2
id_linind_type_Z_E_Cell1_2(:,2) = linind1_2;
id_linind_type_Z_E_Cell1_2(:,3) = typem1_2;
id_linind_type_Z_E_Cell1_2(:,4) = Zm1_2;
id_linind_type_Z_E_Cell1_2(:,5) = Em1_2;

%%% type3
id_linind_type_Z_E_Cell1_3(:,2) = linind1_3;
id_linind_type_Z_E_Cell1_3(:,3) = typem1_3;
id_linind_type_Z_E_Cell1_3(:,4) = Zm1_3;
id_linind_type_Z_E_Cell1_3(:,5) = Em1_3;


id_linind_type_Z_E_Cell1        = ...
    [id_linind_type_Z_E_Cell1_1;
     id_linind_type_Z_E_Cell1_2;
     id_linind_type_Z_E_Cell1_3];


id_linind_type_Z_E_Cell1(:,1) = [1:size(id_linind_type_Z_E_Cell1),1];

%%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
linind2_1 = find(initial_locations_array2 == 1);
linind2_2 = find(initial_locations_array2 == 2);
linind2_3 = find(initial_locations_array2 == 3);

typem2_1  =  1*ones(size(linind2_1));
Zm2_1     = Z2*ones(size(linind2_1));
Em2_1     = zeros(size(linind2_1));

typem2_2  =  2*ones(size(linind2_2));
Zm2_2     = Z2*ones(size(linind2_2));
Em2_2     = zeros(size(linind2_2));

typem2_3  =  3*ones(size(linind2_3));
Zm2_3     = Z2*ones(size(linind2_3));
Em2_3     = zeros(size(linind2_3));

%%% type1
id_linind_type_Z_E_Cell2_1(:,2) = linind2_1;
id_linind_type_Z_E_Cell2_1(:,3) = typem2_1;
id_linind_type_Z_E_Cell2_1(:,4) = Zm2_1;
id_linind_type_Z_E_Cell2_1(:,5) = Em2_1;

%%% type2
id_linind_type_Z_E_Cell2_2(:,2) = linind2_2;
id_linind_type_Z_E_Cell2_2(:,3) = typem2_2;
id_linind_type_Z_E_Cell2_2(:,4) = Zm2_2;
id_linind_type_Z_E_Cell2_2(:,5) = Em2_2;

%%% type3
id_linind_type_Z_E_Cell2_3(:,2) = linind2_3;
id_linind_type_Z_E_Cell2_3(:,3) = typem2_3;
id_linind_type_Z_E_Cell2_3(:,4) = Zm2_3;
id_linind_type_Z_E_Cell2_3(:,5) = Em2_3;


id_linind_type_Z_E_Cell2        = ...
    [id_linind_type_Z_E_Cell2_1;
     id_linind_type_Z_E_Cell2_2;
     id_linind_type_Z_E_Cell2_3];


id_linind_type_Z_E_Cell2(:,1) = [1:size(id_linind_type_Z_E_Cell2),1];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

simulation_data.Cell1.molecules = id_linind_type_Z_E_Cell1;
simulation_data.Cell2.molecules = id_linind_type_Z_E_Cell2;

end