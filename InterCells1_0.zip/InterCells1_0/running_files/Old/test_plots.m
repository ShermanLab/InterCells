% test_plots

figure(3)
subplot(2,2,1)
imagesc(initial_locations_array1)
axis equal
axis tight

subplot(2,2,2)
imagesc(initial_locations_array2)
axis equal
axis tight

subplot(2,2,3)
imagesc(simulation_data.Cell1.initial_locations_array)
axis equal
axis tight

subplot(2,2,4)
imagesc(simulation_data.Cell2.initial_locations_array)
axis equal
axis tight