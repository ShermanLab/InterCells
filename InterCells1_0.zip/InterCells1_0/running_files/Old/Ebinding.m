function E_binding = Ebinding()


















end