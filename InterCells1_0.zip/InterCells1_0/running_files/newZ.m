function [new_Z1,new_Z2] = newZ(simulation_data,parameters)

id_linind_type_Z_E_Cell1 = simulation_data.Cell1.molecules;
id_linind_type_Z_E_Cell2 = simulation_data.Cell2.molecules;

Z1 = simulation_data.Cell1.membrane.Z;
Z2 = simulation_data.Cell2.membrane.Z;

K1 = simulation_data.Cell1.membrane.K;
K2 = simulation_data.Cell2.membrane.K;
% iter

%%% gravity %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% gravity_force/pixel
use_gravity = parameters.global.use_gravity;
if use_gravity
    e_gravity = parameters.global.e_gravity;
else
    e_gravity = 0;
end
% e_gravity_array = e_gravity*ones(size(L)); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sigma_dz1 = parameters.Cells.Cell1.membrane.dz;
sigma_dz2 = parameters.Cells.Cell2.membrane.dz;
%%% calculating elastic energy of the membrane L %%%%%%%%%%
%%% oldE is the total energy at every patch %%%%%%%%%%%%%%%
oldE_membrane1 = Emembrane(Z1,K1,parameters); 
oldE1          = oldE_membrane1; % 

oldE_membrane2 = Emembrane(Z2,K2,parameters); 
oldE2          = oldE_membrane2; % 

linind_Cell1         = id_linind_type_Z_E_Cell1(:,2);
oldE_molecules_Cell1 = id_linind_type_Z_E_Cell1(:,5);
oldE1(linind_Cell1)  = oldE_membrane1(linind_Cell1) + oldE_molecules_Cell1; % problem?

linind_Cell2         = id_linind_type_Z_E_Cell2(:,2);
oldE_molecules_Cell2 = id_linind_type_Z_E_Cell2(:,5);
oldE1(linind_Cell2)   = oldE_membrane2(linind_Cell2) + oldE_molecules_Cell2; % problem?

%%% generating new Z attempt %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rand_dZ1 = sigma_dz1*randn(size(Z1)) - 0.0;
Zn1      = abs(Z1 + rand_dZ1);

rand_dZ2 = sigma_dz2*randn(size(Z2)) - 0.0;
Zn2      = abs(Z2 + rand_dZ2);

%%% Z2 is the height of the membrane at the proteins locations
newZ1 = Zn1(linind_Cell1); 
newZ2 = Zn2(linind_Cell2);

%%% initializing 'id_linind_type_newZ_E_TOP' to be 'id_linind_type_Z_E_TOP'; 
id_linind_type_newZ_E_Cell1 = id_linind_type_Z_E_Cell1;
id_linind_type_newZ_E_Cell2 = id_linind_type_Z_E_Cell2;

%%% assigning the new attempted Z2 %%%%%%%%%%%%%%%%%%%%%%%% 
id_linind_type_newZ_E_Cell1(:,4) = newZ1; 
id_linind_type_newZ_E_Cell2(:,4) = newZ2; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% calculating the new attempted elastic energy %%%%%%%%%%
newE_membrane1 = Emembrane(Zn1,K1,parameters);
newE_membrane2 = Emembrane(Zn2,K2,parameters);

%%% calculating the new proteins energy with newZ %%%%%%%%%
simulation_data.Cell1.molecules = id_linind_type_newZ_E_Cell1;
simulation_data.Cell2.molecules = id_linind_type_newZ_E_Cell2;

[id_linind_type_newZ_newE_Cell1,id_linind_type_newZ_newE_Cell2] = ...
    Emolecules(simulation_data,parameters);
%%%
newE1               = newE_membrane1;
newE1_molecules     = id_linind_type_newZ_newE_Cell1(:,5);
newE1(linind_Cell1) = newE_membrane1(linind_Cell1) + newE1_molecules; 
delta_E1            = newE1 - oldE1 + e_gravity; % + 0.05*rand_dL; %e_gravity;

newE2               = newE_membrane2;
newE2_molecules     = id_linind_type_newZ_newE_Cell2(:,5);
newE2(linind_Cell2) = newE_membrane2(linind_Cell2) + newE2_molecules; 
delta_E2            = newE2 - oldE2 + e_gravity; % + 0.05*rand_dL; %e_gravity;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% accepting/rejecing the dLs according to Metropolis criterion
logical_accepted_dZ1 = logical(rand(size(Z1)) <= exp(-delta_E1));
dZ1                  = rand_dZ1.*logical_accepted_dZ1; 
new_Z1               = abs(Z1 + dZ1);

logical_accepted_dZ2 = logical(rand(size(Z2)) <= exp(-delta_E2));
dZ2                  = rand_dZ2.*logical_accepted_dZ2; 
new_Z2               = abs(Z2 + dZ2);

end
