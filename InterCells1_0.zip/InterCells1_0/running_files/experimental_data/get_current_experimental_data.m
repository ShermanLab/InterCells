function current_linind_experimental_data = get_current_experimental_data(experimental_data,iter)

experimental_frame = ceil((iter+1)/250); 
rect_x = experimental_data.rect_x;
rect_y = experimental_data.rect_y;
%%% reading tcrs coordinates %%%%%%
TCR_XY  = experimental_data.TCR_XY_all{experimental_frame};
linind_TCR = sub2ind([rect_x,rect_y],TCR_XY(:,1),TCR_XY(:,2));
%%% updating L at TCR locations %%%
if isempty(linind_TCR);
    disp('linind_T is empty')
end
current_linind_experimental_data = linind_TCR;




