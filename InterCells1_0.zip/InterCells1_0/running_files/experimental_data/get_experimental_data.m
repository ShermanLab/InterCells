function [experimental_data] = get_experimental_data(parameters)

experiment_ligand_type = parameters.experiment_ligand_type;
ROI_number = parameters.ROI_number;
%%% imports the experimental data and gives the 'print name' for plotting
if strcmp(experiment_ligand_type,'alpha_CD3')
    all_experiment_data = importdata('aCD3.mat');
%     print_experiment_ligand_type = 'alpha CD3';
elseif strcmp(experiment_ligand_type,'alpha_CD45')
    all_experiment_data = importdata('aCD45.mat');
%     print_experiment_ligand_type = 'alpha CD45';
end

%%% this is all the data of all the ROIs or cells:
all_data_488            = all_experiment_data.all_areas_488;
all_data_647            = all_experiment_data.all_areas_647;
all_data_starting_frame = all_experiment_data.all_areas_starting_frame;

%%% get_experiment_data of ROI_number %%%%%%%%%%%%%%%%%%%%%
all_data488_ROI = all_data_488{ROI_number};
all_data647_ROI = all_data_647{ROI_number};

%%% creating ROI data - getcelldata %%%%%%%%%%%%%%%%%%%%%%%
[TCR_XY_all,CD45_XY_all,N_TCR_all,N_CD45_all,rect_x,rect_y] = ...
    getcelldata(all_data488_ROI,all_data647_ROI,...
    all_data_starting_frame,ROI_number);

experimental_data.TCR_XY_all  = TCR_XY_all;
experimental_data.CD45_XY_all = CD45_XY_all;
experimental_data.N_TCR_all   = N_TCR_all;
experimental_data.N_CD45_all  = N_CD45_all;
experimental_data.rect_x      = rect_x;
experimental_data.rect_y      = rect_y;






