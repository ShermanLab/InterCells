function simulation_data = updatesimulationdata(simulation_data,current_linind_experimental_data,parameters)

% input      : simulation_data,
%              current_linind_experimental_data,
%              parameters.
% output     : simulation_data.
% called by  : interface_simulation3.
% calling    : Emembrane,
% description:

Z1 = simulation_data.Cell1.membrane.Z;
Z2 = simulation_data.Cell2.membrane.Z;
DZ = Z1 - Z2;

K1 = simulation_data.Cell1.membrane.K;
K2 = simulation_data.Cell2.membrane.K;
K  = (K1.*K2)./(K1 + K2);

D1 = simulation_data.Cell1.membrane.D;
D2 = simulation_data.Cell2.membrane.D;

iter   = simulation_data.iter;
%%% update linind
%%%
[id_linind_type_Z_E_Cell1,id_linind_type_Z_E_Cell2] = ...
    new_linind_two_cells(simulation_data,parameters);
%%%


%%% update DZ
[Z1,Z2] = newZ(simulation_data,parameters); 
DZ = Z1 - Z2;
%%%{

%%% molecules locations %%%%%%%%%%%%%%%
idm1      = id_linind_type_Z_E_Cell1(:,1);
idm2      = id_linind_type_Z_E_Cell2(:,1);

typem1    = id_linind_type_Z_E_Cell1(:,3);
typem2    = id_linind_type_Z_E_Cell2(:,3);

idm1_1    = idm1(typem1 == 1);
idm1_2    = idm1(typem1 == 2);
idm1_3    = idm1(typem1 == 3);

idm2_1    = idm2(typem2 == 1);
idm2_2    = idm2(typem2 == 2);
idm2_3    = idm2(typem2 == 3);

linindm1  = id_linind_type_Z_E_Cell1(:,2);
linindm2  = id_linind_type_Z_E_Cell2(:,2);

linindm1_1 = linindm1(idm1_1);
linindm1_2 = linindm1(idm1_2);
linindm1_3 = linindm1(idm1_3);

linindm2_1 = linindm2(idm2_1);
linindm2_2 = linindm2(idm2_2);
linindm2_3 = linindm2(idm2_3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if parameters.Cells.Cell1.molecules.type1.force_z
    Z1(linindm1_1)   = parameters.Cells.Cell1.molecules.type1.vertical_size;
end
if parameters.Cells.Cell1.molecules.type2.force_z
    Z1(linindm1_2)   = parameters.Cells.Cell1.molecules.type2.vertical_size;
end
if parameters.Cells.Cell1.molecules.type3.force_z
    Z1(linindm1_3)   = parameters.Cells.Cell1.molecules.type3.vertical_size;
end
% if iter < parameters.global.stick_time/parameters.global.iteration_time     
%     if parameters.Cell1.type2.force_z == 1
%         Z1(linindm1_2)   = parameters.Cells.Cell1.type2.vertical_size;
%     end
%     if parameters.Cell1.type3.force_z == 1
%         Z1(linind1_3)   = parameters.Cells.Cell1.type3.vertical_size;
%     end
% end

%%%
id_linind_type_Z_E_Cell1(idm1_1,4) = Z1(linindm1_1);
id_linind_type_Z_E_Cell1(idm1_2,4) = Z1(linindm1_2);
id_linind_type_Z_E_Cell1(idm1_3,4) = Z1(linindm1_3);

id_linind_type_Z_E_Cell2(idm2_1,4) = Z2(linindm2_1);
id_linind_type_Z_E_Cell2(idm2_2,4) = Z2(linindm2_2);
id_linind_type_Z_E_Cell2(idm2_3,4) = Z2(linindm2_3);


E_membrane1 = Emembrane(Z1,K1,parameters);
E_membrane2 = Emembrane(Z2,K2,parameters);

simulation_data.Cell1.membrane.E = E_membrane1;
simulation_data.Cell2.membrane.E = E_membrane2;

simulation_data.Cell1.membrane.Z = Z1;
simulation_data.Cell2.membrane.Z = Z2;

simulation_data.Cell1.membrane.K = K1;
simulation_data.Cell2.membrane.K = K2;

simulation_data.Cell1.molecules = id_linind_type_Z_E_Cell1;
simulation_data.Cell2.molecules = id_linind_type_Z_E_Cell2;

end