function id_newlinind_type_newZ_newE = metropolis(...
    id_linind_type_Z_E,id_newlinindattempt_type_newZ_newE,...
    parameters)

%%% getting the hopping id's %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id1 = id_linind_type_Z_E(:,1);
id1_linind1 = id_linind_type_Z_E(:,[1,2]);
id2_linind2 = id_newlinindattempt_type_newZ_newE(:,[1,2]);
id_no_hop   = find(ismember(id1_linind1,id2_linind2,'rows'));
id_hop      = setdiff(id1,id_no_hop);

%%% accepting/rejecting the hops according to Metropolis criterion:
%%% genrating rand values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
rand_values = rand(size(id_hop)); % rand values at the size the hopping proteins 
%%% calculating delta_E %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_E3 = id_newlinindattempt_type_newZ_newE(:,5) - id_linind_type_Z_E(:,5); %delta_E is negative if energy is gained 
%%% one step metropolis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
logical_accepted = exp(-delta_E3(id_hop)) > rand_values;

%%% two step metropolis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% two_step_metropolis = 0;
if parameters.global.metropolis_steps == 2
    delta_E31 = -id_linind_type_Z_E(:,5);
    delta_E32 = id_newlinindattempt_type_newZ_newE(:,5);

    logical_accepted1 = exp(-delta_E31(id_hop)) > rand_values; % accepted: exp_delta_E31 >= 1
    logical_accepted2 = exp(-delta_E32(id_hop   )) > rand_values; % accepted: exp_delta_E32 >= 1
    logical_accepted = logical_accepted1 & logical_accepted2;
end
% barrier_metropolis = 0;
% if barrier_metropolis
%     delta_E_barrier = -id_linind_type_Z_E_T_cell(:,5);
% 
%     logical_accepted1 = exp(-delta_E3(id_hop))        > rand_values; % accepted: exp_delta_E31 >= 1
%     logical_accepted2 = exp(-delta_E_barrier(id_hop)) > rand_values; % accepted: exp_delta_E32 >= 1
%     logical_accepted  = logical_accepted1 & logical_accepted2;
% end
%%%
id_accepted = id_hop(logical_accepted);
% id_accepted = id_hop2(exp(-delta_E3(id_hop2)) > rand_values); % accepted: exp_delta_E3 >= 1
id_no_hop3 = setdiff(id1,id_accepted);
id_newlinindattempt_type_newZ_newE(id_no_hop3,:) = id_linind_type_Z_E(id_no_hop3,:);
id_newlinind_type_newZ_newE = id_newlinindattempt_type_newZ_newE;

end













