function id_newlinindattempt_type_newZ_E = newlinindattempt_newZ_Cell1(simulation_data,parameters)

% gets the all the data and the T cell data. It attempts to 
% change the proteins and the ligands locations. 
% The new locations are accepted according
% the Metropolis criterion and other confinements.

size_x          = parameters.global.array_size_x;
size_y          = parameters.global.array_size_y;
a               = parameters.global.pixel_size;
iteration_time  = parameters.global.iteration_time;

diffusion1_1    = parameters.Cells.Cell1.molecules.type1.diffusion_constant;
diffusion1_2    = parameters.Cells.Cell1.molecules.type2.diffusion_constant;
diffusion1_3    = parameters.Cells.Cell1.molecules.type3.diffusion_constant;

sigma_pixels1_1 = sqrt(4*diffusion1_1*iteration_time)*1000/a;
sigma_pixels1_2 = sqrt(4*diffusion1_2*iteration_time)*1000/a;
sigma_pixels1_3 = sqrt(4*diffusion1_3*iteration_time)*1000/a;

%%% diffusivity of membrane
id_linind_type_Z_E_Cell1 = simulation_data.Cell1.molecules;
Z1 = simulation_data.Cell1.membrane.Z;
D1 = simulation_data.Cell1.membrane.D;

N_molecules_Cell1  = size(id_linind_type_Z_E_Cell1,1);
[x0_Cell1,y0_Cell1] = ind2sub([size_x,size_y],id_linind_type_Z_E_Cell1(:,2));

%%% id TOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
idm1_1 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 1),1);
idm1_2 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 2),1);
idm1_3 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 3),1);

%%% setting descrete random jumps %%%%%%%%%%%%%%%%%%%%%%%%%
randn_numbers_Cell1 = randn(N_molecules_Cell1,1);  
diffusions_Cell1    = zeros(N_molecules_Cell1,1);

%%% diffusions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
diffusions_Cell1(idm1_1) = sigma_pixels1_1;
diffusions_Cell1(idm1_2) = sigma_pixels1_2;
diffusions_Cell1(idm1_3) = sigma_pixels1_3;

%%% local_diffusions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
linind_Cell1            = id_linind_type_Z_E_Cell1(:,2);
D1_linind_Cell1         = D1(linind_Cell1);
local_diffusions_Cell1  = diffusions_Cell1.*D1_linind_Cell1;

%%% getting new coordinates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hop_r_Cell1         = local_diffusions_Cell1.*randn_numbers_Cell1;
hop_theta_Cell1     = pi*rand(N_molecules_Cell1,1); 
[dx_Cell1,dy_Cell1] = pol2cart(hop_theta_Cell1,hop_r_Cell1);
dx_Cell1            = fix(dx_Cell1);
dy_Cell1            = fix(dy_Cell1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x1_Cell1 = ceil(mod(x0_Cell1 + dx_Cell1 + size_x, size_x + 0.1)); 
y1_Cell1 = ceil(mod(y0_Cell1 + dy_Cell1 + size_y, size_y + 0.1)); 
newlinindattempt = sub2ind([size_x,size_y],x1_Cell1,y1_Cell1);

%%% looking for ilegal hopping due to patch that is already 
% occupied by finding common lininds
oldlinind = id_linind_type_Z_E_Cell1(:,2);
id_common_oldlinind_newlinind_Cell1 = ...
    find(ismember(newlinindattempt,oldlinind));

%%% finding no hops %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id_no_hop1_Cell1 = id_common_oldlinind_newlinind_Cell1;

%%% initalizing id_newlinindattempt_type_newZ_E_T_cell %%%%
id_newlinindattempt_type_newZ_E = ...
    id_linind_type_Z_E_Cell1;

%%% assigning the newlinindattempts %%%%%%%%%%%%%%%%%%%%%%%
id_newlinindattempt_type_newZ_E(:,2) = ...
    newlinindattempt;

%%% assigning the no hops to the newlinindattempts %%%%%%%%
id_newlinindattempt_type_newZ_E(id_no_hop1_Cell1,2) = ...
    id_linind_type_Z_E_Cell1(id_no_hop1_Cell1,2);

%%% updating the newlininds %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
newlinindattempt_with_no_hops = ...
    id_newlinindattempt_type_newZ_E(:,2);

%%% assigning newZ to the newlininds %%%%%%%%%%%%%%%%%%%%%%
id_newlinindattempt_type_newZ_E(:,4) = ...
    Z1(newlinindattempt_with_no_hops);





