function id_singlenewlinindattempt_type_newZ_newE = ...
    rejectmultiple(id_linind_type_Z_E,...
    id_newlinindattempt_type_newZ_newE)

% input      : 
% output     :
% called by  :
% calling    :
% description:


%%% looking for multiple hopping to the same patch by finding
%%% common lininds
%%% getting all the lininds of the new attempted locations
linind2            = id_newlinindattempt_type_newZ_newE(:,2);

%%% getting the unique values of the lininds 
unique_linind2     = unique(linind2);

%%% getting how many times lininds occuring 
repetitions        = histc(linind2,unique_linind2);

%%% finding which lininds occure more than once 
unique_linind2_gt1 = unique_linind2(repetitions > 1);

%%% rejecting the hops where less energy is gained 
%%% finding the id of the multiple linind2 
id_multiple_linind2       = find(ismember(linind2,unique_linind2_gt1)); 

%%% finding the linind that are the sources of linind2 %%%% ???
source_of_linind2         = id_linind_type_Z_E(id_multiple_linind2,2); 

%%% taking all multiple linind2s %%%%%%%%%%%%%%%%%%%%%%%%%%
all_multiple_linind2      = linind2(id_multiple_linind2); 

%%% Energy_of_source_of_linind2 %%%%%%%%%%%%%%%%%%%%%%%%%%%
E_of_source_of_linind2    = id_linind_type_Z_E(id_multiple_linind2,5); 

%%% Energy_of_all_multiple_linind2 %%%%%%%%%%%%%%%%%%%%%%%%
E_of_all_multiple_linind2 = id_newlinindattempt_type_newZ_newE(id_multiple_linind2,5); 

%%% delta_E is negative if energy is gained %%%%%%%%%%%%%%%
delta_E = E_of_all_multiple_linind2 - E_of_source_of_linind2; 

%%% putting togehther id_linind_linind2_delta_E for sorting by energy
%%% making a four column array of [id, linind, linind2, delta_E]
id_linind_linind2_delta_E = [id_multiple_linind2,...
    source_of_linind2, all_multiple_linind2,delta_E];

%%% sorting by energy %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id_linind_linind2_sort_delta_E = sortrows(id_linind_linind2_delta_E,4); 

%%% sorting by multiple linind2 %%%%%%%%%%%%%%%%%%%%%%%%%%%
id_linind_sort_linind2_sort_delta_E = sortrows(id_linind_linind2_sort_delta_E,3); 

%%% getting the unique lininds with lowest energy %%%%%%%%%
[~, ia1, ~] = unique(id_linind_sort_linind2_sort_delta_E(:,3),'first');

% linind_hopping = source_of_linind2(ia1); 
%%%% finding the sources of those who hop %%%%%%%%%%%%%%%%%
id_hopping     = id_linind_sort_linind2_sort_delta_E(ia1,1); 

%%% finding the id's that do not hop %%%%%%%%%%%%%%%%%%%%%%
id_non_hopping = setdiff(id_multiple_linind2,id_hopping);

%%% initializing id_singleconfinednewlinindattempt_type_newZ_newE
id_singlenewlinindattempt_type_newZ_newE = ...
    id_newlinindattempt_type_newZ_newE;
%%% assigning the non hop id's back to the original state %
id_singlenewlinindattempt_type_newZ_newE(id_non_hopping,:) = ...
    id_linind_type_Z_E(id_non_hopping,:);

%%% getting the original, all ordered id's %%%%%%%%%%%%%%%%
id1         = id_linind_type_Z_E(:,1);

%%% getting the [id,linind] of the old cell %%%%%%%%%%%%%%%
id1_linind1 = id_linind_type_Z_E(:,[1,2]);

%%% getting the [id,linind] of the new cell %%%%%%%%%%%%%%%
id2_linind2 = id_singlenewlinindattempt_type_newZ_newE(:,[1,2]);

%%% looking for id's [id,linind] that does not change %%%%%
id_no_hop = find(ismember(id1_linind1,id2_linind2,'rows'));

%%% getting the hopping id's %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id_hop    = setdiff(id1,id_no_hop);

id_singlenewlinindattempt_type_newZ_newE(id_hop,:)...
    = id_newlinindattempt_type_newZ_newE(id_hop,:);

id_singlenewlinindattempt_type_newZ_newE(id_no_hop,:)...
    = id_linind_type_Z_E(id_no_hop,:);












