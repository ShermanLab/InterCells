function id_newlinindattempt_type_newZ_E = newlinindattempt_newZ_Cell2(simulation_data,parameters)

% gets the all the data and the T cell data. It attempts to 
% change the proteins and the ligands locations. 
% The new locations are accepted according
% the Metropolis criterion and other confinements.

size_x         = parameters.global.array_size_x;
size_y         = parameters.global.array_size_y;
a              = parameters.global.pixel_size;
iteration_time = parameters.global.iteration_time;

diffusion2_1   = parameters.Cells.Cell2.molecules.type1.diffusion_constant;
diffusion2_2   = parameters.Cells.Cell2.molecules.type2.diffusion_constant;
diffusion2_3   = parameters.Cells.Cell2.molecules.type3.diffusion_constant;

sigma_pixels2_1 = sqrt(4*diffusion2_1*iteration_time)*1000/a;
sigma_pixels2_2 = sqrt(4*diffusion2_2*iteration_time)*1000/a;
sigma_pixels2_3 = sqrt(4*diffusion2_3*iteration_time)*1000/a;

%%% diffusivity of membrane
id_linind_type_Z_E_Cell2 = simulation_data.Cell2.molecules;
D2 = simulation_data.Cell2.membrane.D;
Z2 = simulation_data.Cell2.membrane.Z;


N_molecules_Cell2  = size(id_linind_type_Z_E_Cell2,1);
[x0_TOP,y0_TOP] = ind2sub([size_x,size_y],id_linind_type_Z_E_Cell2(:,2));

%%% id TOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id1 = id_linind_type_Z_E_Cell2((id_linind_type_Z_E_Cell2(:,3) == 1),1);
id2 = id_linind_type_Z_E_Cell2((id_linind_type_Z_E_Cell2(:,3) == 2),1);
id3 = id_linind_type_Z_E_Cell2((id_linind_type_Z_E_Cell2(:,3) == 3),1);

%%% setting descrete random jumps %%%%%%%%%%%%%%%%%%%%%%%%%
randn_numbers_Cell2 = randn(N_molecules_Cell2,1);  
diffusions_Cell2    = zeros(N_molecules_Cell2,1);

%%% diffusions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
diffusions_Cell2(id1) = sigma_pixels2_1;
diffusions_Cell2(id2) = sigma_pixels2_2;
diffusions_Cell2(id3) = sigma_pixels2_3;

%%% local_diffusions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
linind_Cell2            = id_linind_type_Z_E_Cell2(:,2);
D1_linind_Cell2         = D2(linind_Cell2);
local_diffusions_Cell2  = diffusions_Cell2.*D1_linind_Cell2;

%%% getting new coordinates %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hop_r_Cell2       = local_diffusions_Cell2.*randn_numbers_Cell2;
hop_theta_Cell2   = pi*rand(N_molecules_Cell2,1); 
[dx_Cell2,dy_Cell2] = pol2cart(hop_theta_Cell2,hop_r_Cell2);
dx_Cell2          = fix(dx_Cell2);
dy_Cell2          = fix(dy_Cell2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x1_Cell2 = ceil(mod(x0_TOP + dx_Cell2 + size_x, size_x + 0.1)); 
y1_Cell2 = ceil(mod(y0_TOP + dy_Cell2 + size_y, size_y + 0.1)); 
newlinindattempt = sub2ind([size_x,size_y],x1_Cell2,y1_Cell2);

%%% looking for ilegal hopping due to patch that is already 
% occupied by finding common lininds
oldlinind = id_linind_type_Z_E_Cell2(:,2);
id_common_oldlinind_newlinind_Cell2 = find(ismember(newlinindattempt,oldlinind));

%%% finding no hops %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
id_no_hop1_Cell2 = id_common_oldlinind_newlinind_Cell2;

%%% initalizing id_newlinindattempt_type_newZ_E_T_cell %%%%
id_newlinindattempt_type_newZ_E = id_linind_type_Z_E_Cell2;

%%% assigning the newlinindattempts %%%%%%%%%%%%%%%%%%%%%%%
id_newlinindattempt_type_newZ_E(:,2) = newlinindattempt;

%%% assigning the no hops to the newlinindattempts %%%%%%%%
id_newlinindattempt_type_newZ_E(id_no_hop1_Cell2,2) = id_linind_type_Z_E_Cell2(id_no_hop1_Cell2,2);

%%% updating the newlininds %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
newlinindattempt_with_no_hops = id_newlinindattempt_type_newZ_E(:,2);

%%% assigning newZ to the newlininds %%%%%%%%%%%%%%%%%%%%%%
id_newlinindattempt_type_newZ_E(:,4) = Z2(newlinindattempt_with_no_hops);





