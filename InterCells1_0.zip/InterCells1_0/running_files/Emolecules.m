function [id_linind_type_Z_newE_Cell1,id_linind_type_Z_newE_Cell2] = ...
    Emolecules(simulation_data,parameters)

% input      : simulation_data, parameters.
% output     : id_linind_type_Z_newE_Cell1,
%              id_linind_type_Z_newE_Cell2
% called by  : new_linind_two_cells.
% calling    : none.
% description: updates the molecules' energy values.

for fold_read_data = 1:1
id_linind_type_Z_oldE_Cell1 = simulation_data.Cell1.molecules;
id_linind_type_Z_oldE_Cell2 = simulation_data.Cell2.molecules;

%%% Cell1
id_linind_type_Z_newE_Cell1      = id_linind_type_Z_oldE_Cell1;
id_linind_type_Z_newE_Cell1(:,5) = 0;
%%% Cell2
id_linind_type_Z_newE_Cell2      = id_linind_type_Z_oldE_Cell2;
id_linind_type_Z_newE_Cell2(:,5) = 0;

%%% getting the Z of the membrane at the locations of molecules
%%% Cell1
% Cell1name        = parameters.Cells.Cell1.cellname;

idm1     = id_linind_type_Z_oldE_Cell1(:,1);
linindm1 = id_linind_type_Z_oldE_Cell1(:,2);
typesm1  = id_linind_type_Z_oldE_Cell1(:,3);
DZm1     = id_linind_type_Z_oldE_Cell1(:,4);
Nm1      = size(idm1,1);


%%% Cell2
% Cell2name        = parameters.Cells.Cell2.cellname;

idm2     = id_linind_type_Z_oldE_Cell2(:,1);
linindm2 = id_linind_type_Z_oldE_Cell2(:,2);
typesm2  = id_linind_type_Z_oldE_Cell2(:,3);
DZm2     = id_linind_type_Z_oldE_Cell2(:,4);
Nm2      = size(idm2,1);

% Cell2name    = parameters.Cells.Cell2.cellname;

%%% assigning E_binding to 0 
Emb1 = zeros(Nm1,1);
Emb2 = zeros(Nm2,1);

%%% assigning E_spring to 0 
Ems1  = zeros(Nm1,1);
Ems2  = zeros(Nm2,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% membranes rigidity
K1 = simulation_data.Cell1.membrane.K;
K2 = simulation_data.Cell1.membrane.K;

%%% membranes rigidity at molecules locations
linindm1_1 = linindm1(typesm1 == 1);
linindm1_2 = linindm1(typesm1 == 2);
linindm1_3 = linindm1(typesm1 == 3);

linindm2_1 = linindm2(typesm2 == 1);
linindm2_2 = linindm2(typesm2 == 2);
linindm2_3 = linindm2(typesm2 == 3);
% linindm2_1 = linindm1(typesm2 == 1);
% linindm2_2 = linindm1(typesm2 == 2);
% linindm2_3 = linindm1(typesm2 == 3);
% K1_linindm1 = K1(linindm1);
% K2_linindm2 = K2(linindm2);

K1_linindm1_1 = K1(linindm1_1);
K1_linindm1_2 = K1(linindm1_2);
K1_linindm1_3 = K1(linindm1_3);

K2_linindm2_1 = K2(linindm2_1);
K2_linindm2_2 = K2(linindm2_2);
K2_linindm2_3 = K2(linindm2_3);

a     = parameters.global.pixel_size;

%%% spring constants of molecules
% Cell1
k1_1  = parameters.Cells.Cell1.molecules.type1.spring_k;
k1_2  = parameters.Cells.Cell1.molecules.type2.spring_k;
k1_3  = parameters.Cells.Cell1.molecules.type3.spring_k;

% Cell2
k2_1  = parameters.Cells.Cell2.molecules.type1.spring_k;
k2_2  = parameters.Cells.Cell2.molecules.type2.spring_k;
k2_3  = parameters.Cells.Cell2.molecules.type3.spring_k;

%%% spring constants of molecules combined with membrane rigidity
% Cell1
km1_1 = k1_1*K1_linindm1_1/a^2;
km1_2 = k1_2*K1_linindm1_2/a^2;
km1_3 = k1_3*K1_linindm1_3/a^2;
km1   = [km1_1;km1_2;km1_3];
% Cell2
km2_1 = k2_1*K2_linindm2_1/a^2;
km2_2 = k2_2*K2_linindm2_2/a^2;
km2_3 = k2_3*K2_linindm2_3/a^2;
km2   = [km2_1;km2_2;km2_3];
%%% molecules heights
% Cell1
h1_1  = parameters.Cells.Cell1.molecules.type1.vertical_size;
h1_2  = parameters.Cells.Cell1.molecules.type2.vertical_size;
h1_3  = parameters.Cells.Cell1.molecules.type3.vertical_size;

% Cell2
h2_1  = parameters.Cells.Cell2.molecules.type1.vertical_size;
h2_2  = parameters.Cells.Cell2.molecules.type2.vertical_size;
h2_3  = parameters.Cells.Cell2.molecules.type3.vertical_size;

%%% binding ranges min and max
% Cell1
bmin1_1  = parameters.Cells.Cell1.molecules.type1.binding_bottom;
bmin1_2  = parameters.Cells.Cell1.molecules.type2.binding_bottom;
bmin1_3  = parameters.Cells.Cell1.molecules.type3.binding_bottom;

bmax1_1  = parameters.Cells.Cell1.molecules.type1.binding_top;
bmax1_2  = parameters.Cells.Cell1.molecules.type2.binding_top;
bmax1_3  = parameters.Cells.Cell1.molecules.type3.binding_top;

% Cell2
bmin2_1  = parameters.Cells.Cell2.molecules.type1.binding_bottom;
bmin2_2  = parameters.Cells.Cell2.molecules.type2.binding_bottom;
bmin2_3  = parameters.Cells.Cell2.molecules.type3.binding_bottom;

bmax2_1  = parameters.Cells.Cell2.molecules.type1.binding_top;
bmax2_2  = parameters.Cells.Cell2.molecules.type2.binding_top;
bmax2_3  = parameters.Cells.Cell2.molecules.type3.binding_top;

%%% binding strengths
% Cell1
U1_1  = parameters.Cells.Cell1.molecules.type1.binding_strength;
U1_2  = parameters.Cells.Cell1.molecules.type2.binding_strength;
U1_3  = parameters.Cells.Cell1.molecules.type3.binding_strength;

% Cell2
U2_1  = parameters.Cells.Cell2.molecules.type1.binding_strength;
U2_2  = parameters.Cells.Cell2.molecules.type2.binding_strength;
U2_3  = parameters.Cells.Cell2.molecules.type3.binding_strength;


end % fold_reading_data


%%% finding the Z of the type_tcr proteins 
%%% Cell1
idm1_1 = idm1(typesm1 == 1);
idm1_2 = idm1(typesm1 == 2);
idm1_3 = idm1(typesm1 == 3);

%%% Cell2
idm2_1 = idm2(typesm2 == 1);
idm2_2 = idm2(typesm2 == 2);
idm2_3 = idm2(typesm2 == 3);

%%% DZ
%%% Cell1
DZm1_1 = DZm1(idm1_1); % linindm1_1 % idm1_1
DZm1_2 = DZm1(idm1_2);
DZm1_3 = DZm1(idm1_3);

%%% Cell2
DZm2_1 = DZm2(idm2_1);
DZm2_2 = DZm2(idm2_2);
DZm2_3 = DZm2(idm2_3);

%%% finding molecules on the oposite membranes that are 
%%% of the same type
%%% Cell1
linindm1_1 = linindm1(idm1_1);
linindm1_2 = linindm1(idm1_2);
linindm1_3 = linindm1(idm1_3);

%%% Cell2
linindm2_1 = linindm2(idm2_1);
linindm2_2 = linindm2(idm2_2);
linindm2_3 = linindm2(idm2_3);

%%% finding Cell1 in binding range that are 
%%% colocalized with Cell2
%%% Cell1
idm1_1_colocalized  = idm1_1(ismember(linindm1_1,linindm2_1));
idm1_2_colocalized  = idm1_2(ismember(linindm1_2,linindm2_2));
idm1_3_colocalized  = idm1_3(ismember(linindm1_3,linindm2_3));

%%% Cell2
idm2_1_colocalized  = idm2_1(ismember(linindm2_1,linindm1_1));
idm2_2_colocalized  = idm2_2(ismember(linindm2_2,linindm2_2));
idm2_3_colocalized  = idm2_3(ismember(linindm2_3,linindm1_3));

%%% Cell1
% linindm1_1_colocalized = linindm1_1(idm1_1_colocalized);
% linindm1_2_colocalized = linindm1_2(idm1_2_colocalized);
% linindm1_3_colocalized = linindm1_3(idm1_3_colocalized);
% 
% %%% Cell2
% linindm2_1_colocalized = linindm2_1(idm2_1_colocalized);
% linindm2_2_colocalized = linindm2_2(idm2_2_colocalized);
% linindm2_3_colocalized = linindm2_3(idm2_3_colocalized);

%%% Zm of colocalized molecules
%%% Cell1
DZm1_1_colocalized = DZm1(idm1_1_colocalized);
DZm1_2_colocalized = DZm1(idm1_2_colocalized);
DZm1_3_colocalized = DZm1(idm1_3_colocalized);

% Cell2
DZm2_1_colocalized = DZm2(idm2_1_colocalized);
DZm2_2_colocalized = DZm2(idm2_2_colocalized);
DZm2_3_colocalized = DZm2(idm2_3_colocalized);


%%% finding id of molecules in binding range 
%%% Cell1
idm1_1_colocalized_in_binding_range = ...
    idm1_1_colocalized(DZm1_1_colocalized >= bmin1_1...
                     & DZm1_1_colocalized <= bmax1_1);

idm1_2_colocalized_in_binding_range = ...
    idm1_2_colocalized(DZm1_2_colocalized >= bmin1_2...
                     & DZm1_2_colocalized <= bmax1_2);
             
idm1_3_colocalized_in_binding_range = ...
    idm1_3_colocalized(DZm1_3_colocalized >= bmin1_3...
                     & DZm1_3_colocalized <= bmax1_3);
                 
idm1_colocalized_in_binding_range = [...
    idm1_1_colocalized_in_binding_range;
    idm1_2_colocalized_in_binding_range;
    idm1_3_colocalized_in_binding_range];                

%%% Cell2
idm2_1_colocalized_in_binding_range = ...
    idm2_1_colocalized(DZm2_1_colocalized >= bmin1_1...
                     & DZm2_1_colocalized <= bmax1_1);

idm2_2_colocalized_in_binding_range = ...
    idm2_2_colocalized(DZm2_2_colocalized >= bmin1_2...
                     & DZm2_2_colocalized <= bmax1_2);  

idm2_3_colocalized_in_binding_range = ...
    idm2_3_colocalized(DZm2_3_colocalized >= bmin1_3...
                     & DZm2_3_colocalized <= bmax1_3);                  

idm2_colocalized_in_binding_range = [...
    idm2_1_colocalized_in_binding_range;
    idm2_2_colocalized_in_binding_range;
    idm2_3_colocalized_in_binding_range];  
%%% E_binding
%%% Cell1
Emb1(idm1_1_colocalized_in_binding_range) = U1_1;
Emb1(idm1_2_colocalized_in_binding_range) = U1_2;
Emb1(idm1_3_colocalized_in_binding_range) = U1_3;


%%% Cell2
Emb2(idm2_1_colocalized_in_binding_range) = U2_1;                
Emb2(idm2_2_colocalized_in_binding_range) = U2_2;                
Emb2(idm2_3_colocalized_in_binding_range) = U2_3;                

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% E_spring %%%%%%%%%%%%%%%%%%%%%%%%%%
%%% finding the id of the proteins type in spring range 
%%% Cell1
idm1_1_in_spring_range = idm1_1(DZm1_1 < h1_1); % <=
idm1_2_in_spring_range = idm1_2(DZm1_2 < h1_2); % <=
idm1_3_in_spring_range = idm1_3(DZm1_3 < h1_3); % <=

%%% Cell2
idm2_1_in_spring_range = idm2_1(DZm2_1 < h2_1);
idm2_2_in_spring_range = idm2_2(DZm2_2 < h2_2);
idm2_3_in_spring_range = idm2_3(DZm2_3 < h2_3);

%%% finding the Z of the molecules in spring range
%%% Cell1
DZm1_1_in_spring_range = DZm1(idm1_1_in_spring_range);
DZm1_2_in_spring_range = DZm1(idm1_2_in_spring_range);
DZm1_3_in_spring_range = DZm1(idm1_3_in_spring_range);

%%% Cell2 
DZm2_1_in_spring_range = DZm2(idm2_1_in_spring_range);
DZm2_2_in_spring_range = DZm2(idm2_2_in_spring_range);
DZm2_3_in_spring_range = DZm2(idm2_3_in_spring_range);

%%% calculating the spring energy %%%%%%%%%%%%%%%%%
%%% Cell1 type1
Ems1(idm1_1_in_spring_range) = ...
    0.5*km1(idm1_1_in_spring_range).*(h1_1 - DZm1_1_in_spring_range).^2;

%%% Cell1 type2
Ems1(idm1_2_in_spring_range) = ...
    0.5*km1(idm1_2_in_spring_range).*(h1_2 - DZm1_2_in_spring_range).^2;

%%% Cell1 type3
Ems1(idm1_3_in_spring_range) = ...
    0.5*km1(idm1_3_in_spring_range).*(h1_3 - DZm1_3_in_spring_range).^2;

%%% Cell2
%%% Cell2 type1
Ems2(idm2_1_in_spring_range) = ...
    0.5*km2(idm2_1_in_spring_range).*(h2_1 - DZm2_1_in_spring_range).^2;

%%% Cell2 type2
Ems2(idm2_2_in_spring_range) = ...
    0.5*km2(idm2_2_in_spring_range).*(h2_2 - DZm2_2_in_spring_range).^2;

%%% Cell2 type3
Ems2(idm2_3_in_spring_range) = ...
    0.5*km2(idm2_3_in_spring_range).*(h2_3 - DZm2_3_in_spring_range).^2;

%%% poly_L_lysene %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
use_PLL      = parameters.global.PLL.use;
U_PLL        = parameters.global.PLL.binding_strength;
E_PLL_Cell1  = zeros(Nm1,1);

if strcmp(Cell2name,'Coverslip');
    if use_PLL
        idm1_1_in_PLL_range = idm1_1(DZm1_1 <= h1_1 + 3);
        idm1_2_in_PLL_range = idm1_2(DZm1_2 <= h1_2 + 5);
        idm1_3_in_PLL_range = idm1_3(DZm1_3 <= h1_3 + 5);
        idm1_in_PLL_range   = [idm1_1_in_PLL_range;
                               idm1_2_in_PLL_range;
                               idm1_3_in_PLL_range];

%         idm1_in_PLL_range   = [idm1_2_in_PLL_range;
%                                idm1_3_in_PLL_range];
        E_PLL_Cell1(idm1_in_PLL_range) = U_PLL;                
%         E_PLL_Cell1(idm1_1_in_PLL_range) = U_PLL;
%         E_PLL_Cell1(idm1_2_in_PLL_range) = U_PLL;
%         E_PLL_Cell1(idm1_3_in_PLL_range) = U_PLL;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% E_Cell1 = Emb1 + Ems1 + E_PLL_Cell1;
E_Cell1 = Ems1 + E_PLL_Cell1;
E_Cell1(idm1_colocalized_in_binding_range) = ...
   Emb1(idm1_colocalized_in_binding_range);

E_Cell2 = Emb2 + Ems2;

id_linind_type_Z_newE_Cell1(:,5) = E_Cell1;
id_linind_type_Z_newE_Cell2(:,5) = E_Cell2;

%%%
% subplot(2,2,3)
% 
% Z1 = simulation_data.Cell1.membrane.Z;
% iter = simulation_data.iter;
% E_molecules1 = zeros(size(Z1));
% E_molecules1(linindm1) = id_linind_type_Z_newE_Cell1(:,5);
% 
% figure(6)
% clf
% imagesc(E_molecules1)
% text(20,20,[int2str(iter)])
% colorbar
% caxis([-14 4])
% title('E molecules1')
% 
% pause%(0.1)
%%% 
end


