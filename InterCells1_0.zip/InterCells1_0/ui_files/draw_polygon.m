function polygon_boundary = draw_polygon(parameters)

size_x     = parameters.global.array_size_x;
size_y     = parameters.global.array_size_y;

figure(8)

axis equal
axis([0 size_x 0 size_y])

% the initial list of points is empty 
px = [];
py = [];
n  = 0; % point index

% picking up the polygon points 
disp('Left mouse button picks points')
disp('Right mouse button picks last point')

button = 1;
hold on
while button == 1
    [xi,yi,button] = ginput(1);
    plot(xi,yi,'ko')
    n = n+1;
    px(n) =  xi;
    py(n) =  yi;
end
polygon_x  = [px, px(1)];
polygon_y  = [py, py(1)];
polygon_boundary = [polygon_x',polygon_y'];

% plot polygon 
plot(polygon_x,polygon_y,'-','Color','k');

end