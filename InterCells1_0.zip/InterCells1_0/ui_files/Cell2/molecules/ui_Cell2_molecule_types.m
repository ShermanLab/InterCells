function parameters = ui_Cell2_molecule_types(ui_parameters,parameters)
% Cell1_type
%%%
x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;
%%%

fs8  = 8;
% fs10 = 10;
fs12 = 12;

c2_1 = parameters.Cells.Cell2.molecules.type1.color;
c2_2 = parameters.Cells.Cell2.molecules.type2.color;
c2_3 = parameters.Cells.Cell2.molecules.type3.color;
%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 2;
gapy = 2;

px   = x0+170;
py   = y0+610;
pw   = 155;
ph   = 160; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 20;

p = figure(26);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');
%     set(p,'Name','Cell1 Type','NumberTitle','off');

%%% title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol('Parent',p,...
    'Style','text',...
    'String','Cell2 molecule types','FontSize',fs12,...
    'Position',[2 130 150 30]);

%%% button group %%%%%%%%%%%%%%%%%%%%%%
bgh   = 150;

rbw   = 80;%100;
rbh   = 20;

bg = uibuttongroup('Parent',p,...
    'visible','on',...
    'Position',[0 0 1 1]);
%     'Title','Cell1 type',...
%     'FontSize',fs10);
%   [bgx/w0 bgy/h0 bgw/w0 bgh/h0], uipanel,
% Create three radio buttons in the button group.
% rb1 = 
uicontrol(bg,'Style','PushButton',...
  'String','Mol. type1',...
  'FontSize',fs8,...
  'Position',[gapx bgh-2*(gapy+rbh) rbw rbh],...
  'Backgroundcolor',c2_1,...
  'Callback','parameters = ui_Cell2_molecule1(ui_parameters,parameters)');
% rb2 = 
uicontrol(bg,'Style','PushButton',...
  'String','Mol. type2',...
  'FontSize',fs8,...
  'Position',[gapx bgh-3*(gapy+rbh) rbw rbh],...
  'Backgroundcolor',c2_2,...
  'Callback','parameters = ui_Cell2_molecule2(ui_parameters,parameters)');

% rb3 = 
uicontrol(bg,'Style','PushButton',...
  'String','Mol. type3',...
  'FontSize',fs8,...
  'Position',[gapx bgh-4*(gapy+rbh) rbw rbh],...
  'Backgroundcolor',c2_3,...
  'Callback','parameters = ui_Cell2_molecule3(ui_parameters,parameters)');

% rb4 = 
% uicontrol(bg,'Style','PushButton',...
%   'String','Mol. type4',...
%   'FontSize',fs8,...
%   'Position',[gapx bgh-5*(gapy+rbh) rbw rbh]);

uicontrol(bg,'Style','pushbutton',...
    'String','Apply',...
    'Position',[pbx pby pbw pbh],...
    'Callback','[]'); % {@button_callback}

uicontrol(bg,'Style','pushbutton',...
    'String','Close',...
    'Position',[pbx+pbw+gapx pby pbw pbh],...
    'Callback','close(26)'); % {@button_callback}

end

% Initialize some button group properties. 
% set(h,'SelectionChangeFcn','2');
% set(h,'SelectedObject',[]);  % No selection
% set(h,'Visible','on');
% Cell1_type = get(get(h,'SelectedObject'),'String');










