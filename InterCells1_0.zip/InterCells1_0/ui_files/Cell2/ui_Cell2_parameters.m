% ui_Cell1_parameters

table_Cell1    = Cell1_parameters2table(parameters);
dat            = table_Cell1;
nrows          = size(dat,1);

columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {150,'auto','auto'};
columneditable = [false false true]; 

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
gapx = 3;
gapy = 3;
tx   = 150+6+360;
ty   = 156;
tw   = 350;
th   = nrows*rowh+57;


t = uitable('Parent',f0,'Data',dat,...
            'ColumnName',columnname,...
            'ColumnFormat',columnformat,...
            'ColumnWidth',columnwidth,...
            'ColumnEditable',columneditable,...
            'Position',[tx ty tw th]);

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pbx = tx+231;
Cancel_pby = ty+10;
Cancel_pbw = 50;
Cancel_pbh = 20;

Cancel_pb = uicontrol('Style', 'pushbutton',...
    'String','Cancel','Position', [Cancel_pbx Cancel_pby Cancel_pbw Cancel_pbh],...
    'FontSize',8,...
    'Callback', 'cla'); % 'Parent','f0',

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pbx = Cancel_pbx + Cancel_pbw + gapx;
Ok_pby = Cancel_pby;
Ok_pbw = 50;
Ok_pbh = 20;

Ok_pb = uicontrol('Style', 'pushbutton',...
    'String','Ok','Position', [Cancel_pbx+Cancel_pbw+3 Cancel_pby Cancel_pbw Cancel_pbh],...
    'FontSize',8,...
    'Callback', '[]'); % 'Parent','f0',
        
        
        % size dat, y_row
















