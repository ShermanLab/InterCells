function parameters = ui_Cell2_membrane(ui_parameters,parameters)

% f0 = ui_parameters.mainfig.name;
for fold1 = 1:1
    %%% craete global parameters table
    table_Cell2_membrane    = Cell2_membrane_parameters2table(parameters);
    dat            = table_Cell2_membrane;
    nrows          = size(dat,1);
    
    %%% getting parameters %%%%%%%%%%%%
%     f0 = ui_parameters.mainfig.name;

    x0 = ui_parameters.mainfig.x0;
    y0 = ui_parameters.mainfig.y0;

    fs8  = 8;
    
    fs12  = 12;
    
    %%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
    rowh = 18;
    pw   = 305;
    ph   = nrows*rowh+95; % nrows*rowh+80
    px   = x0+150;
    py   = y0+408;
    
    gapx = 2;
%     gapy = 2;
     
    p = figure(25);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');
%     set(p,'Name','Cell1 Membrane','NumberTitle','off');

end
%%% title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol('Parent',p,...
    'Style','text',...
    'String','Cell2 Membrane','FontSize',fs12,...
    'Position',[0 315 305 30]);

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1
    columnname     = {'Name', 'Default', 'New',};
    columnformat   = {'char','numeric', 'numeric'};
    columnwidth    = {150,60,60}; % {150,'auto','auto'};
    columneditable = [false false true]; 

    tx   = 0;
    ty   = 25;
    tw   = 305;
    th   = 290;   
     
    t = uitable('Parent',p,...
        'Data',dat,...
        'ColumnName',columnname,...
        'ColumnFormat',columnformat,...
        'ColumnWidth',columnwidth,...
        'ColumnEditable',columneditable,...
        'Position',[tx ty tw th]); % [tx ty tw th]
end

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1

    Cancel_pbx = 151;
    Cancel_pby = 3;
    pbw = 50;
    pbh = 20;
%     Cancel_pb = 
    uicontrol('Parent',p,...
        'Style', 'pushbutton',...
        'String','Cancel',...
        'Position', [Cancel_pbx Cancel_pby pbw pbh],...
        'FontSize',fs8,...
        'Callback','close(25)'); 
end

%%% Apply %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1
    Apply_pbx = Cancel_pbx + pbw + gapx;
    Apply_pby = 3;
%     Apply_pb = 
    uicontrol('Parent',p,...
        'Style', 'pushbutton',...
        'String','Apply',...
        'Position', [Apply_pbx Apply_pby pbw pbh],...
        'FontSize',fs8,...
        'Callback',@update_membrane_parameters); 
end
%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1

    Close_pbx = Apply_pbx + pbw + gapx; 
    Close_pby = 3; 
%     Close_pb = 
    uicontrol('Parent',p,...
        'Style', 'pushbutton',...
        'String','Close',...
        'Position', [Close_pbx Close_pby pbw pbh],...
        'FontSize',fs8,...
        'Callback', 'close(25)'); 
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
table = get(t,'Data');
membrane_parameters = table2membraneparameters(parameters,table);
parameters.Cells.Cell2.membrane = membrane_parameters;
    
function membrane_parameters = update_membrane_parameters(a,b)
    table = get(t,'Data');
    membrane_parameters = table2membraneparameters(parameters,table);
    parameters.Cells.Cell2.membrane = membrane_parameters;
    uiresume
end
uiwait
end        





