function table_Cell2 = Cell2_parameters2table(parameters)

% table_Cell1 = cell(6,3);
%%% rigidity
table_Cell2{1,1}  = 'Membrane rigidity (KT)';
table_Cell2{2,1}  = 'Membrane min rigidity (KT)';
table_Cell2{3,1}  = 'Membrane max rigidity (KT)';
table_Cell2{4,1}  = 'Membrane local rigidity (0/1)';

%%% diffusivity
table_Cell2{6,1}  = 'Membrane diffusivity (0-1)';
table_Cell2{7,1}  = 'Membrane min diffusivity (KT)';
table_Cell2{8,1}  = 'Membrane max diffusivity (KT)';
table_Cell2{9,1}  = 'Membrane local diffusivity (0/1)';

%%% Z
table_Cell2{11,1} = 'Initial menbrane Z (nm)';
table_Cell2{12,1} = 'Min menbrane Z (nm)';
table_Cell2{13,1} = 'Max menbrane Z (nm)';
table_Cell2{14,1} = 'Sigma dz (nm)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
table_Cell2{1,2}  = parameters.Cells.Cell1.membrane.rigidity;
table_Cell2{2,2}  = parameters.Cells.Cell1.membrane.min_rigidity;
table_Cell2{3,2}  = parameters.Cells.Cell1.membrane.max_rigidity;
table_Cell2{4,2}  = parameters.Cells.Cell1.membrane.local_rigidity;

table_Cell2{6,2}  = parameters.Cells.Cell1.membrane.diffusivity;
table_Cell2{7,2}  = parameters.Cells.Cell1.membrane.min_diffusivity;
table_Cell2{8,2}  = parameters.Cells.Cell1.membrane.max_diffusivity;
table_Cell2{9,2}  = parameters.Cells.Cell1.membrane.local_diffusivity;

table_Cell2{11,2} = parameters.Cells.Cell1.membrane.Z0;
table_Cell2{12,2} = parameters.Cells.Cell1.membrane.min_Z;
table_Cell2{13,2} = parameters.Cells.Cell1.membrane.max_Z;
table_Cell2{14,2} = parameters.Cells.Cell1.membrane.dz;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table_Cell2(:,3)  = table_Cell2(:,2);

















