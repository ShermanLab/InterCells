function analyses_options = ui_analyses_options(ui_parameters,parameters)


analyses_options = [];

x0   = ui_parameters.mainfig.x0;
y0   = ui_parameters.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2 = 10;
fs3 = 12;

gapx = 2;
gapy = 2;

px   = x0+170;
py   = y0+610;
pw   = 175;
ph   = 190; 

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 30;
cbh  = 20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(16);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
% set(p,'Name','Cell1 Type','NumberTitle','off');

%%% text Cell1 molecules %%%%%%%%%%%%%%
text1 = uicontrol(p,'Style','text',...
  'String','Analyses options',...
  'FontSize',fs3,...
  'Position',[2 ph-pbh pw pbh]);

%%% Pair Correlation Function %%%%%%%%%
 cb1 = uicontrol(p,'Style','checkbox',...
     'String','Pair Correlation Function',...
     'FontSize',fs2,...
     'Value',1,...
     'Position',[2 ph-3*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,1});

%%% Pair Correlation Function %%%%%%%%% 
cb2 = uicontrol(p,'Style','checkbox',...
     'String','Dilations',...
     'FontSize',fs2,...
     'Value',1,...
     'Position',[2 ph-4*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,2});

%%% Minkowski functionals %%%%%%%%%%%%% 
cb3 = uicontrol(p,'Style','checkbox',...
     'String','Minkowski functionals',...
     'FontSize',fs2,...
     'Value',0,...
     'Position',[2 ph-5*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,3});
 
%%% Clustering %%%%%%%%%%%%%%%%%%%%%%%%
cb4 = uicontrol(p,'Style','checkbox',...
     'String','Clustering',...
     'FontSize',fs2,...
     'Value',0,...
     'Position',[2 ph-6*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,4});
 
%%% Entropy %%%%%%%%%%%%%%%%%%%%%%%%%%%
cb5 = uicontrol(p,'Style','checkbox',...
     'String','Entropy',...
     'FontSize',fs2,...
     'Value',0,...
     'Position',[2 ph-7*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,5});
 
 
%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(p,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[pbx pby pbw 20],...
    'Callback','close(16)'); 

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(text1,'Left'   ,'Top');
align(cb1  ,'Fixed',2,'none');
% align(Close_pb,'Fixed',2,'none');
align([text1 cb1 cb2 cb3 cb4 cb5],'Left','Fixed',gapy);














end