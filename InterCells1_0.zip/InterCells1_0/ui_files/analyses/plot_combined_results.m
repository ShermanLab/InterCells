function plot_combined_results(movie,DILATIONS,MINKOWSKI)
% plot_combined_results(movie,DILATIONS,MINKOWSKI)
% plot_combined_results(movie,GR,DEPLETIONS,MINKOWSKI)

%%% plot points locations


%%% plot density(dilations)


%%% plot minkowski 
















