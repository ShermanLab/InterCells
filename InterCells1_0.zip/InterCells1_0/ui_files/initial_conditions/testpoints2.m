function [locations_array,linind_locations] = testpoints2(...
    ui_parameters,parameters,locations_array,Celln,Typen,CTcolor)


[size_x,size_y] = size(locations_array);
%%%
if Celln == 1
    locations_array1 = locations_array;
    if Typen == 1
        Cell_molecule = parameters.Cells.Cell1.molecules.type1;
        global_density  = Cell_molecule.global_density;
        cluster_density = Cell_molecule.cluster_density;
    end
    if Typen == 2
        Cell_molecule = parameters.Cells.Cell1.molecules.type2;
        global_density  = Cell_molecule.global_density;
        cluster_density = Cell_molecule.cluster_density;
    end
    if Typen == 3
        Cell_molecule = parameters.Cells.Cell1.molecules.type3;
        global_density  = Cell_molecule.global_density;
        cluster_density = Cell_molecule.cluster_density;
    end
end
if Celln == 2
    locations_array2 = locations_array;
    Cell_molecule = parameters.Cells.Cell2.molecules.type1;
end
%%%



 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


for ui_fold = 1:1
x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;
%%%

fs1 = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 2;
gapy = 2;

px   = x0+300;
py   = y0+200;
pw   = 150;
ph   = 217; 

pbx  = 3;
pby  = 3;
pbw  = pw-4;
pbh  = 30;

bgh   = ph;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(19);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');
    
uicontrol('Parent',p,...
    'Style','text',...
    'String','Distribution method','FontSize',fs3,...
    'Position',[2 ph-30 pbw 30],...
    'Backgroundcolor',CTcolor);

%%% button group %%%%%%%%%%%%%%%%%%%%%%
bg = uibuttongroup('Parent',p,...
  'visible','on',...
  'Position',[0 0 1 1]);

%%% load file %%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(bg,'Style','PushButton',...
  'String','Load existing file',...
  'FontSize',fs2,...
  'Position',[gapx bgh-2*(gapy+pbh) pbw pbh],...
  'Callback',@get_existing_data);

%%% generate file from experiment %%%%%
uicontrol(bg,'Style','PushButton',...
  'String','Load experimental data',...
  'FontSize',fs2,...
  'Position',[gapx bgh-3*(gapy+pbh) pbw pbh],...
  'Callback',@get_experimental_data);

%%% uniform distribution %%%%%%%%%%%%%%
uicontrol(bg,'Style','PushButton',...
  'String','Uniform distribution (D)',...
  'FontSize',fs2,...
  'Position',[gapx bgh-4*(gapy+pbh) pbw pbh],...
  'Callback',@get_uniform_distribution);   
    
%%% clusters(r) (circular, N) rand locations
uicontrol(bg,'Style','PushButton',...
  'String','circular clusters',...
  'FontSize',fs2,...
  'Position',[gapx bgh-5*(gapy+pbh) pbw pbh],...
  'Callback',@get_circular_clusters);   

%%% clusters (user defined, sizes and locations)
uicontrol(bg,'Style','PushButton',...
  'String','User defined clusters (d)',...
  'FontSize',fs2,...
  'Position',[gapx bgh-6*(gapy+pbh) pbw pbh],...
  'Callback',@get_user_defined_clusters);   

%%% Close
% uicontrol(bg,'Style','PushButton',...
%   'String','Close',...
%   'FontSize',fs1,...
%   'Position',[gapx bgh-7*(gapy+pbh)+10 50 20],...
%   'Callback','close'); 

%%% Cancel
uicontrol(bg,'Style','PushButton',...
  'String','Cancel',...
  'FontSize',fs1,...
  'Position',[gapx bgh-7*(gapy+pbh)+10 50 20],...
  'Callback',@cancel1); 
end % ui_fold

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% load existing data file %%%%%%%%%%%
function existing_data_file = get_existing_data(~,~)
    existing_data_path = uigetdir('C:\Users\Owner\Documents\MATLAB\Weikl_Lipowsky\small_patches\Interface_simulation3');
    existing_data_file = uigetfile(existing_data_path);
    uiresume
end

%%% load experimental data file %%%%%%%
function get_experimental_data(~,~)
%     linind_existing_points = linind_initial_locations; % temp
    
    experimental_data_path = uigetdir('C:\Users\Owner\Documents\MATLAB\Weikl_Lipowsky\small_patches\Interface_simulation3');
    experimental_data_file = uigetfile(experimental_data_path);
    uiresume
end

%%% uniform distribution %%%%%%%%%%%%%%

function get_uniform_distribution(~,~) 
    
%     linind_existing_points = simulation_data; % temp

    size_x             = parameters.global.array_size_x;
    size_y             = parameters.global.array_size_y;
    cluster_boundary_x = [0 size_x size_x 0];
    cluster_boundary_y = [0 0 size_y size_y];
    cluster_boundary   = [cluster_boundary_x',cluster_boundary_y'];
    
    linind_locations = test_make_linind_cluster_points(...
        parameters,cluster_boundary,global_density,...
        locations_array,CTcolor);

    if Celln == 1
        locations_array1(linind_locations) = Typen;
        locations_array = locations_array1;
    end
    if Celln == 2
        locations_array2(linind_locations) = Typen;
        locations_array = locations_array2;
    end
        
    uiresume
    close(19)
end

%%% circular clusters %%%%%%%%%%%%%%%%%
function get_circular_clusters(~,~)
%     linind_existing_points = simulation_data; 
    
    circle_boundary = draw_circle(parameters);
    cluster_boundary = circle_boundary;
    
    linind_locations = test_make_linind_cluster_points(...
        parameters,cluster_boundary,cluster_density,...
        locations_array,CTcolor);
    
    if Celln == 1
        locations_array1(linind_locations) = Typen;
        locations_array = locations_array1;
    end
    if Celln == 2
        locations_array2(linind_locations) = Typen;
        locations_array = locations_array2;
    end

    uiresume
    close(19)
end

%%% user defined clusters %%%%%%%%%%%%%
function get_user_defined_clusters(~,~)
%     linind_existing_points = simulation_data; 
    
    polygon_boundary = draw_polygon(parameters);
    cluster_boundary = polygon_boundary;
    
    linind_locations = test_make_linind_cluster_points(...
        parameters,cluster_boundary,cluster_density,...
        locations_array,CTcolor);
    
    uiresume
    close(19)
end

%%% user defined clusters %%%%%%%%%%%%%
function cancel1(~,~)
%     linind_existing_points = simulation_data; 
    
%     linind_locations = [];
    uiresume
    close(19)
end
uiwait

end





