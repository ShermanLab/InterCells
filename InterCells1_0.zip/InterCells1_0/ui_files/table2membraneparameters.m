function membrane_parameters = table2membraneparameters(table)

%%% rigidity 
membrane.rigidity          = table{1,3};
membrane.min_rigidity      = table{2,3};
membrane.max_rigidity      = table{3,3};
membrane.local_rigidity    = table{4,3};
%%% diffusivity 
membrane.diffusivity       = table{6,3};
membrane.min_diffusivity   = table{7,3};
membrane.max_diffusivity   = table{8,3};
membrane.local_diffusivity = table{9,3};
%%% Z
membrane.Z0                = table{11,3};
membrane.min_Z             = table{12,3};
membrane.max_Z             = table{13,3};
membrane.dz                = table{14,3};

membrane_parameters = membrane;
end








