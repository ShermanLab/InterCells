function Cell2_name = ui_Cell2_type(ui_parameters,parameters)
% parameters = 
% Cell2_type

% Cell2_type = parameters.Cells.Cell2.name
%%%
x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;
%%%

fs8  = 8;
% fs10 = 10;
fs12 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 2;
gapy = 2;

px   = x0+170;
py   = y0+480;
pw   = 110;
ph   = 110; %150; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 20;

p = figure(24);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');
%     set(p,'Name','Cell1 Type','NumberTitle','off');

%%% title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol('Parent',p,...
    'Style','text',...
    'String','Cell2 type','FontSize',fs12,...
    'Position',[2 ph-30 106 30]);

%%% button group %%%%%%%%%%%%%%%%%%%%%%
bgh   = ph - 10;

rbw   = 80;%100;
rbh   = 20;

bg = uibuttongroup('Parent',p,...
    'visible','on',...
    'Position',[0 0 1 1]);

% rb2 = 
uicontrol(bg,'Style','Radio',...
  'String','APC',...
  'FontSize',fs8,...
  'Position',[gapx bgh-2*(gapy+rbh) rbw rbh],...
  'Callback',@button_callback);

% rb3 = 
uicontrol(bg,'Style','Radio',...
  'String','Coverslip',...
  'FontSize',fs8,...
  'Position',[gapx bgh-3*(gapy+rbh) rbw rbh],...
  'Callback',@button_callback);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(bg,'Style','pushbutton',...
    'String','Apply',...
    'Position',[pbx pby pbw pbh],...
    'Callback',@button_callback); % @button_callback %'picked_name = update_cell2_name()'

uicontrol(bg,'Style','pushbutton',...
    'String','Close',...
    'Position',[pbx+pbw+gapx pby pbw pbh],...
    'Callback','close(24)'); % {@button_callback}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cellname_pick = get(get(bg,'SelectedObject'),'String');
if strcmp(cellname_pick,'APC')
    Cell2_name = 'APC';
elseif strcmp(cellname_pick,'Coverslip')
    Cell2_name = 'Coverslip';
end
cc1 = Cell2_name
% uiwait(gcf)
%Apply callback function
function Cell2_name = button_callback(a,b) % src,ev picked_name
%     uiresume(gcbf)
    Cell2_name = get(get(bg,'SelectedObject'),'String');
    cc2 = Cell2_name
    uiresume(gcbf)
end

uiwait(gcf)
end

% f = figure;
% h = uicontrol('Position',[20 20 200 40],'String','Continue',...
%               'Callback','uiresume(gcbf)');
% disp('This will print immediately');
% uiwait(gcf); 
% disp('This will print after you click Continue');
% close(f);








