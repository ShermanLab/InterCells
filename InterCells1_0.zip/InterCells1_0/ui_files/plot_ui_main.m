function plot_ui_main(parameters,simulation_data)

% input      : parameters,
%              simulation_data
% output     :
% called by  :
% calling    :
% description:

%%% subplots sizes and locations
rx = 0.27; % ratio of x origin location
ry = 0.10; % ratio of y origin location
rw = 0.35; % ratio of subplot width
rh = 0.35; % ratio of subplot height
dx = 0.35; % ratio of delta x
dy = 0.45; % ratio of delta y

%%% font sizes
fs1 = 8;
fs2 = 10;
fs3 = 12;
fs4 = 14;

%%% proteins properties %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for plot_proteins_properties = 1:1
    pos1 = [rx*0.9 ry+dy-0.05 rw rh*1.1];
    subplot('Position',pos1)
    %%% locations %%%%%%%%%%%%%%%%%%%%%%%%%
    mz1 = 70;
    mz2 = 0;
%     z_min  = mz2 - 20;
%     z_max  = mz1 + 20;
    mx_min = 0;
    mx_max = 120;
%     x_min  = mx_min - 10;
%     x_max  = mx_max + 10;
    dx_p   = 15;
    
    %%% proteins colors %%%%%%%%%%%%%%%%%%%
    %%% Cell1
    color1_1 = parameters.Cells.Cell1.molecules.type1.color;
    color1_2 = parameters.Cells.Cell1.molecules.type2.color;
    color1_3 = parameters.Cells.Cell1.molecules.type3.color;
    
    %%% Cell2
    color2_1 = parameters.Cells.Cell2.molecules.type1.color;
    color2_2 = parameters.Cells.Cell2.molecules.type2.color;
    color2_3 = parameters.Cells.Cell2.molecules.type3.color;

    %%% PLL 
    PLL_parameters = parameters.global.PLL;
    PLL_color      = PLL_parameters.color;
    PLL_U          = PLL_parameters.binding_strength;
    PLL_bmax       = PLL_parameters.binding_top;

    %%% plot membranes %%%%%%%%%%%%%%%%%%%%
    % plot membrane1
    plot([mx_min mx_max],[mz1 mz1]    ,'-','Color',[1 1 1],'LineWidth',6)
    hold on
    plot([mx_min mx_max],[mz2 mz2]    ,'-','Color',[0 0 0],'LineWidth',6)
    %%% cell2 layer (PLL)
    plot([mx_min mx_max],[mz2+2 mz2+2],'-','Color',PLL_color,'LineWidth',3)
    
    %%% membranes %%%%%%%%%%%%%%%%%%%%%
    text((mx_max+mx_min)/2,mz1+12,'Cell1 membrane','FontSize',fs4,'HorizontalAlignment','Center')
    text((mx_max+mx_min)/2,mz2-12,'Cell2 membrane','FontSize',fs4,'HorizontalAlignment','Center')
    
    %%% Cells names
    Cell1_name = parameters.Cells.Cell1.cellname;
    Cell2_name = parameters.Cells.Cell2.cellname;    
    
    text((mx_min),mz1+12,['Cell1 = ',Cell1_name],'FontSize',fs4,'HorizontalAlignment','Center')
    text((mx_min),mz2-12,['Cell2 = ',Cell2_name],'FontSize',fs4,'HorizontalAlignment','Center')
    
    %%% get mol sizes %%%%%%%%%%%%%%%%%
    %%% Cell1 molecules %%%%%%%%%%%%%%%
    Cell1_molecules = parameters.Cells.Cell1.molecules;
    
    %%% names %%%%%%%%%%%%%%%%%%%%%%%%%
    name1_1 = Cell1_molecules.type1.name;
    name1_2 = Cell1_molecules.type2.name;
    name1_3 = Cell1_molecules.type3.name;
    
    %%% heights %%%%%%%%%%%%%%%%%%%%%%%
    h1_1    = Cell1_molecules.type1.vertical_size;
    h1_2    = Cell1_molecules.type2.vertical_size;
    h1_3    = Cell1_molecules.type3.vertical_size;
    
    %%% diffusions %%%%%%%%%%%%%%%%%%%%
    D1_1    = Cell1_molecules.type1.diffusion_constant;
    D1_2    = Cell1_molecules.type2.diffusion_constant;
    D1_3    = Cell1_molecules.type3.diffusion_constant;
    
    %%% potentials %%%%%%%%%%%%%%%%%%%%
    U1_1    = Cell1_molecules.type1.binding_strength;
    U1_2    = Cell1_molecules.type2.binding_strength;
    U1_3    = Cell1_molecules.type3.binding_strength;
    
    %%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%
    Cell2_molecules = parameters.Cells.Cell2.molecules;
    
    %%% names %%%%%%%%%%%%%%%%%%%%%%%%%
    name2_1 = Cell2_molecules.type1.name;
    name2_2 = Cell2_molecules.type2.name;
    name2_3 = Cell2_molecules.type3.name;
    
    %%% heights %%%%%%%%%%%%%%%%%%%%%%%
    h2_1    = Cell2_molecules.type1.vertical_size;
    h2_2    = Cell2_molecules.type2.vertical_size;
    h2_3    = Cell2_molecules.type3.vertical_size;
    
    %%% diffusions %%%%%%%%%%%%%%%%%%%%
    D2_1    = Cell2_molecules.type1.diffusion_constant;
    D2_2    = Cell2_molecules.type2.diffusion_constant;
    D2_3    = Cell2_molecules.type3.diffusion_constant;
    
    %%% potentials %%%%%%%%%%%%%%%%%%%%
    U2_1    = Cell2_molecules.type1.binding_strength;
    U2_2    = Cell2_molecules.type2.binding_strength;
    U2_3    = Cell2_molecules.type3.binding_strength;
    
    %%% plot molecules %%%%%%%%%%%%%%%%%%%%
    %%% cell1 Mol1
    plot([1*dx_p 1*dx_p],[mz1 mz1-h1_1],...
        '-','Color',color1_1,'LineWidth',10)
    %%% cell1 Mol2
    plot([2*dx_p 2*dx_p],[mz1 mz1-h1_2],...
        '-','Color',color1_2,'LineWidth',10)
    %%% cell1 Mol3
    plot([3*dx_p 3*dx_p],[mz1 mz1-h1_3],...
        '-','Color',color1_3,'LineWidth',10)
    
    %%% cell2 Mol1
    plot([1*dx_p 1*dx_p],[0 3],...
        '-','Color',color2_1,'LineWidth',10)
    %%% cell2 Mol2
    plot([2*dx_p 2*dx_p],[0 3],...
        '-','Color',color2_2,'LineWidth',10)
    %%% cell2 Mol3
    plot([3*dx_p 3*dx_p],[0 3],...
        '-','Color',color2_3,'LineWidth',10)
    
    %%% Molecules names %%%%%%%%%%%%%%%%%%%
    %%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    text(1*dx_p,mz1+5,name1_1,'FontSize',fs1,'HorizontalAlignment','Center')
    text(2*dx_p,mz1+5,name1_2,'FontSize',fs1,'HorizontalAlignment','Center')
    text(3*dx_p,mz1+5,name1_3,'FontSize',fs1,'HorizontalAlignment','Center')
    
    %%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    text(1*dx_p,mz2-5,name2_1,'FontSize',fs1,'HorizontalAlignment','Center')
    text(2*dx_p,mz2-5,name2_2,'FontSize',fs1,'HorizontalAlignment','Center')
    text(3*dx_p,mz2-5,name2_3,'FontSize',fs1,'HorizontalAlignment','Center')
    
    %%% Mol sizes %%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    text(1*dx_p,mz1-2-h1_1,[num2str(h1_1),'nm'],...
        'FontSize',fs1,'HorizontalAlignment','Center','Rotation',0)
    text(2*dx_p,mz1-2-h1_2,[num2str(h1_2),'nm'],...
        'FontSize',fs1,'HorizontalAlignment','Center','Rotation',0)
    text(3*dx_p,mz1-2-h1_3,[num2str(h1_3),'nm'],...
        'FontSize',fs1,'HorizontalAlignment','Center','Rotation',0)
    
    %%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    text(1*dx_p,mz2+5+h2_1,[num2str(h2_1),'nm'],...
        'FontSize',fs1,'HorizontalAlignment','Center','Rotation',0)
    text(2*dx_p,mz2+5+h2_2,[num2str(h2_2),'nm'],...
        'FontSize',fs1,'HorizontalAlignment','Center','Rotation',0)
    text(3*dx_p,mz2+5+h2_3,[num2str(h2_3),'nm'],...
        'FontSize',fs1,'HorizontalAlignment','Center','Rotation',0)
    
    %%% Diffusions %%%%%%%%%%%%%%%%%%%%%%%%
    %%% plot diffusions %%%%%%%%%%%%%%%%%%%
    Dscale = 2000;
    d0     = 75;
    y0_D   = mz1 - 13;
    dy_D   = 7;
    
    text(d0,mz1-7,'Diffiusion constants (\mum^2/sec)','FontSize',fs2)
    %%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% cell1 Mol1
    plot([d0 d0+Dscale*D1_1],[y0_D-0*dy_D y0_D-0*dy_D],...
        '-','Color',color1_1,'LineWidth',6)
    %%% cell1 Mol2
    plot([d0 d0+Dscale*D1_2],[y0_D-1*dy_D y0_D-1*dy_D],...
        '-','Color',color1_2,'LineWidth',6)
    %%% cell1 Mol3
    plot([d0 d0+Dscale*D1_3],[y0_D-2*dy_D y0_D-2*dy_D],...
        '-','Color',color1_3,'LineWidth',6)
    
    %%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% cell2 Mol1
    plot([d0 d0+Dscale*D2_1+1],[y0_D-3*dy_D y0_D-3*dy_D],...
        '-','Color',color2_1,'LineWidth',6)
    %%% cell2 Mol2
    plot([d0 d0+Dscale*D2_2+1],[y0_D-4*dy_D y0_D-4*dy_D],...
        '-','Color',color2_2,'LineWidth',6)
    %%% cell2 Mol2
    plot([d0 d0+Dscale*D2_3+1],[y0_D-5*dy_D y0_D-5*dy_D],...
        '-','Color',color2_3,'LineWidth',6)
    
    %%% text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    text(mx_max-20,y0_D-0*dy_D,[num2str(D1_1)],'FontSize',fs1)
    text(mx_max-20,y0_D-1*dy_D,[num2str(D1_2)],'FontSize',fs1)
    text(mx_max-20,y0_D-2*dy_D,[num2str(D1_3)],'FontSize',fs1)
    
    %%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    text(mx_max-20,y0_D-3*dy_D,[num2str(D2_1)],'FontSize',fs1)
    text(mx_max-20,y0_D-4*dy_D,[num2str(D2_2)],'FontSize',fs1)
    text(mx_max-20,y0_D-5*dy_D,[num2str(D2_3)],'FontSize',fs1)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    hold off
%     axis equal
    axis([-10 130 -20 90])
    
    set(gca,'color',0.85*[1 1 1]);
    
    title('Molecules','FontSize',fs4)
    % xlabel('X (nm)','FontSize',12)
    ylabel('Z (nm)','FontSize',fs3)
    set(gca,'xtick',[]);
    set(gca,'xticklabel',[]);
    axis off
    % xtick('none')
    % XTickLabel([''])
     
end % plot_proteins_properties
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% interactions properties %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for plot_interaction_properties = 1:1
    pos2 = [(rx+dx)*1.04 ry+dy-0.05 rw*0.7 rh*1.1]; %0.73
    subplot('Position',pos2)
    
    ux = [   0    1   1   0];
    uy = [-0.5 -0.5 0.5 0.5];
    % plot arrows
    plot([-30 60],[0 0],'-','Color',[0 0 0],'LineWidth',3)
    hold on
    plot([0 0],[0 75],'-','Color',[0 0 0],'LineWidth',3)
    text(-15,80,'Z(nm)','FontSize',fs3)
    text(55,-5,'KT','FontSize',fs3)
    
    %%% plot potentials %%%%%%%%%%%%%%%
    %%% Cell1
    %%% molecule1_1
    %%% spring1
    mol1_1sy  = linspace(13,0,10);
    mol1_1sx0 = (mol1_1sy - max(mol1_1sy)).^2;
    mol1_1sx  = 30*(mol1_1sx0/max(mol1_1sx0)); % !!!!!
    
    %%% molecule1_2
    %%% spring2
    mol1_2sy  = linspace(35,0,10);
    mol1_2sx0 = (mol1_2sy - max(mol1_2sy)).^2;
    mol1_2sx  = 30*(mol1_2sx0/max(mol1_2sx0)); % !!!!!
    
    %%% molecule1_3
    %%% spring3
    mol1_3sy  = linspace(50,0,10);
    mol1_3sx0 = (mol1_3sy - max(mol1_3sy)).^2;
    mol1_3sx  = 30*(mol1_3sx0/max(mol1_3sx0)); % !!!!!
    
    %%% plot
    plot(mol1_1sx,mol1_1sy,'-','Color',color1_1,'LineWidth',4)
    plot(mol1_2sx,mol1_2sy,'-','Color',color1_2,'LineWidth',4)
    plot(mol1_3sx,mol1_3sy,'-','Color',color1_3,'LineWidth',4)
    %%% Cell2
    % well2_1
    mol2_1ux  = ux*U2_1;
    mol2_1uy  = uy*6  + h1_1; %!!!! 
        
    %%% well2_2
    mol2_2ux  = ux*U1_2;
    mol2_2uy  = uy*10 + h1_2; %!!!! 
    
    %%% well2_3
    mol2_3ux  = ux*U2_3;
    mol2_3uy  = uy*10 + h1_3; %!!!!
    
    %%% well PLL
    PLL_ux  = ux*PLL_U;
    PLL_uy  = uy*PLL_bmax + PLL_bmax/2; %!!!!
    
    PLL_bmax       = PLL_parameters.binding_top;
    %%% plot 
    plot(mol2_1ux,mol2_1uy,'-','Color',color2_1,'LineWidth',4)
    plot(mol2_2ux,mol2_2uy,'-','Color',color2_2,'LineWidth',4)
    plot(mol2_3ux,mol2_3uy,'-','Color',color2_3,'LineWidth',4)
    
    plot(PLL_ux  ,PLL_uy  ,'-','Color',PLL_color,'LineWidth',4)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for z_ind = 10:10:70
        text(-7,z_ind,[num2str(z_ind),' -'],'FontSize',fs2)
    end
    for x_ind = -20:10:50
        text(x_ind,-5,[num2str(x_ind),' '],'FontSize',fs2,...
            'HorizontalAlignment','Center')
    end
    hold off
%     axis square
    % axis equal
    axis([-30 60 mz2-20 mz1+20])
    set(gca,'color',0.8*[1 1 1]); % [0.85 0.85 0.85]
    
    title('Interactions','FontSize',fs4)
    xlabel('E (KT)','FontSize',fs4)
    ylabel('Z (nm)','FontSize',fs4)
    axis off
    
end % plot_interaction_properties = 1:1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% membrane properties %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for plot_membrane_properties = 1:1
    pos3 = [rx ry rw*0.85 rh];
    subplot('Position',pos3)

    size_x = parameters.global.array_size_x;
    size_y = parameters.global.array_size_y;
    
    membrane1 = simulation_data.Cell1.membrane;
    membrane2 = simulation_data.Cell2.membrane;
    
    Z0 = parameters.Cells.Cell1.membrane.Z0;
    Z1 = membrane1.Z;
    Z2 = membrane2.Z;
    DZ = Z1 - Z2;
    
    h3 = pcolor(DZ);
    colormap(gray);
    set(h3,'EdgeColor','none')
    colorbar
    caxis([0 Z0])
    
    axis equal
    axis([0 size_x 0 size_y])
    title('Inter membranes distance','FontSize',fs4)
    xlabel('X (pixels)','FontSize',fs3)
    ylabel('Y (pixels)','FontSize',fs3)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% initial conditions %%%%%%%%%%%%%%%%
for plot_initial_conditions = 1:1
    pos4 = [rx+dx ry rw*0.85 rh];
    h4 = subplot('Position',pos4);
%     size_x = parameters.global.array_size_x;
%     size_y = parameters.global.array_size_y;
    
    id_linind_type_Z_E_Cell1 = simulation_data.Cell1.molecules;
    id_linind_type_Z_E_Cell2 = simulation_data.Cell2.molecules;
    %%% Cell1
    idm1        = id_linind_type_Z_E_Cell1(:,1);
    linindm1    = id_linind_type_Z_E_Cell1(:,2);
    typesm1     = id_linind_type_Z_E_Cell1(:,3);
    
    idm1_1      = idm1(typesm1 == 1);
    idm1_2      = idm1(typesm1 == 2);
    idm1_3      = idm1(typesm1 == 3);
    
    linindm1_1  = linindm1(idm1_1);
    linindm1_2  = linindm1(idm1_2);
    linindm1_3  = linindm1(idm1_3);
    
    [X1_1,Y1_1] = ind2sub([size_x,size_y],linindm1_1);
    [X1_2,Y1_2] = ind2sub([size_x,size_y],linindm1_2);
    [X1_3,Y1_3] = ind2sub([size_x,size_y],linindm1_3);
    
    color1_1    = parameters.Cells.Cell1.molecules.type1.color;
    color1_2    = parameters.Cells.Cell1.molecules.type2.color;
    color1_3    = parameters.Cells.Cell1.molecules.type3.color;
    
    %%% Cell2
    idm2        = id_linind_type_Z_E_Cell2(:,1);
    linindm2    = id_linind_type_Z_E_Cell2(:,2);
    typesm2     = id_linind_type_Z_E_Cell2(:,3);
    
    idm2_1      = idm2(typesm2 == 1);
    idm2_2      = idm2(typesm2 == 2);
    idm2_3      = idm2(typesm2 == 3);
    
    linindm2_1  = linindm2(idm2_1);
    linindm2_2  = linindm2(idm2_2);
    linindm2_3  = linindm2(idm2_3);
    
    [X2_1,Y2_1] = ind2sub([size_x,size_y],linindm2_1);
    [X2_2,Y2_2] = ind2sub([size_x,size_y],linindm2_2);
    [X2_3,Y2_3] = ind2sub([size_x,size_y],linindm2_3);
    
    color2_1    = parameters.Cells.Cell2.molecules.type1.color;
    color2_2    = parameters.Cells.Cell2.molecules.type2.color;
    color2_3    = parameters.Cells.Cell2.molecules.type3.color;
    
    %%% plot 
    ms = 5;
    plot(X1_1,Y1_1,'.','MarkerSize',ms,'Color',color1_1)
    hold on
    plot(X1_2,Y1_2,'.','MarkerSize',ms,'Color',color1_2)
    plot(X1_3,Y1_3,'.','MarkerSize',ms,'Color',color1_3)
    
    plot(X2_1,Y2_1,'.','MarkerSize',ms,'Color',color2_1)
    plot(X2_2,Y2_2,'.','MarkerSize',ms,'Color',color2_2)
    plot(X2_3,Y2_3,'.','MarkerSize',ms,'Color',color2_3)
    
    %%% PLL
    if strcmp(parameters.Cells.Cell1.cellname,'Coverslip'); 
        if PLL_parameters.use    % 0/1;
%             frame_x = [0 1 1 0 0];
%             frame_y = [0 0 1 1 0];
%             plot(size_x*frame_x,size_y*frame_y,'-',...
%                 'LineWidth',6,'Color',PLL_color)
            set(h4,'Color',PLL_color)
        end
    end
    hold off
    
    axis equal
    axis([0 size_x 0 size_y])
    
    title('Initial conditions','FontSize',fs4)
    xlabel('X (pixels)','FontSize',fs3)
    ylabel('Y (pixels)','FontSize',fs3)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% h = suptitle('Main');
% set(h,'FontSize',24,'FontWeight','normal');

%}

end