function ui_parameters = ui_main2(parameters,simulation_data)

%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
% ui_main(parameters)
%%% main

ui_parameters.mainfig.x0 = 50;
ui_parameters.mainfig.y0 = 50;
ui_parameters.mainfig.w0 = 1200;
ui_parameters.mainfig.h0 = 900;

x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;
w0 = ui_parameters.mainfig.w0;
h0 = ui_parameters.mainfig.h0;

%%% just testing % plot subplots %%%%%%%%%%%%%%%%%%%%%%%%%%
% f0 = figure('Visible','on','Position',[x0 y0 w0 h0]);
% clf
f0 = figure(1);
set(f0,'Position',[x0 y0 w0 h0])
set(gcf,'Color',0.6*[1 1 1])
% set(f0,'Name','Main panel','NumberTitle','off');

ui_parameters.mainfig.name = f0;
h = suptitle('Simulation properties');
set(h,'FontSize',24,'FontWeight','normal',...
      'VerticalAlignment','Bottom');
%%% main panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pbx  = 3;
pby  = 780;
pbh  = 30;
pbw  = 120;
gapx = 3;
gapy = 3;

fs8  = 8;
fs10 = 10;
fs12 = 12;

%%% main panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mpx = 3;
mpy = 500;
mpw = pbw+10;
mph = 270; % 580;

ui_parameters.mainpanel.right = mpx+mpw;
ui_parameters.mainpanel.top   = mpy+mph;
% ui_parameters.mainpanel.w = w0;
% ui_parameters.mainpanel.h = h0;

main_buttons_panel = uipanel('Parent',f0,...
    'Title','',...
    'Position',[mpx/w0 mpy/h0 mpw/w0 mph/h0],...
    'FontSize',fs10,...
    'visible','on');

%%% global parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% global_parameters_table = globalparameters2table(parameters);
% global_parameters_pb = 
uicontrol('Parent',main_buttons_panel,...
    'Style', 'pushbutton',...
    'String','Global parameters',...
    'Position', [gapx mph-1.25*pbh pbw pbh],...
    'FontSize',fs10,...
    'Callback', 'parameters = ui_global_parameters(ui_parameters,parameters)'); % 'Parent','f0',

%%% Cell1 parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_C1 = 1:1
%%% Cell1 panel %%%%%%%%%%%%%%%%%%%%%%%
%     C1py = 655; %750; %
C1ph = 120;
Cells_panel = uipanel('Parent',main_buttons_panel,...
    'Title','Cells parameters',...
    'Position',[0.01 1-(C1ph+1.3*pbh)/mph 0.98 C1ph/mph],...
    'FontSize',fs10);

%%% Cells Types %%%%%%%%%%%%%%%%%%%%%%%
% pb2 = 
uicontrol('Parent',Cells_panel,...
    'Style', 'pushbutton',...
    'String','Cells types',...
    'Position', [1 C1ph-1.5*(pbh+gapy) pbw-2*gapx pbh],...
    'FontSize',fs10,...
    'Callback', 'parameters = ui_Cells_types(ui_parameters,parameters)'); % 'Parent','f0',
    
%%% membranes %%%%%%%%%%%%%%%%%%%%%%%%%
% pb3
uicontrol('Parent',Cells_panel,...
    'Style', 'pushbutton',...
    'String','Membranes',...
    'Position', [1 C1ph-2.5*(pbh+gapy) pbw-2*gapx pbh],...
    'FontSize',fs10,...
    'Callback', 'parameters = ui_Cells_membranes(ui_parameters,parameters)'); % 

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
% pb4 = 
    uicontrol('Parent',Cells_panel,...
        'Style', 'pushbutton',...
        'String','Molecules',...
        'Position', [1 C1ph-3.5*(pbh+gapy) pbw-2*gapx pbh],...
        'FontSize',fs10,...
        'Callback', 'parameters = ui_Cell_molecule_types(ui_parameters,parameters)'); 
end % fold C1

%%% initial conditions %%%%%%%%%%%%%%%%
% pb5 = 
uicontrol('Parent',main_buttons_panel,...
    'Style', 'pushbutton',...
    'String','Initial locations',...
    'Position', [pbx mph-6*(pbh+gapy) pbw pbh],...
    'FontSize',fs10,...
    'Callback', ['initial_locations = ui_initial_locations(',...
        'ui_parameters,parameters,simulation_data);']); % 'Parent','f0',

%%% analyses %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pb6 = 
uicontrol('Parent',main_buttons_panel,...
    'Style', 'pushbutton',...
    'String','Analyses',...
    'Position', [pbx mph-7*(pbh+gapy) pbw pbh],...
    'FontSize',fs10,...
    'Callback', '[]'); % 'Parent','f0',

%%% save what %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% pb7 = 
uicontrol('Parent',main_buttons_panel,...
    'Style', 'pushbutton',...
    'String','Run',...
    'Position', [pbx mph-8*(pbh+gapy) pbw pbh],...
    'FontSize',fs10,...
    'Callback', 'ui_save_what_checkbox'); % 'Parent','f0',

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot_ui_main(parameters,simulation_data);

end


