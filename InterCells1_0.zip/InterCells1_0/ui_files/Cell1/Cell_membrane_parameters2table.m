function table_Cell_membrane = Cell_membrane_parameters2table(Cell_membrane_parameters)

%%% rigidity
table_Cell_membrane{1,1}  = 'Membrane rigidity (KT)';
table_Cell_membrane{2,1}  = 'Membrane min rigidity (KT)';
table_Cell_membrane{3,1}  = 'Membrane max rigidity (KT)';
table_Cell_membrane{4,1}  = 'Membrane local rigidity (0/1)';
%%% diffusivity
table_Cell_membrane{6,1}  = 'Membrane diffusivity (0-1)';
table_Cell_membrane{7,1}  = 'Membrane min diffusivity (KT)';
table_Cell_membrane{8,1}  = 'Membrane max diffusivity (KT)';
table_Cell_membrane{9,1}  = 'Membrane local diffusivity (0/1)';
%%% Z
table_Cell_membrane{11,1} = 'Initial menbrane Z (nm)';
table_Cell_membrane{12,1} = 'Min menbrane Z (nm)';
table_Cell_membrane{13,1} = 'Max menbrane Z (nm)';
table_Cell_membrane{14,1} = 'Sigma dz (nm)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
table_Cell_membrane{1,2}  = Cell_membrane_parameters.rigidity;
table_Cell_membrane{2,2}  = Cell_membrane_parameters.min_rigidity;
table_Cell_membrane{3,2}  = Cell_membrane_parameters.max_rigidity;
table_Cell_membrane{4,2}  = Cell_membrane_parameters.local_rigidity;

table_Cell_membrane{6,2}  = Cell_membrane_parameters.diffusivity;
table_Cell_membrane{7,2}  = Cell_membrane_parameters.min_diffusivity;
table_Cell_membrane{8,2}  = Cell_membrane_parameters.max_diffusivity;
table_Cell_membrane{9,2}  = Cell_membrane_parameters.local_diffusivity;

table_Cell_membrane{11,2} = Cell_membrane_parameters.Z0;
table_Cell_membrane{12,2} = Cell_membrane_parameters.min_Z;
table_Cell_membrane{13,2} = Cell_membrane_parameters.max_Z;
table_Cell_membrane{14,2} = Cell_membrane_parameters.dz;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table_Cell_membrane(:,3)  = table_Cell_membrane(:,2);

















