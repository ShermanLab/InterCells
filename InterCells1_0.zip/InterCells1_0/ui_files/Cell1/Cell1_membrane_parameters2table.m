function table_Cell1_membrane = Cell1_membrane_parameters2table(parameters)

% table_Cell1 = cell(6,3);
%%% rigidity
table_Cell1_membrane{1,1}  = 'Membrane rigidity (KT)';
table_Cell1_membrane{2,1}  = 'Membrane min rigidity (KT)';
table_Cell1_membrane{3,1}  = 'Membrane max rigidity (KT)';
table_Cell1_membrane{4,1}  = 'Membrane local rigidity (0/1)';

%%% diffusivity
table_Cell1_membrane{6,1}  = 'Membrane diffusivity (0-1)';
table_Cell1_membrane{7,1}  = 'Membrane min diffusivity (KT)';
table_Cell1_membrane{8,1}  = 'Membrane max diffusivity (KT)';
table_Cell1_membrane{9,1}  = 'Membrane local diffusivity (0/1)';

%%% Z
table_Cell1_membrane{11,1} = 'Initial menbrane Z (nm)';
table_Cell1_membrane{12,1} = 'Min menbrane Z (nm)';
table_Cell1_membrane{13,1} = 'Max menbrane Z (nm)';
table_Cell1_membrane{14,1} = 'Sigma dz (nm)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
table_Cell1_membrane{1,2}  = parameters.Cells.Cell1.membrane.rigidity;
table_Cell1_membrane{2,2}  = parameters.Cells.Cell1.membrane.min_rigidity;
table_Cell1_membrane{3,2}  = parameters.Cells.Cell1.membrane.max_rigidity;
table_Cell1_membrane{4,2}  = parameters.Cells.Cell1.membrane.local_rigidity;

table_Cell1_membrane{6,2}  = parameters.Cells.Cell1.membrane.diffusivity;
table_Cell1_membrane{7,2}  = parameters.Cells.Cell1.membrane.min_diffusivity;
table_Cell1_membrane{8,2}  = parameters.Cells.Cell1.membrane.max_diffusivity;
table_Cell1_membrane{9,2}  = parameters.Cells.Cell1.membrane.local_diffusivity;

table_Cell1_membrane{11,2} = parameters.Cells.Cell1.membrane.Z0;
table_Cell1_membrane{12,2} = parameters.Cells.Cell1.membrane.min_Z;
table_Cell1_membrane{13,2} = parameters.Cells.Cell1.membrane.max_Z;
table_Cell1_membrane{14,2} = parameters.Cells.Cell1.membrane.dz;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table_Cell1_membrane(:,3)  = table_Cell1_membrane(:,2);

















