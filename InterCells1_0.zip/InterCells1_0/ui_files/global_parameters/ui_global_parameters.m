function parameters = ui_global_parameters(ui_parameters,parameters) 

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : global_parameters_table
called by  : ui_main
calling    : globalparameters2table
description: make tabel from parameters.global 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% global parameters panel setup %%%%%
for fold1 = 1:1
    %%% craete global parameters table
    global_parameters_table = globalparameters2table(parameters);
    dat   = global_parameters_table;
    nrows = size(dat,1);
    
    %%% getting ui_parameters %%%%%%%%%
    x0 = ui_parameters.mainfig.x0;
    y0 = ui_parameters.mainfig.y0;

    fs1  = 8;
    fs2 = 10;
    fs3 = 12;
    
    %%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
    rowh = 18;
    pw   = 305;
    ph   = nrows*rowh+100; 
    px   = x0+150;
    py   = y0+500;
    
    gapx = 2;
     
    p = figure(3);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');

end
%%% title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol('Parent',p,...
    'Style','text',...
    'String','Global parameters','FontSize',fs3,...
    'Position',[0 ph-30 pw 30]);

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1
    columnname     = {'Name', 'Default', 'New',};
    columnformat   = {'char','numeric', 'numeric'};
    columnwidth    = {150,60,60};
    columneditable = [false false true]; 

    tx   = 0;
    ty   = 25;
    tw   = pw;
    th   = ph-65;   
    
t = uitable('Parent',p,...
        'Data',dat,...
        'ColumnName',columnname,...
        'ColumnFormat',columnformat,...
        'ColumnWidth',columnwidth,...
        'ColumnEditable',columneditable,...
        'Position',[tx ty tw th]); 
end

%%% Cencel %%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1

    Cancel_pbx = 151;
    Cancel_pby = 3;
    pbw = 50;
    pbh = 20;

Close_pb = uicontrol('Parent',p,...
        'Style', 'pushbutton',...
        'String','Cancel',...
        'Position', [Cancel_pbx Cancel_pby pbw pbh],...
        'FontSize',fs1,...
        'Callback','close(3)'); 
end

%%% Apply %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1
    Apply_pbx = Cancel_pbx + pbw + gapx;
    Apply_pby = 3;
%     Apply_pb = 
    uicontrol('Parent',p,...
        'Style', 'pushbutton',...
        'String','Apply',...
        'Position', [Apply_pbx Apply_pby pbw pbh],...
        'FontSize',fs1,...
        'Callback',@update_global_parameters); 
end

%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold1 = 1:1

    Ok_pbx = Apply_pbx + pbw + gapx; 
    Ok_pby = 3; 
%     Ok_pb = 
    uicontrol('Parent',p,...
        'Style', 'pushbutton',...
        'String','Close',...
        'Position', [Ok_pbx Ok_pby pbw pbh],...
        'FontSize',fs1,...
        'Callback', 'close(3)'); 
end

table = get(t,'Data');

function update_global_parameters(~,~)
    table = get(t,'Data');
    global_parameters = table2globalparameters(parameters,table);
    parameters.global = global_parameters;
    uiresume
    figure(1)
    plot_ui_main(parameters,[])
%     uiresume
end

uiwait
end













