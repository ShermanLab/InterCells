function global_parameters_table = globalparameters2table(parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : global_parameters_table
called by  : ui_main
calling    : none
description: 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for fold = 1:1
    %%% Name (units) %%%%%%%%%%%%%%%%%%
    %%% array
    global_parameters_table{1,1}  = 'Array size x (pixels)';
    global_parameters_table{2,1}  = 'Array size y (pixels)';
    global_parameters_table{3,1}  = 'Pixel size (nm)';
    %%% times
    global_parameters_table{5,1}  = 'Iteration time (sec)';
    global_parameters_table{6,1}  = 'Simulation time (sec)';
    global_parameters_table{7,1}  = 'Experiment frame time (sec)';
    global_parameters_table{8,1}  = 'Save rate (every N iterations)';
    %%% dynamics
    global_parameters_table{10,1} = 'Metropolis steps (2/1)';
    global_parameters_table{11,1} = 'E gravity (KT)';
    global_parameters_table{12,1} = 'Use gravity (0/1)';
    global_parameters_table{13,1} = 'Stick time (sec)';
    %%% runs 
    global_parameters_table{14,1} = 'Number of runs (N)';
    
    %%% Default %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% array
    global_parameters_table{1,2}  = parameters.global.array_size_x;
    global_parameters_table{2,2}  = parameters.global.array_size_y;
    global_parameters_table{3,2}  = parameters.global.pixel_size;
    %%% times
    global_parameters_table{5,2}  = parameters.global.iteration_time;
    global_parameters_table{6,2}  = parameters.global.simulation_time;
    global_parameters_table{7,2}  = parameters.global.experiment_frame_time;
    global_parameters_table{8,2}  = parameters.global.save_rate;
    %%% dynamics
    global_parameters_table{10,2} = parameters.global.metropolis_steps;
    global_parameters_table{11,2} = parameters.global.e_gravity;
    global_parameters_table{12,2} = parameters.global.use_gravity;
    global_parameters_table{13,2} = parameters.global.stick_time;
    %%% runs
    global_parameters_table{14,2} = parameters.global.runs;
    
    %%% New %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    global_parameters_table(:,3) = global_parameters_table(:,2);
end
end

    
    


