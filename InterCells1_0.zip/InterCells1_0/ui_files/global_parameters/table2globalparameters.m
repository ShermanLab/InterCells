function global_parameters = table2globalparameters(parameters,table)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters, table
output     : global_parameters
called by  : ui_main
calling    : none
description: 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% array
parameters.global.array_size_x          = table{1,3};
parameters.global.array_size_y          = table{2,3};
parameters.global.pixel_size            = table{3,3};
%%% times
parameters.global.iteration_time        = table{5,3};
parameters.global.simulation_time       = table{6,3};
parameters.global.experiment_frame_time = table{7,3};
parameters.global.save_rate             = table{8,3};
%%% dynamics
parameters.global.metropolis_steps      = table{10,3};
parameters.global.e_gravity             = table{11,3};
parameters.global.use_gravity           = table{12,3};
parameters.global.stick_time            = table{13,3};
%%% runs
parameters.global.runs                  = table{14,3};

global_parameters = parameters.global;
end
