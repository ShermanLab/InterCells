function table_membrane = membrane_parameters2table(parameters,Cell)

Cell
% table_Cell1 = cell(6,3);
%%% rigidity
table_membrane{1,1}  = 'Membrane rigidity (KT)';
table_membrane{2,1}  = 'Membrane min rigidity (KT)';
table_membrane{3,1}  = 'Membrane max rigidity (KT)';
table_membrane{4,1}  = 'Membrane local rigidity (0/1)';

%%% diffusivity
table_membrane{6,1}  = 'Membrane diffusivity (0-1)';
table_membrane{7,1}  = 'Membrane min diffusivity (KT)';
table_membrane{8,1}  = 'Membrane max diffusivity (KT)';
table_membrane{9,1}  = 'Membrane local diffusivity (0/1)';

%%% Z
table_membrane{11,1} = 'Initial menbrane Z (nm)';
table_membrane{12,1} = 'Min menbrane Z (nm)';
table_membrane{13,1} = 'Max menbrane Z (nm)';
table_membrane{14,1} = 'Sigma dz (nm)';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
table_membrane{1,2}  = parameters.Cells.Cell.membrane.rigidity;
table_membrane{2,2}  = parameters.Cells.Cell2.membrane.min_rigidity;
table_membrane{3,2}  = parameters.Cells.Cell2.membrane.max_rigidity;
table_membrane{4,2}  = parameters.Cells.Cell2.membrane.local_rigidity;

table_membrane{6,2}  = parameters.Cells.Cell2.membrane.diffusivity;
table_membrane{7,2}  = parameters.Cells.Cell2.membrane.min_diffusivity;
table_membrane{8,2}  = parameters.Cells.Cell2.membrane.max_diffusivity;
table_membrane{9,2}  = parameters.Cells.Cell2.membrane.local_diffusivity;

table_membrane{11,2} = parameters.Cells.Cell2.membrane.Z0;
table_membrane{12,2} = parameters.Cells.Cell2.membrane.min_Z;
table_membrane{13,2} = parameters.Cells.Cell2.membrane.max_Z;
table_membrane{14,2} = parameters.Cells.Cell2.membrane.dz;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table_membrane(:,3)  = table_membrane(:,2);

















