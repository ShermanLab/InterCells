function Cell_membrane_parameters = ui_Cell_membrane_table(...
    ui_parameters,Cell_parameters)

%%% Cell_parameters to Cell_membrane_parameters
Cell_membrane_parameters = Cell_parameters.membrane;
Cell_name                = Cell_parameters.cellname;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table_Cell_membrane = Cell_membrane_parameters2table(Cell_membrane_parameters);

dat            = table_Cell_membrane;
nrows          = size(dat,1);
%%% 

columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {180,60,60};
columneditable = [false false true]; 

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;

rowh = 18;
pw   = 335;
ph   = nrows*rowh+90; % nrows*rowh+80
px   = x0+150;
py   = y0+408;

% gapx = 2;
% gapy = 2;

fs8  = 8;
% fs10 = 10;
% fs12 = 12;

p = figure(17);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Cell membrane table','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
text1 = uicontrol('Parent',p,...
        'Style', 'Text',...
        'String',[Cell_name, ' membrane parameters table'],...
        'Position', [0 ph-30 350 30],...
        'FontSize',14); 

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
gapx = 3;
gapy = 3;
tw   = 350;
th   = nrows*rowh+57;

t = uitable('Parent',p,'Data',dat,...
            'ColumnName',columnname,...
            'ColumnFormat',columnformat,...
            'ColumnWidth',columnwidth,...
            'ColumnEditable',columneditable,...
            'Position',[0 0 tw th]);

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pbx = 151;
pbw = 50;
pbh = 20;

Cancel_pb = uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Cancel',...
    'Position', [Cancel_pbx gapy pbw pbh],...
    'FontSize',fs8,...
    'Callback','close(17)'); 


%%% Apply %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Apply_pbx = Cancel_pbx + pbw + gapx;
Apply_pby = 3;

Apply_pb = uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Apply',...
    'Position', [Apply_pbx gapy pbw pbh],...
    'FontSize',fs8,...
    'Callback',@update_membrane_parameters); 

%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Close_pbx = Apply_pbx + pbw + gapx; 
Close_pb = uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Close',...
    'Position', [Close_pbx gapy pbw pbh],...
    'FontSize',fs8,...
    'Callback', 'close(17)'); 


%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align([text1,t],'Left','Fixed',0)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table = get(t,'Data');
membrane_parameters = table2membraneparameters(table);
Cell_membrane_parameters = membrane_parameters;
    
function membrane_parameters = update_membrane_parameters(~,~)
    table = get(t,'Data');
    membrane_parameters = table2membraneparameters(table);
    Cell_membrane_parameters = membrane_parameters;
    
    uiresume
end
uiwait
end






