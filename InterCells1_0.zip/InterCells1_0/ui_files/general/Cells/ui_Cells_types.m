function parameters = ui_Cells_types(ui_parameters,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : ui_parameters,
             paramters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;
%%%

fs1  = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 2;
gapy = 2;

px   = x0+170;
py   = y0+610;
pw   = 110;
ph   = 200; %150; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 20;

p = figure(14);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');

rbh   = 25;

bg1 = uibuttongroup('Parent',p,...
    'visible','on',...
    'Position',[0 0.65 1 1]);

text1 = uicontrol('Parent',p,...
    'Style','text',...
    'String','Cell1 type',...
    'FontSize',fs3,...
    'BackgroundColor',[1 1 1],...
    'Position',[2 ph-30 pw rbh]);

rb1_1 = uicontrol('Parent',bg1,...
    'Style','Radio',...
    'String','T-cell',...
    'FontSize',fs2,...
    'Position',[gapx 10 pw rbh]);

Cell1_name = get(get(bg1,'SelectedObject'),'String');
parameters.Cells.Cell1.cellname = Cell1_name;

%%% title2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bg2 = uibuttongroup('Parent',p,...
    'visible','on',...
    'Position',[0 0 1 0.65]);

text2 = uicontrol('Parent',bg2,...
    'Style','text',...
    'String','Cell2 type',...
    'FontSize',fs3,...
    'ForegroundColor',[1 1 1],...
    'BackgroundColor',0.2*[1 1 1],...
    'Position',[2 95 pw 30]);

rb2_1 = uicontrol(bg2,'Style','Radio',...
    'String','Coverslip',...
    'FontSize',fs2,...
    'Position',[gapx 60 pw rbh]);

rb2_2 = uicontrol(bg2,'Style','Radio',...
    'String','APC',...
    'FontSize',fs2,...
    'Position',[gapx 30 pw rbh]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(bg2,'Style','pushbutton',...
    'String','Apply',...
    'FontSize',fs1,...
    'Position',[pbx pby pbw pbh],...
    'Callback',@button_callback); 

uicontrol(bg2,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[pbx+pbw+gapx pby pbw pbh],...
    'Callback','close(14)'); 

Cell2_name = get(get(bg2,'SelectedObject'),'String');
parameters.Cells.Cell2.cellname = Cell2_name;

function button_callback(~,~) 
    Cell1_name = get(get(bg1,'SelectedObject'),'String');
    Cell2_name = get(get(bg2,'SelectedObject'),'String');
    parameters.Cells.Cell1.cellname = Cell1_name;
    parameters.Cells.Cell2.cellname = Cell2_name;
    
    uiresume
end

uiwait
end










