function molecule_type_parameters = table2moleculeparameters(table)

%%% 
molecule_type.name                = table{1,3};
molecule_type.lateral_size        = table{2,3};
molecule_type.vertical_size       = table{3,3};
%%% interactions
molecule_type.binding_top         = table{5,3};
molecule_type.binding_bottom      = table{6,3};
molecule_type.binding_strength    = table{7,3};
molecule_type.spring_k            = table{8,3};
molecule_type.force_z             = table{9,3};
%%% clusters prperties
molecule_type.diffusion_constant  = table{11,3};
molecule_type.global_density      = table{12,3};
molecule_type.cluster_density     = table{13,3};
molecule_type.density_of_clusters = table{14,3};
%%% 

molecule_type_parameters = molecule_type;
end


