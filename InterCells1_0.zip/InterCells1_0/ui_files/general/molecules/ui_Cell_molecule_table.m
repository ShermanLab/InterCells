function Cell_Molecule_parameters = ui_Cell_molecule_table(...
    ui_parameters,Cell_Molecule_parameters)

table_Cell_molecule = Cell_molecule_parameters2table(Cell_Molecule_parameters);

dat            = table_Cell_molecule;
nrows          = size(dat,1);
%%% 
mcolor           = Cell_Molecule_parameters.color;

% f0 = ui_parameters.mainfig.name;
columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {180,60,60};
columneditable = [false false true]; 
% pp = ui_parameters;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
x0 = ui_parameters.mainfig.x0;
y0 = ui_parameters.mainfig.y0;

rowh = 18;
pw   = 335;
ph   = nrows*rowh+90; % nrows*rowh+80
px   = x0+150;
py   = y0+408;

pbw = 50;
pbh = 20;
% gapx = 2;
fs8  = 8;
% fs10 = 10;
% fs12 = 12;

p = figure(17);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name',['Cell molecule table'],'NumberTitle','off');

%%% text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% edit color?
text1 = uicontrol('Parent',p,...
        'Style', 'Text',...
        'String',' ',...
        'Position', [0 ph-30 350 30],...
        'BackgroundColor',mcolor,...
        'FontSize',14); 

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
gapx = 3;
gapy = 3;
% tx   = 200; %150+6+360;
% ty   = 417; %156;
tw   = 350;
th   = nrows*rowh+57;

t = uitable('Parent',p,'Data',dat,...
            'ColumnName',columnname,...
            'ColumnFormat',columnformat,...
            'ColumnWidth',columnwidth,...
            'ColumnEditable',columneditable,...
            'Position',[0 0 tw th]); %[tx ty tw th]

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pbx = 151;

%     Cancel_pb = 
uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Cancel',...
    'Position', [Cancel_pbx gapy pbw pbh],...
    'FontSize',fs8,...
    'Callback','close(17)'); 

%%% Apply %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Apply_pbx = Cancel_pbx + pbw + gapx;

%     Apply_pb = 
uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Apply',...
    'Position', [Apply_pbx gapy pbw pbh],...
    'FontSize',fs8,...
    'Callback',@update_molecule_parameters); 


%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Close_pbx = Apply_pbx + pbw + gapx; 


uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Close',...
    'Position', [Close_pbx gapy pbw pbh],...
    'FontSize',fs8,...
    'Callback', 'close(17)'); 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% table = get(t,'Data');
% molecule_type_parameters = table2moleculeparameters(table);
% Cell_Molecule_parameters = molecule_type_parameters;
% Cell_Molecule_parameters.color = mcolor;

% Cell_Molecule_parameters.name  = mname;
    
function update_molecule_parameters(~,~)
    table = get(t,'Data');
    molecule_type_parameters = table2moleculeparameters(table);
    Cell_Molecule_parameters = molecule_type_parameters;
    Cell_Molecule_parameters.color = mcolor;
    uiresume
end


uiwait
end
















