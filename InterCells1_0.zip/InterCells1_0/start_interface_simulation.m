% start_interface_simulation

% input      : none
% output     :
% called by  : none
% calling    :
% description:

clear %all
close all
clc
%%% initializing parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_parameters = defaultparameters();
library            = make_library(default_parameters);
parameters         = default_parameters;

parameters = moltypenames2moltypenumbers(parameters);
% assigns 'type#' instead of molecule name.
% from here the molecules.'name' in 'parameters' do not have specific names.
% the original names are kept in 'library'.

%%% choose cells %%%%%%%%%%%%%%%%%%%%%%
Cell1_name = 'Tcell'; 
Cell2_name = 'Coverslip';
parameters = cellsnames2cellsnumbers(parameters,Cell1_name,Cell2_name);

%%% initial simulation data / temp %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initial_Tcell_data     = test_Tcell_data(default_parameters);
initial_Coverslip_data = test_Coverslip_data(default_parameters);

%%% set initial_simulation_data %%%%%%%
simulation_data.Cell1 = initial_Tcell_data;
simulation_data.Cell2 = initial_Coverslip_data;
simulation_data.iter  = 0;

simulation_data.Cell1.linind_initial_locations = [];
simulation_data.Cell1.initial_locations_array  = initial_Tcell_data.locations_array; 
%zeros(size(simulation_data.Cell1.membrane.Z));

simulation_data.Cell2.linind_initial_locations = [];
simulation_data.Cell2.initial_locations_array  = initial_Coverslip_data.locations_array; 
%zeros(size(simulation_data.Cell1.membrane.Z));

initial_simulation_data = simulation_data;
%%% plot initial_simulation_data %%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% start gui %%%%%%%%%%%%%%%%%%%%%%%%%
use_gui = 0; 
if use_gui
    [parameters,ui_parameters] = ui_main(parameters,simulation_data);
    parameters     = out_parameters;
end
% pause
plot_simulation_data(initial_simulation_data,parameters);

%%% running the simulation %%%%%%%%%%%%
run_simulation

%%% open analyses options %%%%%%%%%%%%%
ui_analyses

%%% run analyses %%%%%%%%%%%%%%%%%%%%%%
run_analyses













