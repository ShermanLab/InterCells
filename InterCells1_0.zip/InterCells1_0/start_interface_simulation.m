% start_interface_simulation

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : parameters,
             ui_parameters
called by  : none
calling    : defaultparameters(),
             make_library(default_parameters)
             moltypenames2moltypenumbers(parameters)
             cellsnames2cellsnumbers(parameters,Cell1_name,Cell2_name)
             test_Tcell_data(parameters)
             test_Coverslip_data(parameters)
             ui_main(parameters,simulation_data)
description:
This file initializes the simulation. It generates the parameters
pform pre-defined default parameters. After defining the
parameters it opens the Graphic User Interface (GUI) main panel. 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear %all
close all
clc

%%% initializing parameters %%%%%%%%%%%
default_parameters = defaultparameters();
library            = make_library(default_parameters);
parameters         = default_parameters;

parameters = moltypenames2moltypenumbers(parameters);

% assigns 'type#' instead of molecule name.
% from here the molecules.'name' in 'parameters' 
% do not have specific names.
% the original names are kept in 'library'.

%%% choose cells %%%%%%%%%%%%%%%%%%%%%%
Cell1_name = 'Tcell'; 
Cell2_name = 'Coverslip';
parameters = cellsnames2cellsnumbers(parameters,Cell1_name,Cell2_name);

%%% initial simulation data / temp %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initial_Cell1_data = make_initial_Cell1_data(parameters);
initial_Cell2_data = make_initial_Cell2_data(parameters);

%%% set initial_simulation_data %%%%%%%
simulation_data.Cell1 = initial_Cell1_data;
simulation_data.Cell2 = initial_Cell2_data;
simulation_data.iter  = 0;

%%% initial simulation_data Cell1 %%%%%
simulation_data.Cell1.linind_initial_locations = [];
simulation_data.Cell1.initial_locations_array  = initial_Cell1_data.locations_array; 

%%% initial simulation_data Cell2 %%%%%
simulation_data.Cell2.linind_initial_locations = [];
simulation_data.Cell2.initial_locations_array  = initial_Cell2_data.locations_array; 

%%% plotting_options %%%%%%%%%%%%%%%%%%
plotting_options.molecules_and_membranes   = 1;
plotting_options.molecules_energy          = 0;
plotting_options.membrane_energy           = 0;
plotting_options.membrane_rigidity         = 0;

%%% analyses_options %%%%%%%%%%%%%%%%%%
analyses_options.pair_correlation_function = 1;
analyses_options.dilations                 = 0;
analyses_options.minkowski_functionals     = 0;
analyses_options.clustering                = 0;
analyses_options.entropy                   = 0;

%%% start gui %%%%%%%%%%%%%%%%%%%%%%%%%
use_gui = 1; 
if use_gui
    [parameters,ui_parameters] = ui_main(parameters,simulation_data);
end














