% gui_lfa
% use gui to update parameters

%%% makes a table from parameters.Tcell.lfa %%%%%%%%%%%%%%% 
table_lfa_names_data = lfaparameters2table(parameters);

%%% returns tcr parameters that are changed by the gui %%%%
gui_lfa_out = gui_LFA_properties();

%%% return parameters.Tcell.lfa with the updated parameters
lfa_parameters_out = lfatable2parameters(gui_lfa_out,parameters);

%%% assigns the new parameters to the default parameters %%
parameters.Tcell.lfa = lfa_parameters_out;