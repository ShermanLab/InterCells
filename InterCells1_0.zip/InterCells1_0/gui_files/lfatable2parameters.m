function lfa_parameters_out = lfatable2parameters(gui_lfa_out,parameters)

for tcr = 1:1
    
    parameters.Tcell.lfa.color(1)           = gui_lfa_out{1};
    parameters.Tcell.lfa.color(2)           = gui_lfa_out{2};
    parameters.Tcell.lfa.color(3)           = gui_lfa_out{3};
    parameters.Tcell.lfa.lateral_size       = gui_lfa_out{4};
    parameters.Tcell.lfa.vertical_size      = gui_lfa_out{5};
    parameters.Tcell.lfa.binding_top        = gui_lfa_out{6};
    parameters.Tcell.lfa.binding_bottom     = gui_lfa_out{7};
    parameters.Tcell.lfa.binding_strength   = gui_lfa_out{8};
    parameters.Tcell.lfa.spring_k           = gui_lfa_out{9};
    parameters.Tcell.lfa.area_patches_5     = gui_lfa_out{10};
    parameters.Tcell.lfa.area_patches_10    = gui_lfa_out{11};
    parameters.Tcell.lfa.diffusion_constant = gui_lfa_out{12};
    parameters.Tcell.lfa.density            = gui_lfa_out{13};
    
    lfa_parameters_out = parameters.Tcell.lfa;
end
end