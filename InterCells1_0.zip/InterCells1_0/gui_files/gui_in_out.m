function varargout = gui_in_out(varargin)
% GUI_IN_OUT MATLAB code for gui_in_out.fig
%      GUI_IN_OUT, by itself, creates a new GUI_IN_OUT or raises the existing
%      singleton*.
%
%      H = GUI_IN_OUT returns the handle to a new GUI_IN_OUT or the handle to
%      the existing singleton*.
%
%      GUI_IN_OUT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_IN_OUT.M with the given input arguments.
%
%      GUI_IN_OUT('Property','Value',...) creates a new GUI_IN_OUT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before gui_in_out_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to gui_in_out_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help gui_in_out

% Last Modified by GUIDE v2.5 26-Jul-2017 15:45:46

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @gui_in_out_OpeningFcn, ...
                   'gui_OutputFcn',  @gui_in_out_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before gui_in_out is made visible.
function gui_in_out_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to gui_in_out (see VARARGIN)

% Choose default command line output for gui_in_out
handles.output = hObject;
handles.in_parameters = varargin{1};
handles.tcr_vertical_size = handles.in_parameters.tcr.vertical_size;
set(handles.edit1,'string',num2str(handles.tcr_vertical_size));
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes gui_in_out wait for user response (see UIRESUME)
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = gui_in_out_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
handles = guidata(hObject);
% set(handles.edit1,'String',unm2str(handles.invar1));
new1 = str2double(get(handles.edit1,'String'));
handles.output = new1;
disp(handles.output)
guidata(hObject,handles);
uiresume

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(handles.figure1)
