function table_lfa_names_data = tablelfadata(parameters)

%%% TCR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for tcr = 1:1
    table_lfa_names_data = cell(16,3);
    
    table_lfa_names_data{1,1}  = 'Color (red)';
    table_lfa_names_data{2,1}  = 'Color (green)';
    table_lfa_names_data{3,1}  = 'Color (blue)';
    table_lfa_names_data{4,1}  = 'Lateral size (nm)';
    table_lfa_names_data{5,1}  = 'Vertical size (nm)';
    table_lfa_names_data{6,1}  = 'Binding top (nm)';
    table_lfa_names_data{7,1}  = 'Binding bottom (nm)';
    table_lfa_names_data{8,1}  = 'Binding strength (KT)';
    table_lfa_names_data{9,1}  = 'Spring strength (KT/nm^2)';
    table_lfa_names_data{10,1} = 'Area 5nm (pixels)';
    table_lfa_names_data{11,1} = 'Area 10nm (pixels)';
    table_lfa_names_data{12,1} = 'Diffusion constant (um^2/sec)';
    table_lfa_names_data{13,1} = 'Density (N/um^2)';
    table_lfa_names_data{14,1} = 'Number (N)';
    
    table_lfa_names_data{1,2}  = parameters.lfa.color(1);
    table_lfa_names_data{2,2}  = parameters.lfa.color(2);
    table_lfa_names_data{3,2}  = parameters.lfa.color(3);
    table_lfa_names_data{4,2}  = parameters.lfa.lateral_size;
    table_lfa_names_data{5,2}  = parameters.lfa.vertical_size;
    table_lfa_names_data{6,2}  = parameters.lfa.binding_top;
    table_lfa_names_data{7,2}  = parameters.lfa.binding_bottom;
    table_lfa_names_data{8,2}  = parameters.lfa.binding_strength;
    table_lfa_names_data{9,2}  = parameters.lfa.spring_k;
    table_lfa_names_data{10,2} = parameters.lfa.area_patches_5;
    table_lfa_names_data{11,2} = parameters.lfa.area_patches_10;
    table_lfa_names_data{12,2} = parameters.lfa.diffusion_constant;
    table_lfa_names_data{13,2} = parameters.lfa.density;
    table_lfa_names_data{14,2} = parameters.lfa.N;
    
    
    table_lfa_names_data{1,3}  = parameters.lfa.color(1);
    table_lfa_names_data{2,3}  = parameters.lfa.color(2);
    table_lfa_names_data{3,3}  = parameters.lfa.color(3);
    table_lfa_names_data{4,3}  = parameters.lfa.lateral_size;
    table_lfa_names_data{5,3}  = parameters.lfa.vertical_size;
    table_lfa_names_data{6,3}  = parameters.lfa.binding_top;
    table_lfa_names_data{7,3}  = parameters.lfa.binding_bottom;
    table_lfa_names_data{8,3}  = parameters.lfa.binding_strength;
    table_lfa_names_data{9,3}  = parameters.lfa.spring_k;
    table_lfa_names_data{10,3} = parameters.lfa.area_patches_5;
    table_lfa_names_data{11,3} = parameters.lfa.area_patches_10;
    table_lfa_names_data{12,3} = parameters.lfa.diffusion_constant;
    table_lfa_names_data{13,3} = parameters.lfa.density;
    table_lfa_names_data{14,3} = parameters.lfa.N;
    
end
end





