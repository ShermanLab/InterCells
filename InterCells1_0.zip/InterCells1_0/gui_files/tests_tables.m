% tests_tables
f = figure;
d = randn(10,3); % Make some random data to add
t = uitable(f);
set(t,'Data',d); % Use the set command to change the uitable properties.
set(t,'ColumnName',{'a';'b';'c'})

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

f = figure('Position',[200 200 400 150]);
dat = rand(3); 
cnames = {'X-Data','Y-Data','Z-Data'};
rnames = {'First','Second','Third'};
t = uitable('Parent',f,'Data',dat,'ColumnName',cnames,... 
            'RowName',rnames,'Position',[20 20 360 100]);


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%







