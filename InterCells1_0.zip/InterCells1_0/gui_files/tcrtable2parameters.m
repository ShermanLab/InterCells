function tcr_parameters_out = tcrtable2parameters(gui_tcr_out,parameters)

for tcr = 1:1
    
    parameters.Tcell.tcr.color(1)           = gui_tcr_out{1};
    parameters.Tcell.tcr.color(2)           = gui_tcr_out{2};
    parameters.Tcell.tcr.color(3)           = gui_tcr_out{3};
    parameters.Tcell.tcr.lateral_size       = gui_tcr_out{4};
    parameters.Tcell.tcr.vertical_size      = gui_tcr_out{5};
    parameters.Tcell.tcr.binding_top        = gui_tcr_out{6};
    parameters.Tcell.tcr.binding_bottom     = gui_tcr_out{7};
    parameters.Tcell.tcr.binding_strength   = gui_tcr_out{8};
    parameters.Tcell.tcr.spring_k           = gui_tcr_out{9};
    parameters.Tcell.tcr.area_patches_5     = gui_tcr_out{10};
    parameters.Tcell.tcr.area_patches_10    = gui_tcr_out{11};
    parameters.Tcell.tcr.diffusion_constant = gui_tcr_out{12};
    parameters.Tcell.tcr.density            = gui_tcr_out{13};
    
    tcr_parameters_out = parameters.Tcell.tcr;
end
end