function updated_id_linind_type_Z_E0 = updatetcelldata(id_linind_type_Z_E_T_cell,new_linind_TCR,L,parameters)

% gets the original T_cell data and the new_linind_TCR. It creates new
% id's for the T_cell. In the first N(TCRs) places it puts the new TCR
% data and in the following places the data of the other T_cell proteins.

type_tcr   = parameters.tcr.type_number;
type_lfa   = parameters.lfa.type_number;
type_cd45  = parameters.cd45.type_number;
type_cd43  = parameters.cd43.type_number;
type_cd148 = parameters.cd148.type_number;

% [C,ia] = setdiff(A,B)

%%% T_cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% id_TCR_old = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_tcr,1);
% id_LFA     = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_lfa,1);
% id_CD45    = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_cd45,1);
% id_CD43    = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_cd43,1);
% id_CD148   = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_cd148,1);

linind_TCR_old = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_tcr,2);
linind_LFA     = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_lfa,2);
linind_CD45    = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_cd45,2);
linind_CD43    = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_cd43,2);
linind_CD148   = id_linind_type_Z_E_T_cell(id_linind_type_Z_E_T_cell(:,3) == type_cd148,2);


new_linind_type_tcr = [new_linind_TCR,type_tcr*ones(size(new_linind_TCR))];
linind_type_lfa     = [linind_LFA ,type_lfa*ones(size(linind_LFA))];
linind_type_cd45    = [linind_CD45,type_cd45*ones(size(linind_CD45))];
linind_type_cd43    = [linind_CD43,type_cd43*ones(size(linind_CD43))];
linind_type_cd148   = [linind_CD148,type_cd148*ones(size(linind_CD148))];

linind_type0 = cat(1,new_linind_type_tcr,...
                    linind_type_lfa,...
                    linind_type_cd45,...
                    linind_type_cd43,...
                    linind_type_cd148);

unique_lininds = 1;                
if unique_lininds
    [linind,unique_index,~] = unique(linind_type0(:,1),'stable');
    linind_type = [linind,linind_type0(unique_index,2)];
else
    linind_type = linind_type0;
end

id = (1:size(linind_type,1))';
id_linind_type = [id, linind_type];
Z = L(linind);
E0 = zeros(size(linind));
id_linind_type_Z_E0 = [id_linind_type,Z,E0];

updated_id_linind_type_Z_E0 = id_linind_type_Z_E0;
end




