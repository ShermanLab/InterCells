function table_names_data = tablenamesdata(parameters)
%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for general = 1:1
    table_general_names_data = cell(7,3);

    table_general_names_data{1,1} = 'Iteration time (sec)';
    table_general_names_data{2,1} = 'Simulation time (sec)';
    table_general_names_data{3,1} = 'Experiment frame time (sec)';
    table_general_names_data{4,1} = 'Saving rate (every N iterations)';
    table_general_names_data{5,1} = 'Array size x (pixels)';
    table_general_names_data{6,1} = 'Array size y (pixels)';
    table_general_names_data{7,1} = 'Pixel size (nm)';
    
    
    

    table_general_names_data{1,2} = parameters.iteration_time;
    table_general_names_data{2,2} = parameters.iteration_time;
    table_general_names_data{3,2} = parameters.experiment_frame_time;
    table_general_names_data{4,2} = parameters.delta_iter;
    table_general_names_data{5,2} = parameters.array_size_x;
    table_general_names_data{6,2} = parameters.array_size_y;
    table_general_names_data{7,2} = parameters.experiment_frame_time;

    table_general_names_data{1,3} = parameters.iteration_time;
    table_general_names_data{2,3} = parameters.iteration_time;
    table_general_names_data{3,3} = parameters.experiment_frame_time;
    table_general_names_data{4,3} = parameters.delta_iter;
    table_general_names_data{5,3} = parameters.array_size_x;
    table_general_names_data{6,3} = parameters.array_size_y;
    table_general_names_data{7,3} = parameters.experiment_frame_time;
end

%%% TCR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for TCR = 1:1
table_TCR_names_data = cell(16,3);

table_TCR_names_data{1,1}  = 'Color (red)';
table_TCR_names_data{2,1}  = 'Color (green)';
table_TCR_names_data{3,1}  = 'Color (blue)';
table_TCR_names_data{4,1}  = 'Lateral size (nm)';
table_TCR_names_data{5,1}  = 'Vertical size (nm)';
table_TCR_names_data{6,1}  = 'Binding top (nm)';
table_TCR_names_data{7,1}  = 'Binding bottom (nm)';
table_TCR_names_data{8,1}  = 'Binding strength (KT)';
table_TCR_names_data{9,1}  = 'Spring strength (KT/nm^2)';
table_TCR_names_data{10,1} = 'Area 5nm (pixels)';
table_TCR_names_data{11,1} = 'Area 10nm (pixels)';
table_TCR_names_data{12,1} = 'Diffusion constant (um^2/sec)';
table_TCR_names_data{13,1} = 'Density (N/um^2)';
table_TCR_names_data{14,1} = 'Number (N)';

table_TCR_names_data{1,2}  = parameters.tcr.color(1);
table_TCR_names_data{2,2}  = parameters.tcr.color(2);
table_TCR_names_data{3,2}  = parameters.tcr.color(3);
table_TCR_names_data{4,2}  = parameters.tcr.lateral_size;
table_TCR_names_data{5,2}  = parameters.tcr.vertical_size;
table_TCR_names_data{6,2}  = parameters.tcr.binding_top;
table_TCR_names_data{7,2}  = parameters.tcr.binding_bottom;
table_TCR_names_data{8,2}  = parameters.tcr.binding_strength;
table_TCR_names_data{9,2}  = parameters.tcr.spring_k;
table_TCR_names_data{10,2} = parameters.tcr.area_patches_5;
table_TCR_names_data{11,2} = parameters.tcr.area_patches_10;
table_TCR_names_data{12,2} = parameters.tcr.diffusion_constant;
table_TCR_names_data{13,2} = parameters.tcr.density;
table_TCR_names_data{14,2} = parameters.tcr.N;






end
end





