function table_tcr_names_data = tcrparameters2table(parameters)

%%% TCR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for tcr = 1:1
    table_tcr_names_data = cell(16,3);
    
    table_tcr_names_data{1,1}  = 'Color (red)';
    table_tcr_names_data{2,1}  = 'Color (green)';
    table_tcr_names_data{3,1}  = 'Color (blue)';
    table_tcr_names_data{4,1}  = 'Lateral size (nm)';
    table_tcr_names_data{5,1}  = 'Vertical size (nm)';
    table_tcr_names_data{6,1}  = 'Binding top (nm)';
    table_tcr_names_data{7,1}  = 'Binding bottom (nm)';
    table_tcr_names_data{8,1}  = 'Binding strength (KT)';
    table_tcr_names_data{9,1}  = 'Spring strength (KT/nm^2)';
    table_tcr_names_data{10,1} = 'Area (5nm pixels)';
    table_tcr_names_data{11,1} = 'Area (10nm pixels)';
    table_tcr_names_data{12,1} = 'Diffusion constant (um^2/sec)';
    table_tcr_names_data{13,1} = 'Density (N/um^2)';
    table_tcr_names_data{14,1} = 'Number (N)';
    table_tcr_names_data{15,1} = 'Force membrane to mol height (Yes/No)';
    
    table_tcr_names_data{1,2}  = parameters.Tcell.tcr.color(1);
    table_tcr_names_data{2,2}  = parameters.Tcell.tcr.color(2);
    table_tcr_names_data{3,2}  = parameters.Tcell.tcr.color(3);
    table_tcr_names_data{4,2}  = parameters.Tcell.tcr.lateral_size;
    table_tcr_names_data{5,2}  = parameters.Tcell.tcr.vertical_size;
    table_tcr_names_data{6,2}  = parameters.Tcell.tcr.binding_top;
    table_tcr_names_data{7,2}  = parameters.Tcell.tcr.binding_bottom;
    table_tcr_names_data{8,2}  = parameters.Tcell.tcr.binding_strength;
    table_tcr_names_data{9,2}  = parameters.Tcell.tcr.spring_k;
    table_tcr_names_data{10,2} = parameters.Tcell.tcr.area_patches_5;
    table_tcr_names_data{11,2} = parameters.Tcell.tcr.area_patches_10;
    table_tcr_names_data{12,2} = parameters.Tcell.tcr.diffusion_constant;
    table_tcr_names_data{13,2} = parameters.Tcell.tcr.density;
%     table_tcr_names_data{14,2} = parameters.Tcell.tcr.N;
    table_tcr_names_data{15,2} = parameters.Tcell.tcr.force_z;
    
    table_tcr_names_data(:,3)  = table_tcr_names_data(:,2);

end
end





