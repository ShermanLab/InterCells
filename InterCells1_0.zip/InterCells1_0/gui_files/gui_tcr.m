% gui_tcr
% use gui to update parameters

%%% makes a table from parameters.Tcell.tcr %%%%%%%%%%%%%%%
table_tcr_names_data = tcrparameters2table(parameters);

%%% returns tcr parameters that are changed by the gui %%%%
gui_tcr_out = gui_TCR_properties();

%%% return parameters.Tcell.tcr with the updated parameters
tcr_parameters_out = tcrtable2parameters(gui_tcr_out,parameters);

%%% assigns the new parameters to the default parameters %%
parameters.Tcell.tcr = tcr_parameters_out;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% new locations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% uniform RHO
% circ R1, N, RHO
% ring R1, R2, N, RHO
% polygon N, RHO
for fold_polygons_points = 1;
    locations1 = 1;
    if locations1
        
        
        in_locations = polygonpoints(N,parameters);
        
        rand_array1 = rand(parameters.global.array_size_x,...
            parameters.global.array_size_y);
        [X,Y] = find(rand_array1);
        % color1 =
        
        figure(1)
        % clf
        axis equal
        axis([0 parameters.global.array_size_x 0 parameters.global.array_size_y])
        
        %%% make polygon %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% the initial list of points is empty %%%%%%%%%%%%%%%%%%%
        px = [];
        py = [];
        n = 0;
        %%% loop, picking up the points %%%%%%%%%%%%%%%%%%%%%%%%%%%
        disp('Left mouse button picks points')
        disp('Right mouse button picks last point')
        button = 1;
        hold on
        while button == 1
            [xi,yi,button] = ginput(1);
            plot(xi,yi,'ko')
            n = n+1;
            px(n) =  xi;
            py(n) =  yi;
        end
        polygon_x  = [px, px(1)];
        polygon_y  = [py, py(1)];
        polygon_points = [polygon_x',polygon_y'];
        %%% plot the polygon %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plot(polygon_x,polygon_y,'g-');
        
        %%% scatter points %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% scattering N points uniformly in the polygon area %%%%%
        in_polygon     = inpolygon(X,Y,polygon_x,polygon_y);
        rand_inpolygon = rand_array1(in_polygon);
        X_inpolygon    = X(in_polygon);
        Y_inpolygon    = Y(in_polygon);
        
        sorted_rand_inpolygon = sortrows([X_inpolygon,Y_inpolygon,rand_inpolygon],3);
        
        in_locations = sorted_rand_inpolygon(1:N,1:2);
        
        %%% plot in_locations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        plot(in_locations(:,1),in_locations(:,2),'g.')
        
        hold off
        axis equal
        axis([0 parameters.global.array_size_x 0 parameters.global.array_size_y])
    end
    
end % fold_polygons_points

