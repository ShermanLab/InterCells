function plot_simulation_data(simulation_data,parameters)

% input      : simulation_data, parameters.
% output     : none.
% called by  : interface_simlation.
% calling    : plot_molecules_and_membrane.
% description:

plot_molecules_and_membrane(simulation_data,parameters);

% plot_membrane_data(simulation_data,parameters);

plot_molecules_energies(simulation_data,parameters);
% PlotMembraneEnergy2(simulation_data,parameters);


end