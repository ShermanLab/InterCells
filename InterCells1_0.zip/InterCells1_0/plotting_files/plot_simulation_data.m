function plot_simulation_data(simulation_data,parameters)

% input      : simulation_data, parameters.
% output     : none.
% called by  : interface_simlation.
% calling    : plot_molecules_and_membrane.
% description:

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% molecules_and_membrane %%%%%%%%%%%%
if 1
    plot_molecules_and_membrane(simulation_data,parameters);
end

%%% membrane data %%%%%%%%%%%%%%%%%%%%%
if 0
    plot_membrane_data(simulation_data,parameters);
end

%%% molecules_energies %%%%%%%%%%%%%%%%
if 0
    plot_molecules_energies(simulation_data,parameters);
end

%%% membrane energy %%%%%%%%%%%%%%%%%%%
if 0
    PlotMembraneEnergy2(simulation_data,parameters);
end

end