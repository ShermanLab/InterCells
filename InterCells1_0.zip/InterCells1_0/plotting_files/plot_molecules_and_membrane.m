function plot_molecules_and_membrane(simulation_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data, parameters
output     : none
called by  : plot_simulation_data
calling    : none
description: plotting the membrane heigh and the molecules
locations according to the simulation_data. 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% reading data %%%%%%%%%%%%%%%%%%%%%%
id_linind_type_Z_E_Cell1 = simulation_data.Cell1.molecules;
id_linind_type_Z_E_Cell2 = simulation_data.Cell2.molecules;

%%% height of membranes %%%%%%%%%%%%%%% 
Z1 = simulation_data.Cell1.membrane.Z;
Z2 = simulation_data.Cell2.membrane.Z;
DZ = Z1 - Z2;

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;

Cell1_molecules = parameters.Cells.Cell1.molecules;
Cell2_molecules = parameters.Cells.Cell2.molecules;

%%% molecules colors %%%%%%%%%%%%%%%%%%
color1_1 = Cell1_molecules.type1.color;
color1_2 = Cell1_molecules.type2.color;
color1_3 = Cell1_molecules.type3.color;

color2_1 = Cell2_molecules.type1.color;
color2_2 = Cell2_molecules.type2.color;
color2_3 = Cell2_molecules.type3.color;

%%% molecules names %%%%%%%%%%%%%%%%%%%
% name1_1 = Cell1_molecules.type1.name;
% name1_2 = Cell1_molecules.type2.name;
% name1_3 = Cell1_molecules.type3.name;
% 
% name2_1 = Cell2_molecules.type1.name;
% name2_2 = Cell2_molecules.type2.name;
% name2_3 = Cell2_molecules.type3.name;

%%% molecules locations %%%%%%%%%%%%%%%
idm1      = id_linind_type_Z_E_Cell1(:,1);
idm2      = id_linind_type_Z_E_Cell2(:,1);

typem1    = id_linind_type_Z_E_Cell1(:,3);
typem2    = id_linind_type_Z_E_Cell2(:,3);

idm1_1    = idm1(typem1 == 1);
idm1_2    = idm1(typem1 == 2);
idm1_3    = idm1(typem1 == 3);

idm2_1    = idm2(typem2 == 1);
idm2_2    = idm2(typem2 == 2);
idm2_3    = idm2(typem2 == 3);

linindm1  = id_linind_type_Z_E_Cell1(:,2);
linindm2  = id_linind_type_Z_E_Cell2(:,2);

linindm1_1 = linindm1(idm1_1);
linindm1_2 = linindm1(idm1_2);
linindm1_3 = linindm1(idm1_3);

linindm2_1 = linindm2(idm2_1);
linindm2_2 = linindm2(idm2_2);
linindm2_3 = linindm2(idm2_3);

[X1_1,Y1_1] = ind2sub([size_x,size_y],linindm1_1);
[X1_2,Y1_2] = ind2sub([size_x,size_y],linindm1_2);
[X1_3,Y1_3] = ind2sub([size_x,size_y],linindm1_3);

[X2_1,Y2_1] = ind2sub([size_x,size_y],linindm2_1);
[X2_2,Y2_2] = ind2sub([size_x,size_y],linindm2_2);
[X2_3,Y2_3] = ind2sub([size_x,size_y],linindm2_3);

[X,Y] = meshgrid(1:size_x,1:size_y);
Z0 = parameters.Cells.Cell1.membrane.Z0;

%%% plotting %%%%%%%%%%%%%%%%%%%%%%%%%%
fig4 = figure(4);
pos1 = [800 400 600 600];
set(fig4,'Position',pos1)

plot(X2_1,Y2_1,'.','Color',color2_1);
hold on
plot(X2_2,Y2_2,'.','Color',color2_2);
plot(X2_3,Y2_3,'.','Color',color2_3);
% 
plot(X1_1,Y1_1,'.','Color',color1_1);
plot(X1_2,Y1_2,'.','Color',color1_2);
plot(X1_3,Y1_3,'.','Color',color1_3);

h = pcolor(X-0.5,Y-0.5,DZ'-Z0); 
colormap(gray)
set(h,'EdgeColor','none')
hold off
axis equal
axis([0 size_x 0 size_y])
xlabel('X(pixels)')
ylabel('Y(pixels)')

cbh = colorbar;
set(cbh,'YTick',[-Z0:10:0]);
set(cbh,'YTickLabels',{'0','10','20','30','40','50','60','70'});
caxis([-Z0+0 0])
title('Membrane and molecules locations','FontSize',16)
%%%
drawnow

end