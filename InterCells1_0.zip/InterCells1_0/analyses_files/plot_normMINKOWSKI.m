function plot_normMINKOWSKI(normMINKOWSKI)

normAREA_type1  = normMINKOWSKI.type1.area;
normPERIM_type1 = normMINKOWSKI.type1.perim;
normEULER_type1 = normMINKOWSKI.type1.euler;

normAREA_type2  = normMINKOWSKI.type2.area;
normPERIM_type2 = normMINKOWSKI.type2.perim;
normEULER_type2 = normMINKOWSKI.type2.euler;

normAREA_type3  = normMINKOWSKI.type3.area;
normPERIM_type3 = normMINKOWSKI.type3.perim;
normEULER_type3 = normMINKOWSKI.type3.euler;


max_x = 20;
R = 0:50;

% t = 6;
for t = 1:101
    disp(t)
    figure(6)
    subplot(1,3,1)
    plot(R,normAREA_type1(t,:),'g-')
    hold on
    plot(R,normPERIM_type1(t,:),'g--')
    plot(R,normEULER_type1(t,:),'g:')
    hold off
    legend('a(r)','p(r)','e(r)')
    axis([0 max_x -0.1 1.1])
    title(['TCR, t = ',int2str(t-1),'sec'])
    xlabel('Disk radius (pixels)')

    subplot(1,3,2)
    plot(R,normAREA_type2(t,:),'b-')
    hold on
    plot(R,normPERIM_type2(t,:),'b--')
    plot(R,normEULER_type2(t,:),'b:')
    hold off
    legend('a(r)','p(r)','e(r)')
    axis([0 max_x -0.1 1.1])
    title(['LFA, t = ',int2str(t-1),'sec'])
    xlabel('Disk radius (pixels)')
    
    subplot(1,3,3)
    plot(R,normAREA_type3(t,:),'r-')
    hold on
    plot(R,normPERIM_type3(t,:),'r--')
    plot(R,normEULER_type3(t,:),'r:')
    hold off
    legend('a(r)','p(r)','e(r)')
    axis([0 max_x -0.1 1.1])
    title(['CD45, t = ',int2str(t-1),'sec'])
    xlabel('Disk radius (pixels)')
    
    drawnow
%     pause(0.02)
end






