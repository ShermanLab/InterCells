function MINKOWSKI = results2minkowski(folder_name,times_vector,run,parameters)

all_results = load(folder_name);
% t = 0;
clockname = folder_name(14:end);
%%% parameters
max_R        = parameters.analyses.max_R;
size_t = length(times_vector);
size_r = max_R + 1;

MINKOWSKI = [];
AREA_type1  = zeros(size_t,size_r);
PERIM_type1 = zeros(size_t,size_r);
EULER_type1 = zeros(size_t,size_r);
AREA_type2  = zeros(size_t,size_r);
PERIM_type2 = zeros(size_t,size_r);
EULER_type2 = zeros(size_t,size_r);
AREA_type3  = zeros(size_t,size_r);
PERIM_type3 = zeros(size_t,size_r);
EULER_type3 = zeros(size_t,size_r);

for lt = 1:length(times_vector)
    t = times_vector(lt);
    disp(t)
    %%% TOP
    TOP_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.TOP;
    id_linind_type_Z_E_TOP  = TOP_data.id_linind_type_Z_E_TOP;
    id       = id_linind_type_Z_E_TOP(:,1);
    id_dype1 = id(id_linind_type_Z_E_TOP(:,3) == 1);
    id_dype2 = id(id_linind_type_Z_E_TOP(:,3) == 2);
    id_dype3 = id(id_linind_type_Z_E_TOP(:,3) == 3);
%     id_dype5 = id(id_linind_type_Z_E_TOP(:,3) == 5);
%     id_dype6 = id(id_linind_type_Z_E_TOP(:,3) == 6);
    
    linind_type1  = id_linind_type_Z_E_TOP(id_dype1,2);
    linind_type2  = id_linind_type_Z_E_TOP(id_dype2,2);
    linind_type3  = id_linind_type_Z_E_TOP(id_dype3,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [area1,perim1,euler1] = minkowski(linind_type1,parameters);
    [area2,perim2,euler2] = minkowski(linind_type2,parameters);
    [area3,perim3,euler3] = minkowski(linind_type3,parameters);

    AREA_type1(lt,:)  = area1;
    PERIM_type1(lt,:) = perim1;
    EULER_type1(lt,:) = euler1;
    AREA_type2(lt,:)  = area2;
    PERIM_type2(lt,:) = perim2;
    EULER_type2(lt,:) = euler2;
    AREA_type3(lt,:)  = area3;
    PERIM_type3(lt,:) = perim3;
    EULER_type3(lt,:) = euler3;

end

MINKOWSKI.type1.area  = AREA_type1;
MINKOWSKI.type1.perim = PERIM_type1;
MINKOWSKI.type1.euler = EULER_type1;

MINKOWSKI.type2.area  = AREA_type2;
MINKOWSKI.type2.perim = PERIM_type2;
MINKOWSKI.type2.euler = EULER_type2;

MINKOWSKI.type3.area  = AREA_type3;
MINKOWSKI.type3.perim = PERIM_type3;
MINKOWSKI.type3.euler = EULER_type3;



















