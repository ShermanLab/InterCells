function normMINKOWSKI = results2normminkowski(folder_name,times_vector,run,parameters)

all_results = load(folder_name);
% t = 0;
clockname = folder_name(14:end);
%%% parameters
max_R        = parameters.analyses.max_R;
size_t = length(times_vector);
size_r = max_R + 1;

normMINKOWSKI = [];
normAREA_type1  = zeros(size_t,size_r);
normPERIM_type1 = zeros(size_t,size_r);
normEULER_type1 = zeros(size_t,size_r);
normAREA_type2  = zeros(size_t,size_r);
normPERIM_type2 = zeros(size_t,size_r);
normEULER_type2 = zeros(size_t,size_r);
normAREA_type3  = zeros(size_t,size_r);
normPERIM_type3 = zeros(size_t,size_r);
normEULER_type3 = zeros(size_t,size_r);

for lt = 1:length(times_vector)
    t = times_vector(lt);
    %%% TOP
    TOP_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.TOP;
    id_linind_type_Z_E_TOP  = TOP_data.id_linind_type_Z_E_TOP;
    id       = id_linind_type_Z_E_TOP(:,1);
    id_dype1 = id(id_linind_type_Z_E_TOP(:,3) == 1);
    id_dype2 = id(id_linind_type_Z_E_TOP(:,3) == 2);
    id_dype3 = id(id_linind_type_Z_E_TOP(:,3) == 3);
%     id_dype5 = id(id_linind_type_Z_E_TOP(:,3) == 5);
%     id_dype6 = id(id_linind_type_Z_E_TOP(:,3) == 6);
    
    linind_type1  = id_linind_type_Z_E_TOP(id_dype1,2);
    linind_type2  = id_linind_type_Z_E_TOP(id_dype2,2);
    linind_type3  = id_linind_type_Z_E_TOP(id_dype3,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [normarea1,normperim1,normeuler1] = normminkowski(linind_type1,parameters);
    [normarea2,normperim2,normeuler2] = normminkowski(linind_type2,parameters);
    [normarea3,normperim3,normeuler3] = normminkowski(linind_type3,parameters);

    normAREA_type1(lt,:)  = normarea1;
    normPERIM_type1(lt,:) = normperim1;
    normEULER_type1(lt,:) = normeuler1;
    normAREA_type2(lt,:)  = normarea2;
    normPERIM_type2(lt,:) = normperim2;
    normEULER_type2(lt,:) = normeuler2;
    normAREA_type3(lt,:)  = normarea3;
    normPERIM_type3(lt,:) = normperim3;
    normEULER_type3(lt,:) = normeuler3;

end

normMINKOWSKI.type1.area  = normAREA_type1;
normMINKOWSKI.type1.perim = normPERIM_type1;
normMINKOWSKI.type1.euler = normEULER_type1;

normMINKOWSKI.type2.area  = normAREA_type2;
normMINKOWSKI.type2.perim = normPERIM_type2;
normMINKOWSKI.type2.euler = normEULER_type2;

normMINKOWSKI.type3.area  = normAREA_type3;
normMINKOWSKI.type3.perim = normPERIM_type3;
normMINKOWSKI.type3.euler = normEULER_type3;



















