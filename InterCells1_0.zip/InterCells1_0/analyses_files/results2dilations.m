function DILATIONS = results2dilations(results_folder_name,data_times,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(results_folder_name);
% t = 0;
clockname = results_folder_name(14:end);
%%% parameters
max_R = parameters.analyses.max_R;

DILATIONS  = cell(3,1);
DILATIONS1 = cell(size(data_times,2),1);
DILATIONS2 = cell(size(data_times,2),1);
DILATIONS3 = cell(size(data_times,2),1);
disp(run)
%%% reading data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
size_x      = global_data.array_size_x;
size_y      = global_data.array_size_y;

for t = data_times(1:end)
    disp(t)
    %%% TOP
    TOP_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.TOP;
    id_linind_type_Z_E_TOP  = TOP_data.id_linind_type_Z_E_TOP;
    
    id              = id_linind_type_Z_E_TOP(:,1);
    id_dype1        = id(id_linind_type_Z_E_TOP(:,3) == 1);
    id_dype2        = id(id_linind_type_Z_E_TOP(:,3) == 2);
    id_dype3        = id(id_linind_type_Z_E_TOP(:,3) == 3);
    
    linind_type1    = id_linind_type_Z_E_TOP(id_dype1,2);
    linind_type2    = id_linind_type_Z_E_TOP(id_dype2,2);
    linind_type3    = id_linind_type_Z_E_TOP(id_dype3,2);
       
    dilations1      = dilations(linind_type1,parameters);
    dilations2      = dilations(linind_type2,parameters);
    dilations3      = dilations(linind_type3,parameters);
        
    DILATIONS1{t+1} = dilations1;
    DILATIONS2{t+1} = dilations2;
    DILATIONS3{t+1} = dilations3;
    
end

DILATIONS{1} = DILATIONS1;
DILATIONS{2} = DILATIONS2;
DILATIONS{3} = DILATIONS3;

















