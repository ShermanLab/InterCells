function plot_MINKOWSKI(MINKOWSKI)

AREA_type1  = MINKOWSKI.type1.area;
PERIM_type1 = MINKOWSKI.type1.perim;
EULER_type1 = MINKOWSKI.type1.euler;

AREA_type2  = MINKOWSKI.type2.area;
PERIM_type2 = MINKOWSKI.type2.perim;
EULER_type2 = MINKOWSKI.type2.euler;

AREA_type3  = MINKOWSKI.type3.area;
PERIM_type3 = MINKOWSKI.type3.perim;
EULER_type3 = MINKOWSKI.type3.euler;


max_x = 30;
R = 0:50;

% t = 6;
for t = 1:101
%     disp(t)
    figure(5)
    subplot(3,3,1)
    plot(R,AREA_type1(t,:),'g-')
    legend('a(r)')
    xlabel('Disk radius (pixels)')
    
    subplot(3,3,4)
    plot(R,PERIM_type1(t,:),'g--')
    legend('p(r)')
    xlabel('Disk radius (pixels)')
    
    subplot(3,3,7)
    plot(R,EULER_type1(t,:),'g:')
    legend('e(r)')
    xlabel('Disk radius (pixels)')
    %%%
    subplot(3,3,2)
    plot(R,AREA_type2(t,:),'b-')
    legend('a(r)')
    xlabel('Disk radius (pixels)')
    title(['t = ',int2str(t-1),'sec'])
    
    
    subplot(3,3,5)
    plot(R,PERIM_type2(t,:),'b--')
    legend('p(r)')
    xlabel('Disk radius (pixels)')
    
    subplot(3,3,8)
    plot(R,EULER_type2(t,:),'b:')
    hold off
    legend('e(r)')
    xlabel('Disk radius (pixels)')
    %%%
    subplot(3,3,3)
    plot(R,AREA_type3(t,:),'r-')
    legend('a(r)')
    xlabel('Disk radius (pixels)')
    
    subplot(3,3,6)
    plot(R,PERIM_type3(t,:),'r--')
    legend('p(r)')
    xlabel('Disk radius (pixels)')
    
    subplot(3,3,9)
    plot(R,EULER_type3(t,:),'r:')
    ylim([-2 2])
    legend('e(r)')
    xlabel('Disk radius (pixels)')

    
    drawnow
    pause(0.02)
end






