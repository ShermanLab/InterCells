function plot_DENSITIES(DENSITIES)

DENSITIES11 = DENSITIES{1};
DENSITIES12 = DENSITIES{2};
DENSITIES13 = DENSITIES{3};

R = 0:50;
max_x = max(R);
max_y = 0.1;
maxdensities11 = zeros(101,1);
maxdensities12 = zeros(101,1);
maxdensities13 = zeros(101,1);

stddensities11 = zeros(101,1);
stddensities12 = zeros(101,1);
stddensities13 = zeros(101,1);

for t = 1:101
    densities11 = DENSITIES11{t};
    densities12 = DENSITIES12{t};
    densities13 = DENSITIES13{t};
    
    smdensities11 = smooth([densities11{:}],5);
    smdensities12 = smooth([densities12{:}],5);
    smdensities13 = smooth([densities13{:}],5);
    
    maxdensities11(t) = find(smdensities11 == max(smdensities11));
    maxdensities12(t) = find(smdensities12 == max(smdensities12));
    maxdensities13(t) = find(smdensities13 == max(smdensities13));
    %%%%%%%%%%%%%%%%%%%%%%%%%
%     [xi,yi] = polyxpoly(x1,y1,x2,y2)
    hm11 = max(smdensities12)/2;
    hm12 = max(smdensities12)/2;
    hm13 = max(smdensities13)/2;
    
    [x11i,~] = polyxpoly([0 max_x],[hm11 hm11],R,smdensities12);
    [x12i,~] = polyxpoly([0 max_x],[hm12 hm12],R,smdensities12);
    [x13i,~] = polyxpoly([0 max_x],[hm13 hm13],R,smdensities13);
    
    fwhm11 = max(x11i) - min(x11i);
    fwhm12 = max(x12i) - min(x12i);
    fwhm13 = max(x13i) - min(x13i);
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    stddensities11(t) = std(find(smdensities11 > mean(smdensities11)));
    stddensities12(t) = std(find(smdensities12 > mean(smdensities12)));
    stddensities13(t) = std(find(smdensities13 > mean(smdensities13)));
    
%     stddensities22(t) = std(find(smdensities22 > 0));
%     stddensities23(t) = std(find(smdensities23 > 0));
%     stddensities24(t) = std(find(smdensities24 > 0));
    
    figure(8)
    clf
    %%% 
    plot(R,[densities11{:}],'g-')
    hold on
%     plot(R,[densities23{:}],'b-')
%     plot(R,[densities24{:}],'r-')
    
    bar(R,[densities12{:}],'b')
    bar(R,[densities13{:}],'r')
    alpha(0.5)
    
    plot(R,smdensities11,'g-','LineWidth',2)
    plot(R,smdensities12,'b-','LineWidth',2)
    plot(R,smdensities13,'r-','LineWidth',2)
    hold off
    axis([0 max_x 0 max_y])
%     legend('a(r)')
    xlabel('Disk radius (pixels)')
    ylabel('Density')
    title(['t = ',int2str(t-1)])
    
    drawnow
    pause(0.02)
end
figure(9)
clf
% errorbar(0:100,maxdensities22,stddensities22,'g')
% std23max = maxdensities23 + stddensities23/2;
% std23min = maxdensities23 - stddensities23/2;
% std24max = maxdensities24 + stddensities24/2;
% std24min = maxdensities24 - stddensities24/2;
std11max = maxdensities11 + fwhm11/2;
std11min = maxdensities11 - fwhm11/2;
std12max = maxdensities12 + fwhm12/2;
std12min = maxdensities12 - fwhm12/2;
std13max = maxdensities13 + fwhm13/2;
std13min = maxdensities13 - fwhm13/2;
T = 0:100;
std_polygon_x  = [T,max(T) - T];
std11polygon_y = [std11min',(flipud(std11max))'];
std12polygon_y = [std12min',(flipud(std12max))'];
std13polygon_y = [std13min',(flipud(std13max))'];

% errorbar(0:100,maxdensities23,stddensities23,'b')
% errorbar(0:100,maxdensities24,stddensities24,'r')

patch(std_polygon_x,std11polygon_y,'g','EdgeColor','g')
hold on
patch(std_polygon_x,std12polygon_y,'b','EdgeColor','b')
patch(std_polygon_x,std13polygon_y,'r','EdgeColor','r')
alpha(0.2)
plot(T,maxdensities11,'g','LineWidth',2)
plot(T,maxdensities12,'b','LineWidth',2)
plot(T,maxdensities13,'r','LineWidth',2)
hold off
axis([0 max(T) 0 70])




