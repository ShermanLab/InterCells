function results2images(folder_name,tvec,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(folder_name);
% t = 0;
clockname = folder_name(14:end);
%%% parameters
% a      = parameters.global.pixel_size;
for t = tvec(1:end)
    %%% global
    global_data = all_results.RUNS_RESULTS{1,run}{t+1,1}.global;
    size_x      = global_data.array_size_x;
    size_y      = global_data.array_size_y;
    L           = global_data.L;
    
    %%% TOP
    TOP_data               = all_results.RUNS_RESULTS{1,1}{t+1,1}.TOP;
    K_TOP                  = TOP_data.K;
    M_TOP                  = TOP_data.M;
    id_linind_type_Z_E_TOP = TOP_data.id_linind_type_Z_E_TOP;
    
    %%% BOT
    BOT_data               = all_results.RUNS_RESULTS{1,1}{t+1,1}.BOT;
    K_BOT                  = BOT_data.K;
    M_BOT                  = BOT_data.M;
    id_linind_type_Z_E_BOT = BOT_data.id_linind_type_Z_E_BOT;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    hFig = figure(26);
    clf
    set(hFig, 'Position', [100 100 500 500]) % 800 800
    disp_ticks    = 0;
    disp_text     = 0;
    disp_colorbar = 0;
    msp = 15;
    msc = 15;
    
    % msx = 7;
    sx = 0.5;
    sy = 0.5;
    %%% plot data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for plot_data = 1:1
        %%% TOP = Tcell
        if strcmp(parameters.global.TOP,'Tcell')
            
            color1_TOP = parameters.Tcell.tcr.color;
            color2_TOP = parameters.Tcell.lfa.color;
            color3_TOP = parameters.Tcell.cd45.color;
            color4_TOP = parameters.Tcell.cd43.color;
            color5_TOP = parameters.Tcell.cd148.color;
            
            name1_TOP  = 'TCR';
            name2_TOP  = 'LFA';
            name3_TOP  = 'CD45';
            name4_TOP  = 'CD43';
            name5_TOP  = 'CD148';
            
        end
        %%% BOT = Coverslip
        if strcmp(parameters.global.BOT,'Coverslip')
            
            color1_BOT = parameters.Coverslip.alpha_cd3.color;
            color2_BOT = parameters.Coverslip.alpha_cd11.color;
            color3_BOT = parameters.Coverslip.alpha_cd45.color;
            
            name1_BOT  = '\alphaCD3';
            name2_BOT  = '\alphaCD11';
            name3_BOT  = '\alphaCD45';
        end
        %%% BOT = APC
        if strcmp(parameters.global.BOT,'APC')
            
            color1_BOT = parameters.APC.pmhc.color;
            color2_BOT = parameters.APC.icam.color;
            
            name1_BOT  = 'pMHC';
            name2_BOT  = 'ICAM';
        end
        %%% separating different TOP proteims to types %%%%%%%%%%%%
        TOP1 = id_linind_type_Z_E_TOP((id_linind_type_Z_E_TOP(:,3) == 1),:);
        TOP2 = id_linind_type_Z_E_TOP((id_linind_type_Z_E_TOP(:,3) == 2),:);
        TOP3 = id_linind_type_Z_E_TOP((id_linind_type_Z_E_TOP(:,3) == 3),:);
        TOP4 = id_linind_type_Z_E_TOP((id_linind_type_Z_E_TOP(:,3) == 4),:);
        TOP5 = id_linind_type_Z_E_TOP((id_linind_type_Z_E_TOP(:,3) == 5),:);
        
        %%% getting coordinates of the different types %%%%%%%%%%%%
        [TOP1x,TOP1y] = ind2sub([size_x,size_y],TOP1(:,2));
        [TOP2x,TOP2y] = ind2sub([size_x,size_y],TOP2(:,2));
        [TOP3x,TOP3y] = ind2sub([size_x,size_y],TOP3(:,2));
        [TOP4x,TOP4y] = ind2sub([size_x,size_y],TOP4(:,2));
        [TOP5x,TOP5y] = ind2sub([size_x,size_y],TOP5(:,2));
        
        %%% separating different BOT proteims to types %%%%%%%%%%%%
        BOT2 = id_linind_type_Z_E_BOT((id_linind_type_Z_E_BOT(:,3) == 1),:);
        BOT3 = id_linind_type_Z_E_BOT((id_linind_type_Z_E_BOT(:,3) == 2),:);
        BOT4 = id_linind_type_Z_E_BOT((id_linind_type_Z_E_BOT(:,3) == 3),:);
        
        %%% getting coordinates for the different types %%%%%%%%%%%
        [BOT1x,BOT1y] = ind2sub([size_x,size_y],BOT2(:,2));
        [BOT2x,BOT2y] = ind2sub([size_x,size_y],BOT3(:,2));
        [BOT3x,BOT3y] = ind2sub([size_x,size_y],BOT4(:,2));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% plotting proteins coordinates and L %%%%%%%%%%%%%%%%%%%
        
        %%% plot coverslip ligands %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if strcmp(parameters.global.BOT,'Coverslip')
            plot(BOT1x-sx,BOT1y-sy,'.','MarkerSize',msc,'color',color1_BOT) %dark
            hold on
            plot(BOT2x-sx,BOT2y-sy,'.','MarkerSize',msc,'color',color2_BOT)
            plot(BOT3x-sx,BOT3y-sy,'.','MarkerSize',msc,'color',color3_BOT)
        end
        
        if strcmp(parameters.global.BOT,'APC')
            plot(BOT1x-sx,BOT1y-sy,'.','MarkerSize',msc,'color',color1_BOT) %dark
            hold on
            plot(BOT2x-sx,BOT2y-sy,'.','MarkerSize',msc,'color',color2_BOT)
        end
        %%% plot T-cell proteins %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        plot(TOP1x-sx,TOP1y-sy,'.','MarkerSize',msp,'color',color1_TOP)
        plot(TOP2x-sx,TOP2y-sy,'.','MarkerSize',msp,'color',color2_TOP)
        plot(TOP3x-sx,TOP3y-sy,'.','MarkerSize',msp,'color',color3_TOP)
        plot(TOP4x-sx,TOP4y-sy,'.','MarkerSize',msp,'color',color4_TOP)
        plot(TOP5x-sx,TOP5y-sy,'.','MarkerSize',msp,'color',color5_TOP)
        
        %%% plot active proteins %%%%%%%%%%%%%%%%%%%%%%%%%%
        axis([0 size_x 0 size_y])
        if disp_ticks
            set(gca,'XTick',0:50:size_x)
            set(gca,'XTickLabel',{a*[0:50:size_x]})
            set(gca,'YTick',0:50:size_y)
            set(gca,'YTickLabel',{a*[0:50:size_y]})
        end % disp_ticks
        % title(['\fontsize{16}{\color[rgb]{0 0 0}Coverslip, T-cell and L,   t = ',int2str(ceil(iter/100)),' sec}'])
        title(['\fontsize{14}{\color[rgb]{0 0 0}',...
            parameters.global.TOP,' - ', parameters.global.BOT ,...
            '   t = ',int2str(t),' sec}'])
        %     xlabel('x (nm)','fontsize',14)
        %     ylabel('y (nm)','fontsize',14)
        
        xplot = 0:size_x;
        yplot = 0:size_y;
        [Xplot,Yplot] = meshgrid(xplot,yplot);
        Lplot0 = [L,L(:,end)];
        Lplot  = [Lplot0;Lplot0(end,:)];
        %     cdx = 0.5;
        %     cdy = 0.5;
        
        %%% plot membrane %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        h1 = pcolor(Xplot,Yplot,Lplot'-51); %[1 1 0]flipud
        
        colormap(gray)
        % colormap(jet)
        set(h1, 'EdgeColor', 'none');
        
        zlim([-50 0])
        caxis([-50 0])
        if disp_colorbar
            colorbar
            colorbar('YTickLabel',{0:5:50})
        end
        set(gcf, 'renderer', 'zbuffer');
        
        %%% legends %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% giving names %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        if disp_text
            dyt = size_y/25;
            y0t = size_y*0.9;
            
            
            %%% plot BOT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if strcmp(parameters.global.BOT,'Coverslip')
                text(5,y0t+1*dyt, [name1_BOT,' = ',int2str(size(BOT1x,1))],'Color',color1_BOT,'BackgroundColor',[1 1 1],'fontweight','b')
                text(5,y0t-0*dyt, [name2_BOT,' = ',int2str(size(BOT2x,1))],'Color',color2_BOT,'BackgroundColor',[1 1 1],'fontweight','b')
                text(5,y0t-1*dyt, [name3_BOT,' = ',int2str(size(BOT3x,1))],'Color',color3_BOT,'BackgroundColor',[1 1 1],'fontweight','b')
            end
            
            if strcmp(parameters.global.BOT,'APC')
                text(5,y0t+1*dyt, [name1_BOT,' = ',int2str(size(BOT1x,1))],'Color',color1_BOT,'BackgroundColor',[1 1 1],'fontweight','b')
                text(5,y0t-0*dyt, [name2_BOT,' = ',int2str(size(BOT2x,1))],'Color',color2_BOT,'BackgroundColor',[1 1 1],'fontweight','b')
            end
            
            %%% plot TOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            text(5,y0t-2*dyt, [name1_TOP,' = ',int2str(size(TOP1x,1))],'Color',color1_TOP,'BackgroundColor',[1 1 1],'fontweight','b')
            text(5,y0t-3*dyt, [name2_TOP,' = ',int2str(size(TOP2x,1))],'Color',color2_TOP,'BackgroundColor',[1 1 1],'fontweight','b')
            text(5,y0t-4*dyt, [name3_TOP,' = ',int2str(size(TOP3x,1))],'Color',color3_TOP,'BackgroundColor',[1 1 1],'fontweight','b')
            text(5,y0t-5*dyt, [name4_TOP,' = ',int2str(size(TOP4x,1))],'Color',color4_TOP,'BackgroundColor',[1 1 1],'fontweight','b')
            text(5,y0t-6*dyt, [name5_TOP,' = ',int2str(size(TOP5x,1))],'Color',color5_TOP,'BackgroundColor',[1 1 1],'fontweight','b')
            
        end % if names
        
        hold off
        axis equal
        axis([0 size_x 0 size_y])
        axis off
        view(2)
        
        box on
    end % for_plot_data
    %%% save image %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    image_savename = [parameters.global.TOP,parameters.global.BOT,...
                      '_',clockname,'_t',int2str(t)];
    saveas(gcf,image_savename,'fig');
    saveas(gcf,image_savename,'png');
end





