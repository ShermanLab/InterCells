function initial_Coverslip_data = test_Coverslip_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns = (size_x/1000*a)*(size_y/1000*a);
rand_array   = rand(size_x,size_y);
[X,Y]        = find(rand_array);

linind_points_in = [];

%%% acd3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
acd3_parameters = parameters.Cells.Coverslip.molecules.acd3;
N_acd3          = acd3_parameters.global_density*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in        = sortrows([X_in,Y_in,rand_in],3);
points_in             = sorted_rand_in(1:N_acd3,1:2);
linind_acd3_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linind_aCD3 = linind_acd3_points_in;

linind_points_in = [linind_points_in,linind_acd3_points_in];
rand_array(linind_points_in) = 0;

%%% acd11 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
acd11_parameters = parameters.Cells.Coverslip.molecules.acd11;
N_acd11          = acd11_parameters.global_density*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in         = sortrows([X_in,Y_in,rand_in],3);
points_in              = sorted_rand_in(1:N_acd11,1:2);
linind_acd11_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linind_aCD11 = linind_acd11_points_in;

linind_points_in = [linind_points_in;linind_acd11_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% acd45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
acd45_parameters = parameters.Cells.Coverslip.molecules.acd45;
N_acd45          = acd45_parameters.global_density*area_microns;

% [X,Y]              = find(rand_array);
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in         = sortrows([X_in,Y_in,rand_in],3);
points_in              = sorted_rand_in(1:N_acd45,1:2);
linind_acd45_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linind_aCD45 = linind_acd45_points_in;

linind_points_in = [linind_points_in;linind_acd45_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure(9)
A2 = zeros(size_x,size_y); 
A2(linind_aCD3)  = 1; 
A2(linind_aCD11) = 2; 
A2(linind_aCD45) = 3; 
% imagesc(A0)
% axis equal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%% reading from default_parameters %%% 
%%% Tcell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
type_acd3  = acd3_parameters.type_number;
type_acd11 = acd11_parameters.type_number;
type_acd45 = acd45_parameters.type_number;

%%% putting linind and type together %%
linind_type_aCD3  = [linind_aCD3  ,type_acd3*ones(size(linind_aCD3))];
linind_type_aCD11 = [linind_aCD11  ,type_acd11*ones(size(linind_aCD11))];
linind_type_aCD45 = [linind_aCD45 ,type_acd45*ones(size(linind_aCD45))];

linind_type = cat(1,linind_type_aCD3,...
                    linind_type_aCD11,...
                    linind_type_aCD45);
linind = linind_type(:,1);
%%% gives serial id to the proteins %%%
id = (1:size(linind_type,1))';
%%% putting id, linind and type together 
id_linind_type = [id, linind_type];
%%% giving the height of the membrane at the proteins locations
Z = zeros(size_x,size_y)*parameters.Cells.Coverslip.membrane.Z0;
Z(linind_aCD3) = parameters.Cells.Coverslip.molecules.acd3.vertical_size;
Z_molecules = Z(linind);

%%% setting the energy of each protein to zero %%%%%%%%%%%%
E0 = zeros(size(linind));
%%% putting id, linind, type and E0 together %%%%%%%%%%%%%%
id_linind_type_Z_E0 = [id_linind_type,Z_molecules,E0];

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
% initial rigidity
K = ones(size_x,size_y)*parameters.Cells.Coverslip.membrane.rigidity;
% initial diffusivity
D = ones(size_x,size_y)*parameters.Cells.Coverslip.membrane.diffusivity;
% initial energy
E = zeros(size_x,size_y)*parameters.Cells.Tcell.membrane.diffusivity;

membrane.Z = Z;
membrane.K = K;
membrane.D = D;
membrane.E = E;

initial_Coverslip_data.molecules       = id_linind_type_Z_E0;
initial_Coverslip_data.membrane        = membrane;
initial_Coverslip_data.locations_array = A2;
end