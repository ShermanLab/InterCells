function initial_Tcell_data = test_Tcell_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns = (size_x/1000*a)*(size_y/1000*a);
rand_array   = rand(size_x,size_y);
[X,Y]        = find(rand_array);
linind_points_in = [];

%%%
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);
%%% tcr %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tcr_parameters = parameters.Cells.Tcell.molecules.tcr;

N_tcr          = tcr_parameters.global_density*area_microns;

%%% tcr cluster %%%%%%%%%%%%%%%%%%%%%%%
D_tcr_cluster  = tcr_parameters.cluster_density;
R_tcr_cluster  = 20; % pixels
x0 = size_x/2;
y0 = size_y/2;
t  = 0:pi/10:2*pi;
xc = x0 + R_tcr_cluster*cos(t);
yc = y0 + R_tcr_cluster*sin(t);
N_tcr_cluster = 200;
polygon_x  = xc;
polygon_y  = yc;

in_polygon = inpolygon(X,Y,polygon_x,polygon_y);
% linind_existing_points
% excluding location that are already occupied by 'existing points'
% if ~isempty(linind_existing_points)
%     in_polygon(linind_existing_points) = 0;
% end

% getting rand_array values that are inside the polygon
rand_inpolygon = rand_array(in_polygon);
X_in    = X(in_polygon);
Y_in    = Y(in_polygon);







% scattering N points uniformly in the polygon area %%%%%
sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);
points_in = sorted_rand_in(1:N_tcr_cluster,1:2);

linind_tcr_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

% X_in    = X(ind_free_locations);
% Y_in    = Y(ind_free_locations);
% 
% sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
% points_in            = sorted_rand_in(1:N_tcr,1:2);
% linind_tcr_points_in = sub2ind([size_x,size_y],...
%     points_in(:,1),points_in(:,2));

linind_TCR = linind_tcr_points_in;

linind_points_in = [linind_points_in,linind_tcr_points_in];
rand_array(linind_points_in) = 0;

%%% lfa %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lfa_parameters = parameters.Cells.Tcell.molecules.lfa;
N_lfa          = lfa_parameters.global_density*area_microns;

% [X,Y]              = find(rand_array);
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N_lfa,1:2);
linind_lfa_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linind_LFA = linind_lfa_points_in;

linind_points_in = [linind_points_in;linind_lfa_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% cd45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd45_parameters = parameters.Cells.Tcell.molecules.cd45;
N_cd45         = cd45_parameters.global_density*area_microns;

% [X,Y]              = find(rand_array);
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N_cd45,1:2);
linind_cd45_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linind_CD45 = linind_cd45_points_in;

linind_points_in = [linind_points_in;linind_cd45_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure(9)
A1 = zeros(size_x,size_y); 
A1(linind_TCR)  = 1; 
A1(linind_LFA)  = 2; 
A1(linind_CD45) = 3; 
% % imagesc(A1)
% % axis equal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%% reading from default_parameters %%% 
%%% Tcell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
type_tcr  = tcr_parameters.type_number;
type_lfa  = lfa_parameters.type_number;
type_cd45 = cd45_parameters.type_number;

%%% putting linind and type together %%
linind_type_TCR   = [linind_TCR  ,type_tcr*ones(size(linind_TCR))];
linind_type_LFA   = [linind_LFA  ,type_lfa*ones(size(linind_LFA))];
linind_type_CD45  = [linind_CD45 ,type_cd45*ones(size(linind_CD45))];

linind_type = cat(1,linind_type_TCR,...
                    linind_type_LFA,...
                    linind_type_CD45);
linind = linind_type(:,1);
%%% gives serial id to the proteins %%%
id = (1:size(linind_type,1))';
%%% putting id, linind and type together 
id_linind_type = [id, linind_type];
%%% giving the height of the membrane at the proteins locations
Z = ones(size_x,size_y)*parameters.Cells.Tcell.membrane.Z0;
Z_molecules = Z(linind);
Z(linind_TCR) = parameters.Cells.Tcell.molecules.tcr.vertical_size;

%%% setting the energy of every protein to zero 
E0 = zeros(size(linind));
%%% putting id, linind, type and E0 together 
id_linind_type_Z_E0 = [id_linind_type,Z_molecules,E0];

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
% initial rigidity
K = ones(size_x,size_y)*parameters.Cells.Tcell.membrane.rigidity;
% initial diffusivity
D = ones(size_x,size_y)*parameters.Cells.Tcell.membrane.diffusivity;
% initial energy
E = zeros(size_x,size_y)*parameters.Cells.Tcell.membrane.diffusivity;

membrane.Z = Z;
membrane.K = K;
membrane.D = D;
membrane.E = E;

initial_Tcell_data.molecules       = id_linind_type_Z_E0;
initial_Tcell_data.membrane        = membrane;
initial_Tcell_data.locations_array = A1;
end






