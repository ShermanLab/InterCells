function initial_Cell1_data = make_initial_Cell1_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns = (size_x/1000*a)*(size_y/1000*a);
rand_array   = rand(size_x,size_y);
[X,Y]        = find(rand_array);
linindm_points_in = [];

%%% finding linind of free locations 
% (locations where the value is not 0)
linind_free_locations     = find(rand_array);
linind_occupied_locations = [];

%%% finding locations that free 
X_free    = X(linind_free_locations);
Y_free    = Y(linind_free_locations);

%%% Cell1 type1 %%%%%%%%%%%%%%%%%%%%%%%
for fold_type1 = 1
%%% Cell1 type1 global_density %%%%%%%%
global_density1_1 = parameters.Cells.Cell1.molecules.type1.global_density;
N1_1              = global_density1_1*area_microns;

%%% Cell1 type1 clusters %%%%%%%%%%%%%%
cluster_density1_1  = parameters.Cells.Cell1.molecules.type1.cluster_density;

x01 = [size_x*0.3 ,size_x*0.45, size_x*0.7]; % clusters center x
y01 = [size_y*0.2 ,size_y*0.8 , size_y*0.5]; % clusters center y

linindm1_1 = [];
for C1_ind = 1:3 % cluster index
    R1_1 = 20; % cluster radius pixels
%     x0 = size_x/2; % cluster center x
%     y0 = size_y/2; % cluster center y
    t  = 0:pi/10:2*pi;
    xc = x01(C1_ind) + R1_1*cos(t); % cluster boundary points x
    yc = y01(C1_ind) + R1_1*sin(t); % cluster boundary points y
    
    cluster_area_pixels = polyarea(xc,yc); % sq pixels
    cluster_area_microns = cluster_area_pixels/(1000/a)^2; % sq pixels
    N1_1_cluster = cluster_area_microns*cluster_density1_1;
    
    polygon_x  = xc;
    polygon_y  = yc;

    in_polygon = inpolygon(X_free,Y_free,polygon_x,polygon_y);

    % excluding location that are already occupied
    %by 'existing points'
    if ~isempty(linind_occupied_locations)
        in_polygon(linind_occupied_locations) = 0;
    end

    % getting rand_array values that are inside the polygon
    rand_inpolygon = rand_array(in_polygon);
    
    X_in           = X_free(in_polygon);
    Y_in           = Y_free(in_polygon);

    % scattering N points uniformly in the polygon area
    % arranging the random values inside the polygon
    % in ascending order
    sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);
    % getting the X,Y coordinate of these points
    points_in = sorted_rand_in(1:N1_1_cluster,1:2);
    % getting the linind of these points
    linindm1_1_points_in = sub2ind([size_x,size_y],...
        points_in(:,1),points_in(:,2));

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%% excluding location that are already occupied 
    linindm_points_in = [linindm_points_in;linindm1_1_points_in];
    rand_array(linindm_points_in) = 0;

    linindm1_1 = [linindm1_1;linindm1_1_points_in];
end % Cluster_ind

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cell1 type2 %%%%%%%%%%%%%%%%%%%%%%%
for fold_type2 =1
global_density1_2 = parameters.Cells.Cell1.molecules.type2.global_density;
N1_2              = global_density1_2*area_microns;

%%% type1 clusters %%%%%%%%%%%%%%%%%%%%
cluster_density1_2  = parameters.Cells.Cell1.molecules.type2.cluster_density;

x02 = [size_x*0.25 ,size_x*0.35, size_x*0.8]; % clusters center x
y02 = [size_y*0.33 ,size_y*0.75, size_y*0.25]; % clusters center y

linindm1_2 = [];
for C2_ind = 1:3 % cluster index
R1_2  = 10; % pixels
% x0 = size_x/3;
% y0 = size_y/3;
t  = 0:pi/10:2*pi;
xc = x02(C2_ind) + R1_2*cos(t);
yc = y02(C2_ind) + R1_2*sin(t);

cluster_area_pixels  = polyarea(xc,yc); % sq pixels
cluster_area_microns = cluster_area_pixels/(1000/a)^2; % sq pixels
N1_2_cluster = cluster_area_microns*cluster_density1_2;

polygon_x  = xc;
polygon_y  = yc;

in_polygon = inpolygon(X_free,Y_free,polygon_x,polygon_y);

% excluding location that are already occupied
%by 'existing points'
if ~isempty(linind_occupied_locations)
    in_polygon(linind_occupied_locations) = 0;
end

% getting rand_array values that are inside the polygon
rand_inpolygon = rand_array(in_polygon);
X_in           = X_free(in_polygon);
Y_in           = Y_free(in_polygon);

% scattering N points uniformly in the polygon area
% arranging the random values inside the polygon
% in ascending order
sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);

% getting the X,Y coordinate of these points
points_in = sorted_rand_in(1:N1_2_cluster,1:2);
% getting the linind of these points
linindm1_2_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% excluding location that are already occupied 
linindm_points_in = [linindm_points_in;linindm1_2_points_in];
rand_array(linindm_points_in) = 0;

linindm1_2 = [linindm1_2;linindm1_2_points_in];

end % C_ind
end % fold_type2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cell1 type3 %%%%%%%%%%%%%%%%%%%%%%%
for fold_type3 = 1
global_density1_3 = parameters.Cells.Cell1.molecules.type3.global_density;
N1_3              = global_density1_3*area_microns;

linind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(linind_free_locations);

X_in    = X_free(linind_free_locations);
Y_in    = Y_free(linind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N1_3,1:2);
linindm1_3_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm1_3 = linindm1_3_points_in;

linindm_points_in = [linindm_points_in;linindm1_3_points_in];
rand_array(linindm_points_in) = 0;

end % fold_type3

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A1 = zeros(size_x,size_y); 
A1(linindm1_1) = 1; 
A1(linindm1_2) = 2; 
A1(linindm1_3) = 3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% putting linind and type together %%
linindm1_1type = [linindm1_1 ,1*ones(size(linindm1_1))];
linindm1_2type = [linindm1_2 ,2*ones(size(linindm1_2))];
linindm1_3type = [linindm1_3 ,3*ones(size(linindm1_3))];

linind_type = cat(1,linindm1_1type,...
                    linindm1_2type,...
                    linindm1_3type);
linind = linind_type(:,1);
%%% gives serial id to the proteins %%%
id1 = (1:size(linind_type,1))';
%%% putting id, linind and type together 
id_linind_type = [id1, linind_type];

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
%%% initial Z
%%% giving the height of the membrane at the molacules locations
Z = ones(size_x,size_y)*parameters.Cells.Cell1.membrane.Z0;

%%% setting the membrane height at molecule types 1,2,3 
%%% force_z1_1
if parameters.Cells.Cell1.molecules.type1.force_z
    Z(linindm1_1) = parameters.Cells.Cell1.molecules.type1.vertical_size;
end
%%% force_z1_2
if parameters.Cells.Cell1.molecules.type2.force_z
    Z(linindm1_2) = parameters.Cells.Cell1.molecules.type2.vertical_size;
end
%%% force_z1_3
if parameters.Cells.Cell1.molecules.type3.force_z
    Z(linindm1_3) = parameters.Cells.Cell1.molecules.type3.vertical_size;
end


Z_molecules = Z(linind);

%%% setting the energy of every molecule to zero 
E0 = zeros(size(linind));
%%% putting id, linind, type and E0 together 
id_linind_type_Z_E0 = [id_linind_type,Z_molecules,E0];

%%% initial rigidity
K = ones(size_x,size_y)*parameters.Cells.Cell1.membrane.rigidity;
%%% initial diffusivity
D = ones(size_x,size_y)*parameters.Cells.Cell1.membrane.diffusivity;
%%% initial energy
E = zeros(size_x,size_y);

membrane.Z = Z;
membrane.K = K;
membrane.D = D;
membrane.E = E;

initial_Cell1_data.molecules       = id_linind_type_Z_E0;
initial_Cell1_data.membrane        = membrane;
initial_Cell1_data.locations_array = A1;

end






