function simulation_data = insert_experimental_data(simulation_data,current_linind_experimental_data,parameters)

id_linind_type_Z_E_T_cell    = simulation_data.id_linind_type_Z_E_T_cell;
id_linind_type_Z_E_coverslip = simulation_data.id_linind_type_Z_E_coverslip;
K      = simulation_data.K;
L      = simulation_data.L;
iter   = simulation_data.iter;
rect_x = simulation_data.rect_x;
rect_y = simulation_data.rect_y;

experimental_frame = ceil((iter+1)/250); 

type_tcr   = parameters.tcr.type_number;
type_lfa   = parameters.lfa.type_number;
type_cd45  = parameters.cd45.type_number;
type_cd43  = parameters.cd43.type_number;
type_cd148 = parameters.cd148.type_number;

% TCR   = id_linind_type_Z_E_T_cell((id_linind_type_Z_E_T_cell(:,3) == type_tcr),:);
LFA   = id_linind_type_Z_E_T_cell((id_linind_type_Z_E_T_cell(:,3) == type_lfa),:);
CD45  = id_linind_type_Z_E_T_cell((id_linind_type_Z_E_T_cell(:,3) == type_cd45),:);
CD43  = id_linind_type_Z_E_T_cell((id_linind_type_Z_E_T_cell(:,3) == type_cd43),:);
CD148 = id_linind_type_Z_E_T_cell((id_linind_type_Z_E_T_cell(:,3) == type_cd148),:);
%%% inserting new TCR data 
linind_TCR    = current_linind_experimental_data;
id_TCR        = [1:size(linind_TCR,1)]';
ones_type_TCR = type_tcr*ones(size(linind_TCR));
L(linind_TCR) = parameters.tcr.alpha_cd3_well_center;
E_TCR         = zeros(size(linind_TCR));

TCR = [id_TCR,linind_TCR,ones_type_TCR,L(linind_TCR),E_TCR];

initial_id_linind_type_Z_E0_T_cell    = cat(1,LFA,TCR,CD45,CD43,CD148);
initial_id_linind_type_Z_E0_coverlsip = id_linind_type_Z_E_coverslip;

id_linind_type_Z_E_T_cell = E18(initial_id_linind_type_Z_E0_T_cell,initial_id_linind_type_Z_E0_coverlsip,parameters);
id_linind_type_Z_E_coverslip = initial_id_linind_type_Z_E0_coverlsip;

simulation_data.id_linind_type_Z_E_T_cell    = id_linind_type_Z_E_T_cell;
simulation_data.id_linind_type_Z_E_coverslip = id_linind_type_Z_E_coverslip;
simulation_data.K      = K;
simulation_data.L      = L;
simulation_data.iter   = iter;
simulation_data.rect_x = rect_x;
simulation_data.rect_y = rect_y;







