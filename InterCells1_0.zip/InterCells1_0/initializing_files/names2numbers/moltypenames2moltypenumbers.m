function parameters =  moltypenames2moltypenumbers(parameters)

%%% TCell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.Cells.Tcell.molecules.type1 = parameters.Cells.Tcell.molecules.tcr;
parameters.Cells.Tcell.molecules.type2 = parameters.Cells.Tcell.molecules.lfa;
parameters.Cells.Tcell.molecules.type3 = parameters.Cells.Tcell.molecules.cd45;

parameters.Cells.Tcell.molecules = rmfield(parameters.Cells.Tcell.molecules,'tcr');
parameters.Cells.Tcell.molecules = rmfield(parameters.Cells.Tcell.molecules,'lfa');
parameters.Cells.Tcell.molecules = rmfield(parameters.Cells.Tcell.molecules,'cd45');

%%% Coverslip %%%%%%%%%%%%%%%%%%%%%%%%%
parameters.Cells.Coverslip.molecules.type1 = parameters.Cells.Coverslip.molecules.acd3;
parameters.Cells.Coverslip.molecules.type2 = parameters.Cells.Coverslip.molecules.acd11;
parameters.Cells.Coverslip.molecules.type3 = parameters.Cells.Coverslip.molecules.acd45;

parameters.Cells.Coverslip.molecules = rmfield(parameters.Cells.Coverslip.molecules,'acd3');
parameters.Cells.Coverslip.molecules = rmfield(parameters.Cells.Coverslip.molecules,'acd11');
parameters.Cells.Coverslip.molecules = rmfield(parameters.Cells.Coverslip.molecules,'acd45');

%%% APC %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.Cells.APC.molecules.type1 = parameters.Cells.APC.molecules.pmhc;
parameters.Cells.APC.molecules.type2 = parameters.Cells.APC.molecules.icam;

parameters.Cells.APC.molecules = rmfield(parameters.Cells.APC.molecules,'pmhc');
parameters.Cells.APC.molecules = rmfield(parameters.Cells.APC.molecules,'icam');

end


