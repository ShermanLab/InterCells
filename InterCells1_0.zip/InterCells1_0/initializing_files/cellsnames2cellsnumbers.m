function parameters = cellsnames2cellsnumbers(parameters,Cell1_name,Cell2_name)

% input:
% output:
% called by:
% description:

%%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(Cell1_name,'Tcell')
    parameters.Cells.Cell1 = parameters.Cells.Tcell;
elseif strcmp(Cell1_name,'APC')
    parameters.Cells.Cell1 = parameters.Cells.APC;
elseif strcmp(Cell1_name,'Coverslip')
    parameters.Cells.Cell1 = parameters.Cells.Coverslip;
end
parameters.Cells = rmfield(parameters.Cells,Cell1_name);
parameters.Cells.Cell1.Cell_number = 1;

%%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(Cell2_name,'Tcell')
    parameters.Cells.Cell2 = parameters.Cells.Tcell;
elseif strcmp(Cell2_name,'APC')
    parameters.Cells.Cell2 = parameters.Cells.APC;
elseif strcmp(Cell2_name,'Coverslip')
    parameters.Cells.Cell2 = parameters.Cells.Coverslip;
end
parameters.Cells = rmfield(parameters.Cells,Cell2_name);
parameters.Cells.Cell2.Cell_number = 2;

%%% other Cells %%%%%%%%%%%%%%%%%%%%%%%
if ~strcmp(Cell2_name,'Tcell') && ~strcmp(Cell1_name,'Tcell')
    parameters.Cells = rmfield(parameters.Cells,'Tcell');
end
if ~strcmp(Cell2_name,'APC') && ~strcmp(Cell1_name,'APC')
    parameters.Cells = rmfield(parameters.Cells,'APC');
end
if ~strcmp(Cell2_name,'Coverslip') && ~strcmp(Cell1_name,'Coverslip')
    parameters.Cells = rmfield(parameters.Cells,'Coverslip');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
















