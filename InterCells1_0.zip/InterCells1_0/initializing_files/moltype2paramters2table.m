function moltype2_parameters_table = moltype2paramters2table(parameters)
%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold = 1:1
    moltype2_parameters_table = cell(16,3);
    %%% Name (units) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    moltype2_parameters_table{1,1}  = 'Color (red)';
    moltype2_parameters_table{2,1}  = 'Color (green)';
    moltype2_parameters_table{3,1}  = 'Color (blue)';
    moltype2_parameters_table{4,1}  = 'Lateral size (nm)';
    moltype2_parameters_table{5,1}  = 'Vertical size (nm)';
    moltype2_parameters_table{6,1}  = 'Binding top (nm)';
    moltype2_parameters_table{7,1}  = 'Binding bottom (nm)';
    moltype2_parameters_table{8,1}  = 'Binding strength (KT)';
    moltype2_parameters_table{9,1}  = 'Spring strength (KT/nm^2)';
    moltype2_parameters_table{10,1} = 'Area 5nm (pixels)';
    moltype2_parameters_table{11,1} = 'Area 10nm (pixels)';
    moltype2_parameters_table{12,1} = 'Diffusion constant (um^2/sec)';
    moltype2_parameters_table{13,1} = 'Density (N/um^2)';
    moltype2_parameters_table{14,1} = 'Number (N)';


    
    %%% Default %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    moltype2_parameters_table{1,2}  = parameters.Cell1.moltype2.color(1);
    moltype2_parameters_table{2,2}  = parameters.tcr.color(2);
    moltype2_parameters_table{3,2}  = parameters.tcr.color(3);
    moltype2_parameters_table{4,2}  = parameters.tcr.lateral_size;
    moltype2_parameters_table{5,2}  = parameters.tcr.vertical_size;
    moltype2_parameters_table{6,2}  = parameters.tcr.binding_top;
    moltype2_parameters_table{7,2}  = parameters.tcr.binding_bottom;
    moltype2_parameters_table{8,2}  = parameters.tcr.binding_strength;
    moltype2_parameters_table{9,2}  = parameters.tcr.spring_k;
    moltype2_parameters_table{10,2} = parameters.tcr.area_patches_5;
    moltype2_parameters_table{11,2} = parameters.tcr.area_patches_10;
    moltype2_parameters_table{12,2} = parameters.tcr.diffusion_constant;
    moltype2_parameters_table{13,2} = parameters.tcr.density;
    moltype2_parameters_table{14,2} = parameters.tcr.N;
    
    %%% New %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    moltype2_parameters_table{1,3} = parameters.iteration_time;
end
end





