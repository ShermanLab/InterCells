function initial_Cell2_data = make_initial_Cell2_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns = (size_x/1000*a)*(size_y/1000*a);
rand_array   = rand(size_x,size_y);
[X,Y]        = find(rand_array);

linind_points_in = [];

%%% acd3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global_density2_1 = parameters.Cells.Cell2.molecules.type1.global_density;
N2_1              = global_density2_1*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_1,1:2);
linindm2_1_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_1 = linindm2_1_points_in;

linind_points_in = [linind_points_in,linindm2_1_points_in];
rand_array(linind_points_in) = 0;

%%% Cell2 type1 %%%%%%%%%%%%%%%%%%%%%%%
global_density2_1 = parameters.Cells.Cell2.molecules.type2.global_density;
N2_1              = global_density2_1*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_1,1:2);
linindm2_2_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_2 = linindm2_2_points_in;

linind_points_in = [linind_points_in;linindm2_2_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% acd45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global_density2_3 = parameters.Cells.Cell2.molecules.type2.global_density;
N2_3              = global_density2_3*area_microns;

% [X,Y]              = find(rand_array);
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_3,1:2);
linindm2_3_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_3 = linindm2_3_points_in;

linind_points_in = [linind_points_in;linindm2_3_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure(9)
A2 = zeros(size_x,size_y); 
A2(linindm2_1) = 1; 
A2(linindm2_2) = 2; 
A2(linindm2_3) = 3; 
% imagesc(A0)
% axis equal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%% putting linind and type together %%
linindm2_1  = [linindm2_1 ,1*ones(size(linindm2_1))];
linindm2_2 = [linindm2_2 ,2*ones(size(linindm2_2))];
linindm2_3 = [linindm2_3 ,3*ones(size(linindm2_3))];

linind_type = cat(1,linindm2_1,...
                    linindm2_2,...
                    linindm2_3);
linind = linind_type(:,1);
%%% gives serial id to the proteins %%%
id = (1:size(linind_type,1))';
%%% putting id, linind and type together 
id_linind_type = [id, linind_type];
%%% giving the height of the membrane at the proteins locations
Z2 = zeros(size_x,size_y)*parameters.Cells.Cell2.membrane.Z0;
Z2(linindm2_1) = parameters.Cells.Cell2.molecules.type1.vertical_size;
Z_molecules = Z2(linind);

%%% setting the energy of each protein to zero %%%%%%%%%%%%
E0 = zeros(size(linind));
%%% putting id, linind, type and E0 together %%%%%%%%%%%%%%
id_linind_type_Z_E0 = [id_linind_type,Z_molecules,E0];

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
% initial rigidity
K2 = ones(size_x,size_y)*parameters.Cells.Cell2.membrane.rigidity;
% initial diffusivity
D2 = ones(size_x,size_y)*parameters.Cells.Cell2.membrane.diffusivity;
% initial energy
E2 = zeros(size_x,size_y);

membrane.Z = Z2;
membrane.K = K2;
membrane.D = D2;
membrane.E = E2;

initial_Cell2_data.molecules       = id_linind_type_Z_E0;
initial_Cell2_data.membrane        = membrane;
initial_Cell2_data.locations_array = A2;
end