function library = make_library(parameters)

% library saves the initially generated cells,
% and initial simulations data taken from
% experimental data end from previous simulations.

%%% default Cells 
library.Cells.Tcell     = parameters.Cells.Tcell;
library.Cells.APC       = parameters.Cells.APC;
library.Cells.Coverslip = parameters.Cells.Coverslip;


%%% experimental initial conditions
% library.initial_conditions.experimental



%%% simulated initial conditions
% library.initial_conditions.simulated






















