function default_LIPIDBILAYER_parameters = defaultLIPIDBILAYERparameters(default_parameters)


array_size_x = default_parameters.global.array_size_x;
array_size_y = default_parameters.global.array_size_y;
pixel_size   = default_parameters.global.pixel_size;

%%% APC membrane %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_LIPIDBILAYER_parameters.membrane.rigidity        = 1*25; %25; % KBT
default_LIPIDBILAYER_parameters.membrane.min_rigidity    = 25; % KT
default_LIPIDBILAYER_parameters.membrane.max_rigidity    = 100; % 100; %250; % KT
default_LIPIDBILAYER_parameters.membrane.local_rigidity  = 0; 
%%%
default_LIPIDBILAYER_parameters.membrane.diffusivity       = 1; 
default_LIPIDBILAYER_parameters.membrane.min_diffusivity   = 0.0; 
default_LIPIDBILAYER_parameters.membrane.max_diffusivity   = 1; 
default_LIPIDBILAYER_parameters.membrane.local_diffusivity = 0; 
%%%
default_LIPIDBILAYER_parameters.membrane.Z0                = 0; % nm
default_LIPIDBILAYER_parameters.membrane.min_Z             = 0; % nm 
default_LIPIDBILAYER_parameters.membrane.max_Z             = 0; % nm
default_LIPIDBILAYER_parameters.membrane.dz                = 0; % nm

% default_APC_parameters.membrane.z            = ...
%     default_APC_parameters.membrane.rigidity*...
%     ones(array_size_x,array_size_y); % KBT

%%%% spring_proteins %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_LIPIDBILAYER_parameters.spring_proteins = 1;
if default_LIPIDBILAYER_parameters.spring_proteins
    
    default_LIPIDBILAYER_parameters.molecules.pmhc.spring_k = ...
        1*0.1*default_LIPIDBILAYER_parameters.membrane.rigidity/...
        pixel_size^2; % 10; %0.1
    default_LIPIDBILAYER_parameters.molecules.icam.spring_k = ...
        1*0.1*default_LIPIDBILAYER_parameters.membrane.rigidity/...
        pixel_size^2; % 10; %0.1

end
%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_generate_points = 1:1
    array_size_x_microns = array_size_x*pixel_size/1000;
    array_size_y_microns = array_size_y*pixel_size/1000;
    area_microns = array_size_x_microns*array_size_y_microns;
    ligand_density = 300; %300; % #/um^2
    rand_array = rand(array_size_x,array_size_y);
    ind1  = [1:array_size_x*array_size_y]';
    rand1 = rand_array(:);
    sorted_ind1_rand1 = sortrows([ind1,rand1],2);
end

%%% pmhc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_pmhc = 1:1
    default_LIPIDBILAYER_parameters.molecules.pmhc.name               = 'pMHC';
    default_LIPIDBILAYER_parameters.molecules.pmhc.type_number        = 1;
    default_LIPIDBILAYER_parameters.molecules.pmhc.color              = [0 0.6 0];
    default_LIPIDBILAYER_parameters.molecules.pmhc.lateral_size       = 10; % nm
    default_LIPIDBILAYER_parameters.molecules.pmhc.vertical_size      = 0; % nm
    default_LIPIDBILAYER_parameters.molecules.pmhc.binding_bottom     = 0; %8; % nm
    default_LIPIDBILAYER_parameters.molecules.pmhc.binding_top        = 0; %18; %-5; % nm
    default_LIPIDBILAYER_parameters.molecules.pmhc.binding_strength   = -6; % KT
    if default_LIPIDBILAYER_parameters.spring_proteins
        default_LIPIDBILAYER_parameters.molecules.pmhc.spring_k       = ...
            1*0.1*default_LIPIDBILAYER_parameters.membrane.rigidity/...
            (pixel_size^2*1); % 0.1
    end
    default_LIPIDBILAYER_parameters.molecules.pmhc.area_patches_5     = 4; % nm
    default_LIPIDBILAYER_parameters.molecules.pmhc.area_patches_10    = 1; % nm
    default_LIPIDBILAYER_parameters.molecules.pmhc.diffusion_constant = 0.01; % um^2/sec
    default_LIPIDBILAYER_parameters.molecules.pmhc.sigma_pixels       = ...
        sqrt(4*default_LIPIDBILAYER_parameters.molecules.pmhc.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
    default_LIPIDBILAYER_parameters.molecules.pmhc.global_density     = ligand_density; % #/um^2
    default_LIPIDBILAYER_parameters.molecules.pmhc.cluster_density    = 1000; % #/um^2
    default_LIPIDBILAYER_parameters.molecules.pmhc.density_of_clusters = 1; % #/um^2
    default_LIPIDBILAYER_parameters.molecules.pmhc.force_z          = 0; 

    N1 = default_LIPIDBILAYER_parameters.molecules.pmhc.global_density*area_microns;
    
    linind_pmhc = sorted_ind1_rand1(1:N1,1);
    
    [default_LIPIDBILAYER_parameters.molecules.pmhc.locations(:,1),...
     default_LIPIDBILAYER_parameters.molecules.pmhc.locations(:,2)] = ...
     ind2sub([array_size_x,array_size_y],linind_pmhc);

end
%%% icam %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_icam = 1:1
    default_LIPIDBILAYER_parameters.molecules.icam.type_number        = 2;
    default_LIPIDBILAYER_parameters.molecules.icam.binding_strength   = -10; % KT
    default_LIPIDBILAYER_parameters.molecules.icam.color              = [1 0 1];
    default_LIPIDBILAYER_parameters.molecules.icam.lateral_size       = 10; % nm
    default_LIPIDBILAYER_parameters.molecules.icam.vertical_size      = 0; % nm
    if default_LIPIDBILAYER_parameters.spring_proteins
        default_LIPIDBILAYER_parameters.molecules.icam.spring_k       = ...
            1*0.1*default_LIPIDBILAYER_parameters.membrane.rigidity/...
            (pixel_size^2*1); % 0.1
    end
    default_LIPIDBILAYER_parameters.molecules.icam.area_patches_5     = 1; % nm
    default_LIPIDBILAYER_parameters.molecules.icam.area_patches_10    = 1; % nm
    default_LIPIDBILAYER_parameters.molecules.icam.diffusion_constant = 0.01; % um^2/sec
    default_LIPIDBILAYER_parameters.molecules.icam.sigma_pixels       = ...
        sqrt(4*default_LIPIDBILAYER_parameters.molecules.icam.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
    default_LIPIDBILAYER_parameters.molecules.icam.density            = ligand_density; % #/um^2

    N2 = default_LIPIDBILAYER_parameters.molecules.icam.density*area_microns;
    
    linind_icam = sorted_ind1_rand1(N1+1:N1+N2,1);
    
    [default_LIPIDBILAYER_parameters.molecules.icam.locations(:,1),...
     default_LIPIDBILAYER_parameters.molecules.icam.locations(:,2)] = ...
     ind2sub([array_size_x,array_size_y],linind_icam);
end













