function default_LIPIDBILAYER_parameters = defaultLIPIDBILAYERparameters()

%%% name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Lipidbilayer.cellname = 'Lipidbilayer';

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
Lipidbilayer.membrane       = defaultLIPIDBILAYERmembraneparameters();

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
% pmhc
Lipidbilayer.molecules.pmhc  = defaultLBPMHCparameters();
% icam 
Lipidbilayer.molecules.icam  = defaultLBICAMparameters();

% apcm3 
Lipidbilayer.molecules.apcm3 = defaultLBAPCM3parameters();
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_LIPIDBILAYER_parameters = Lipidbilayer;
end















