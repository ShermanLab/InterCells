function lbpmhc_parameters = defaultLBPMHCparameters()

%%% setting TCR default parameters
pmhc.name                = 'LBpMHC';
pmhc.type_number         = 1;
pmhc.color               = [0.5 1 0.5]; % RGB
% sizes
pmhc.vertical_size       = 0; % nm
pmhc.lateral_size        = 10; % nm
pmhc.area_patches_5      = 4;  % #
pmhc.area_patches_10     = 1;  % #
% potentials
pmhc.potential_width     = 0;  % nm
pmhc.binding_bottom      = pmhc.vertical_size - pmhc.potential_width/2; % nm
pmhc.binding_top         = pmhc.vertical_size + pmhc.potential_width/2; % nm
pmhc.binding_strength    = -10;  % KT
pmhc.spring_k            = 0; % ?
% diffusion
pmhc.diffusion_constant  = 0.005; % um^2/sec
% clusters
pmhc.global_density      = 300;  % #/um^2
pmhc.cluster_density     = 1000; % #/um^2
pmhc.density_of_clusters = 1;    % #/um^2
% force membrane to molecule height
pmhc.force_z = 0; % 0/1

lbpmhc_parameters = pmhc;
end 