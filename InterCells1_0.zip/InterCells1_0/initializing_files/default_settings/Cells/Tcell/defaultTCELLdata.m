function default_Tcell_parameters = defaultTCELLparameters(default_parameters)

%%% name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_Tcell_parameters.cellname = 'T-cell';
%%% array %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pixel_size   = default_parameters.global.pixel_size;



%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% tcr %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_tcr = 1:1
      if default_T_cell_parameters.spring_proteins
        default_Tcell_parameters.molecules.tcr.spring_k       = ...
            1*0.1*default_Tcell_parameters.membrane.rigidity/...
            (pixel_size^2*1); % 0.1
%     end
    default_Tcell_parameters.molecules.tcr.sigma_pixels       = ...
        sqrt(4*default_Tcell_parameters.molecules.tcr.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
    
    cumulated_T_cell_locations                       = [0,0];
    end % fold_tcr
end
%%% lfa %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_lfa = 1:1
        default_Tcell_parameters.molecules.lfa.spring_k       = ...
            1*0.1*default_Tcell_parameters.membrane.rigidity/...
            (pixel_size^2*1); % 0.1
%     end
    default_Tcell_parameters.molecules.lfa.sigma_pixels       = ...
        sqrt(4*default_Tcell_parameters.molecules.lfa.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
end % fold_lfa

%%% cd45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_cd45 = 1:1
        default_Tcell_parameters.molecules.cd45.spring_k       = ...
            1*0.1*default_Tcell_parameters.membrane.rigidity/...
            (pixel_size^2*1); % 0.1
%     end
    default_Tcell_parameters.molecules.cd45.sigma_pixels       = ...
        sqrt(4*default_Tcell_parameters.molecules.cd45.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
end % fold_cd45















