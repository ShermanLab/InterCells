function lfa_parameters = defaultLFA1parameters()

%%% setting TCR default parameters
lfa.name                = 'LFA1';
lfa.type_number         = 2;
lfa.color               = [0 0 1]; % RGB
% sizes
lfa.vertical_size       = 35; % nm
lfa.lateral_size        = 10; % nm
lfa.area_patches_5      = 4;  % #
lfa.area_patches_10     = 1;  % #
% potentials
lfa.potential_width     = 10;  % nm
lfa.binding_bottom      = lfa.vertical_size - lfa.potential_width/2; % nm
lfa.binding_top         = lfa.vertical_size + lfa.potential_width/2; % nm
lfa.binding_strength    = -20;  % KT
lfa.spring_k            = 0.1;  % ?
% diffusion
lfa.diffusion_constant  = 0.01; % um^2/sec
% clusters
lfa.global_density      = 1000; %300;  % #/um^2
lfa.cluster_density     = 2000; % #/um^2
lfa.density_of_clusters = 0.8;    % #/um^2
% force membrane to molecule height
lfa.force_z             = 1; % 0/1

lfa_parameters = lfa;
end 