function Tcell_molecules_locations = initialTCELLmoleculeslocations(default_parameters)

%%% reading from parameters %%%%%%%%%%%
%%% global %%%%%%%%%%%%%%%%%%%%%%%%%%%%
size_x = default_parameters.global.array_size_x;
size_y = default_parameters.global.array_size_y;
a      = default_parameters.global.pixel_size;

%%% boundary for clusters' centers %%%%
centers_x_min = 20; % pixels
centers_y_min = 20; % pixels 
centers_x_max = size_x - 20; 
centers_y_max = size_y - 20; 

%%% calulating clusters' numbers %%%%%%
size_x_microns = size_x/1000*a;
size_y_microns = size_y/1000*a;
rand_array     = rand(size_x,size_y);
% 
% %%% T-cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% tcr %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tcr_parameters = default_parameters.Cells.Tcell.molecules.tcr;
% 
% % tcr_type_number         = tcr_parameters.type_number;
% tcr_global_density      = tcr_parameters.density; % global_ ;
% tcr_cluster_density     = tcr_parameters.cluster_density;
% tcr_density_of_clusters = tcr_parameters.density_of_clusters;
% 
% %%% clusters' locations %%%%%%%%%%%%%%%
% 
% %%%
% %%%
% % number of clusters
% N_tcr_clusters             = round(size_x_microns*size_y_microns*tcr_density_of_clusters);
% N_tcrs_in_cluster          = 110;
% tcr_cluster_radius_microns = sqrt(N_tcrs_in_cluster/(tcr_cluster_density*pi));
% tcr_cluster_radius         = tcr_cluster_radius_microns*1000/a;
% 
% tcr_clusters_centers_x  = ceil(rand(N_tcr_clusters,1)*...
%     (centers_x_max - centers_x_min) + centers_x_min);
% tcr_clusters_centers_y  = ceil(rand(N_tcr_clusters,1)*...
%     (centers_y_max - centers_y_min) + centers_y_min);
% 
% linind_tcr_locations    = [];
% 
% for m = 1:N_tcr_clusters
%     x0 = tcr_clusters_centers_x(m);
%     y0 = tcr_clusters_centers_y(m);
%     linind_points_in_circle = pointsincircle(x0,y0,...
%         tcr_cluster_radius,N_tcrs_in_cluster,size_x,size_y,rand_array);
% 
%     linind_tcr_locations    = [linind_tcr_locations;linind_points_in_circle];
% end 
% %%%
% %%%
% A0 = zeros(size(rand_array));
% A0(linind_tcr_locations) = 1;
% figure(8)
% spy(A0)


linind_tcr_locations = linindclusters(parameters,tcr_parameters);


%%% lfa %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
lfa_parameters = default_parameters.Cells.Tcell.molecules.lfa;

% lfa_type_number         = lfa_parameters.type_number;
lfa_global_density      = lfa_parameters.density; %global_; 
lfa_cluster_density     = lfa_parameters.cluster_density;
lfa_density_of_clusters = lfa_parameters.density_of_clusters;

% number of clusters
N_lfa_clusters = round(size_x_microns*size_y_microns*lfa_density_of_clusters);
N_lfas_in_cluster          = 110;
lfa_cluster_radius_microns = sqrt(N_lfas_in_cluster/(lfa_cluster_density*pi));
lfa_cluster_radius         = lfa_cluster_radius_microns*1000/a;
% clusters' locations
centers_x_min = 20; % pixels
centers_y_min = 20; % pixels 
centers_x_max = size_x - 20; 
centers_y_max = size_y - 20; 

% centers_x_min = centers_x_min_microns*1000/a
lfa_clusters_centers_x  = ceil(rand(N_lfa_clusters,1)*...
    (centers_x_max - centers_x_min) + centers_x_min);
lfa_clusters_centers_y  = ceil(rand(N_lfa_clusters,1)*...
    (centers_y_max - centers_y_min) + centers_y_min);
% [lfa_clusters_centers_x,lfa_clusters_centers_y]

linind_lfa_locations    = [];

for m = 1:N_lfa_clusters
    x0 = lfa_clusters_centers_x(m);
    y0 = lfa_clusters_centers_y(m);
    % setting linind_points_in_circle
    linind_points_in_circle = pointsincircle(x0,y0,...
        lfa_cluster_radius,N_lfas_in_cluster,size_x,size_y,rand_array);

    linind_lfa_locations    = [linind_lfa_locations;linind_points_in_circle];
end 

A0 = zeros(size(rand_array));
A0(linind_lfa_locations) = 1;

figure(8)
hold on
spy(A0)
hold off

%%% cd45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd45_parameters = default_parameters.Cells.Tcell.molecules.cd45;

% cd45_type_number         = cd45_parameters.type_number;
cd45_global_density      = cd45_parameters.global_density;
cd45_cluster_density     = cd45_parameters.cluster_density;
cd45_density_of_clusters = cd45_parameters.density_of_clusters;




Tcell_molecules_locations = [];
end









