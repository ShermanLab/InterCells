function initial_id_linind_type_Z_E0 = initialTCELLdata(default_parameters,...
    initial_Tcell_locations)

linind_TCR = initial_Tcell_locations.tcr;

%%% reading from default_parameters %%% 
%%% Tcell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
type_tcr   = default_parameters.Cells.Tcell.molecules.tcr.type_number;
type_lfa   = default_parameters.Cells.Tcell.molecules.lfa.type_number;
type_cd45  = default_parameters.Cells.Tcell.molecules.cd45.type_number;

%%% putting linind and type together %%%%%%%%%%%%%%%%%%%%%%
linind_type_TCR   = [linind_TCR  ,type_tcr*ones(size(linind_TCR))];
linind_type_LFA   = [linind_LFA  ,type_lfa*ones(size(linind_LFA))];
linind_type_CD45  = [linind_CD45 ,type_cd45*ones(size(linind_CD45))];

linind_type = cat(1,linind_type_TCR,...
                    linind_type_LFA,...
                    linind_type_CD45);

%%% excludes identical lininds %%%%%%%%%%%%%%%%%%%%%%%%%%%%



[linind,unique_index,~] = unique(linind_type(:,1),'stable');
linind_type = [linind,linind_type(unique_index,2)];
%%% gives serial id to the proteins %%%%%%%%%%%%%%%%%%%%%%%
id = (1:size(linind_type,1))';
%%% putting id, linind and type together %%%%%%%%%%%%%%%%%%
id_linind_type = [id, linind_type];
%%% giving the height of the membrane at the proteins locations
Z = L(linind);
%%% setting the energy of each protein to zero %%%%%%%%%%%%
E0 = zeros(size(linind));
%%% putting id, linind, type and E0 together %%%%%%%%%%%%%%
id_linind_type_Z_E0 = [id_linind_type,Z,E0];

initial_id_linind_type_Z_E0 = id_linind_type_Z_E0;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



initial_id_linind_type_Z_E0 = [];

end