function default_Tcell_parameters = defaultTCELLparameters()

%%% name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Tcell.cellname   = 'T-cell';

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
Tcell.membrane       = defaultTCELLmembraneparameters();

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
% tcr
Tcell.molecules.tcr  = defaultTCRparameters();
% lfa 
Tcell.molecules.lfa  = defaultLFA1parameters();
% cd45 
Tcell.molecules.cd45 = defaultCD45parameters();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_Tcell_parameters = Tcell;
end















