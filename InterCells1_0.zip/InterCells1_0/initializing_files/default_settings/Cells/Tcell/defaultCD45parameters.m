function cd45_parameters = defaultCD45parameters()

%%% setting TCR default parameters
cd45.name                = 'CD45';
cd45.type_number         = 3;
cd45.color               = [1 0 0]; % RGB
% sizes
cd45.vertical_size       = 50; % nm
cd45.lateral_size        = 10; % nm
cd45.area_patches_5      = 9;  % #
cd45.area_patches_10     = 1;  % #
% potentials
cd45.potential_width     = 10;  % nm
cd45.binding_bottom      = cd45.vertical_size - cd45.potential_width/2; % nm
cd45.binding_top         = cd45.vertical_size + cd45.potential_width/2; % nm
cd45.binding_strength    = -10;  % KT
cd45.spring_k            = 0.1;  % KT/nm^2
% diffusion
cd45.diffusion_constant  = 0.01; % um^2/sec
% clusters
cd45.global_density      = 300;  % #/um^2
cd45.cluster_density     = 1000; % #/um^2
cd45.density_of_clusters = 0.8;  % #/um^2
% force membrane to molecule height
cd45.force_z             = 0; % 0/1

cd45_parameters = cd45;
end 