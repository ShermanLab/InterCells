function default_APC_parameters = defaultAPCparameters()

%%% name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
APC.cellname = 'APC';

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
APC.membrane       = defaultAPCmembraneparameters();

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
% pmhc
APC.molecules.pmhc  = defaultPMHCparameters();
% icam 
APC.molecules.icam  = defaultICAMparameters();
% apcm3 
APC.molecules.apcm3  = defaultAPCM3parameters();
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_APC_parameters = APC;
end















