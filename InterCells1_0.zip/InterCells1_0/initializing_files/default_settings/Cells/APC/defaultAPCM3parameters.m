function apcm3_parameters = defaultAPCM3parameters()

%%% setting TCR default parameters
apcm3.name                = 'm3';
apcm3.type_number         = 1;
apcm3.color               = [0.5 0.5 1]; % RGB
% sizes
apcm3.vertical_size       = 0; % nm
apcm3.lateral_size        = 10; % nm
apcm3.area_patches_5      = 4;  % #
apcm3.area_patches_10     = 1;  % #
% potentials
apcm3.potential_width     = 0;  % nm
apcm3.binding_bottom      = apcm3.vertical_size - apcm3.potential_width/2; % nm
apcm3.binding_top         = apcm3.vertical_size + apcm3.potential_width/2; % nm
apcm3.binding_strength    = 0;  % KT
apcm3.spring_k            = 0; % ?
% diffusion
apcm3.diffusion_constant  = 0.01; % um^2/sec
% clusters
apcm3.global_density      = 1;  % #/um^2
apcm3.cluster_density     = 1; % #/um^2
apcm3.density_of_clusters = 1;    % #/um^2
% force membrane to molecule height
apcm3.force_z = 0; % 0/1

apcm3_parameters = apcm3;
end 