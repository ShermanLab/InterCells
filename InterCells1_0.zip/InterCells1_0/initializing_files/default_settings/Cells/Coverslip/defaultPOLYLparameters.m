function polyL_parameters = defaultPOLYLparameters()

%%% setting aCD45 default parameters
polyl.name                = 'aCD45';
polyl.type_number         = 1;
polyl.color               = [1 0.5 1]; % RGB
% sizes
polyl.vertical_size       = 0; % nm
polyl.lateral_size        = 10; % nm
polyl.area_patches_5      = 4;  % #
polyl.area_patches_10     = 1;  % #
% potentials
polyl.potential_width     = 0;  % nm
polyl.binding_bottom      = polyl.vertical_size - polyl.potential_width/2; % nm
polyl.binding_top         = polyl.vertical_size + polyl.potential_width/2; % nm
polyl.binding_strength    = -4;  % KT
polyl.spring_k            = 0; % ?
% diffusion
polyl.diffusion_constant  = 0; % um^2/sec
% clusters
polyl.global_density      = 10000;  % #/um^2
polyl.cluster_density     = 10000; % #/um^2
polyl.density_of_clusters = 1;    % #/um^2
% force membrane to molecule height
polyl.force_z = 0; % 0/1

polyL_parameters = polyl;
end 