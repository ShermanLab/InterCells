function default_Coverslip_parameters = defaultCoverslipparameters(default_parameters)

%%% name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_Coverslip_parameters.name = 'Coverslip';
%%% array %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
array_size_x = default_parameters.global.array_size_x;
array_size_y = default_parameters.global.array_size_y;
pixel_size   = default_parameters.global.pixel_size;

%%% APC membrane %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_Coverslip_parameters.membrane.rigidity          = 10^6; %25; % KT
default_Coverslip_parameters.membrane.min_rigidity      = 10^6; % KT
default_Coverslip_parameters.membrane.max_rigidity      = 10^6; % KT
default_Coverslip_parameters.membrane.local_rigidity    = 0; 

default_Coverslip_parameters.membrane.diffusivity       = 0; 
default_Coverslip_parameters.membrane.min_diffusivity   = 0.0; 
default_Coverslip_parameters.membrane.max_diffusivity   = 0; 
default_Coverslip_parameters.membrane.local_diffusivity = 0; 

default_Coverslip_parameters.membrane.Z0                = 0; % nm
default_Coverslip_parameters.membrane.min_Z             = 0; % nm 
default_Coverslip_parameters.membrane.max_Z             = 0; % nm
default_Coverslip_parameters.membrane.dz                = 0; % nm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% spring_proteins %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_Coverslip_parameters.spring_proteins = 1;
if default_Coverslip_parameters.spring_proteins
    
    default_Coverslip_parameters.molecules.alpha_cd3.spring_k = ...
        1*0.1*default_Coverslip_parameters.membrane.rigidity/...
        pixel_size^2; % 10; %0.1
    default_Coverslip_parameters.molecules.alpha_cd11.spring_k = ...
        1*0.1*default_Coverslip_parameters.membrane.rigidity/...
        pixel_size^2; % 10; %0.1

end


%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for fold_generate_points = 1:1
    array_size_x_microns = array_size_x*pixel_size/1000;
    array_size_y_microns = array_size_y*pixel_size/1000;
    area_microns = array_size_x_microns*array_size_y_microns;
    ligand_density = 300; %300; % #/um^2
    rand_array = rand(array_size_x,array_size_y);
    ind1  = [1:array_size_x*array_size_y]';
    rand1 = rand_array(:);
    sorted_ind1_rand1 = sortrows([ind1,rand1],2);
    
end
%%% polyLlysine %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_polyL = 1:1
    default_Coverslip_parameters.use_polyLlysine               = 1; % 0; %
    default_Coverslip_parameters.polyLlysine_binding_strength  = -4; %-5; %-1;
end
%%% alpha_cd3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_alpha_cd3 = 1:1
    default_Coverslip_parameters.molecules.alpha_cd3.type_number        = 2;
    default_Coverslip_parameters.molecules.alpha_cd3.binding_strength   = -10; % KT
    default_Coverslip_parameters.molecules.alpha_cd3.color              = [0.6 0.8 0.6]; %[0 0.6 0];
    default_Coverslip_parameters.molecules.alpha_cd3.lateral_size       = 10; % nm
    default_Coverslip_parameters.molecules.alpha_cd3.vertical_size      = 0; % nm
    default_Coverslip_parameters.molecules.alpha_cd3.area_patches_5     = 1; % nm
    default_Coverslip_parameters.molecules.alpha_cd3.area_patches_10    = 1; % nm
    default_Coverslip_parameters.molecules.alpha_cd3.diffusion_constant = 0.0; % um^2/sec
    default_Coverslip_parameters.molecules.alpha_cd3.sigma_pixels       = ...
        sqrt(4*default_Coverslip_parameters.molecules.alpha_cd3.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
    default_Coverslip_parameters.molecules.alpha_cd3.density            = 300; %1; %1000; %300; %  % #/um^2

    N1 = default_Coverslip_parameters.molecules.alpha_cd3.density*area_microns;
    
    linind_alpha_cd3 = sorted_ind1_rand1(1:N1,1);
    
    [default_Coverslip_parameters.molecules.alpha_cd3.locations(:,1),...
     default_Coverslip_parameters.molecules.alpha_cd3.locations(:,2)] = ...
     ind2sub([array_size_x,array_size_y],linind_alpha_cd3);
end % fold_alpha_cd3
%%% alpha_cd11 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_alpha_cd11 = 1:1
    default_Coverslip_parameters.molecules.alpha_cd11.type_number        = 3;
    default_Coverslip_parameters.molecules.alpha_cd11.binding_strength   = -20; %-10 KT
    default_Coverslip_parameters.molecules.alpha_cd11.color              = [0.0 0.8 0.8];
    default_Coverslip_parameters.molecules.alpha_cd11.lateral_size       = 10; % nm
    default_Coverslip_parameters.molecules.alpha_cd11.vertical_size      = 0; % nm
    default_Coverslip_parameters.molecules.alpha_cd11.area_patches_5     = 1; % nm
    default_Coverslip_parameters.molecules.alpha_cd11.area_patches_10    = 1; % nm
    default_Coverslip_parameters.molecules.alpha_cd11.diffusion_constant = 0.0; % um^2/sec
    default_Coverslip_parameters.molecules.alpha_cd11.sigma_pixels       = ...
        sqrt(4*default_Coverslip_parameters.molecules.alpha_cd11.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
    default_Coverslip_parameters.molecules.alpha_cd11.density            = 0; % #/um^2

    N2 = default_Coverslip_parameters.molecules.alpha_cd11.density*area_microns;
    
    linind_alpha_cd11 = sorted_ind1_rand1(N1+1:N1+N2,1);
    
    [default_Coverslip_parameters.molecules.alpha_cd11.locations(:,1),...
     default_Coverslip_parameters.molecules.alpha_cd11.locations(:,2)] = ...
     ind2sub([array_size_x,array_size_y],linind_alpha_cd11);
end % fold_alpha_cd11
%%% alpha_cd45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for fold_alpha_cd45 = 1:1
    default_Coverslip_parameters.molecules.alpha_cd45.type_number        = 4;
    default_Coverslip_parameters.molecules.alpha_cd45.binding_strength   = -10; % KT
    default_Coverslip_parameters.molecules.alpha_cd45.color              = [0.6 0 0];
    default_Coverslip_parameters.molecules.alpha_cd45.lateral_size       = 10; % nm
    default_Coverslip_parameters.molecules.alpha_cd45.vertical_size      = 0; % nm
    default_Coverslip_parameters.molecules.alpha_cd45.area_patches_5     = 1; % nm
    default_Coverslip_parameters.molecules.alpha_cd45.area_patches_10    = 1; % nm
    default_Coverslip_parameters.molecules.alpha_cd45.diffusion_constant = 0.0; % um^2/sec
    default_Coverslip_parameters.molecules.alpha_cd45.sigma_pixels       = ...
        sqrt(4*default_Coverslip_parameters.molecules.alpha_cd45.diffusion_constant*...
        default_parameters.global.iteration_time)*1000/...
        default_parameters.global.pixel_size; % [pixels]
    default_Coverslip_parameters.molecules.alpha_cd45.density            = 0; % #/um^2

    N3 = default_Coverslip_parameters.molecules.alpha_cd45.density*area_microns;

    linind_alpha_cd45 = sorted_ind1_rand1(N1+N2+1:N1+N2+N3,1);
    
    [default_Coverslip_parameters.molecules.alpha_cd45.locations(:,1),...
     default_Coverslip_parameters.molecules.alpha_cd45.locations(:,2)] = ...
     ind2sub([array_size_x,array_size_y],linind_alpha_cd45);

end % fold_alpha_cd45





