function default_COVERSLIP_parameters = defaultCOVERSLIPparameters()

%%% name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
COVERSLIP.cellname = 'Coverslip';

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
COVERSLIP.membrane        = defaultCOVERSLIPmembraneparameters();

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
% acd3
COVERSLIP.molecules.acd3  = defaultACD3parameters();
% acd11
COVERSLIP.molecules.acd11 = defaultACD11parameters();
% acd45
COVERSLIP.molecules.acd45 = defaultACD45parameters();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_COVERSLIP_parameters = COVERSLIP;
end















