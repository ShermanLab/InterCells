function acd11_parameters = defaultACD11parameters()

%%% setting TCR default parameters
acd11.name                = 'aCD11';
acd11.type_number         = 2;
acd11.color               = [0.8 0.8 1]; % RGB
% sizes
acd11.vertical_size       = 0; % nm
acd11.lateral_size        = 10; % nm
acd11.area_patches_5      = 4;  % #
acd11.area_patches_10     = 1;  % #
% potentials
acd11.potential_width     = 0;  % nm
acd11.binding_bottom      = acd11.vertical_size - acd11.potential_width/2; % nm
acd11.binding_top         = acd11.vertical_size + acd11.potential_width/2; % nm
acd11.binding_strength    = -20;  % KT
acd11.spring_k            = 0; % ?
% diffusion
acd11.diffusion_constant  = 0; % um^2/sec
% clusters
acd11.global_density      = 0; %300;  % #/um^2
acd11.cluster_density     = 1000; % #/um^2
acd11.density_of_clusters = 1;    % #/um^2
% force membrane to molecule height
acd11.force_z = 0; % 0/1

acd11_parameters = acd11;
end 