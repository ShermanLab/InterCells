% analyze_results


postprocess  = 0; % 1
make_images  = 0;
make_movie   = 0;


%     'MSVC' 'RLE'
% end % ROI_number
%%% set time string
mytime1    = datevec(now);
mytime2    = mytime1(1:5);
mytimestr2 = num2str(mytime2);
mytimestr  = strrep(mytimestr2,' ',''); % modifiedStr = strrep(origStr, oldSubstr, newSubstr)
save_name = ['RUNS_RESULTS_',mytimestr];
if save_results
    save(save_name, 'RUNS_RESULTS');
end


% movie2avi(mov, ['movie',int2str(run1),'.avi'], 'compression', 'None');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
run = 1;
results_folder_name = save_name;
data_times = 0:100;
if postprocess
    %%% results2images %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if make_images
        images_times = [0 1 5 20 100];
        results_folder_name = save_name;
        results2images(results_folder_name,images_times,run,parameters);
    end
    
    %%% results2movie %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if make_movie
        frames_times = 0:100;
        results_folder_name = save_name;
        results2movie(results_folder_name,frames_times,run,parameters);
    end
    
    %%% analize_results(runs_result) %%%%%%%%%%%%%%%%%%%%%%
    data_times = 0:100;
    %     results2analyses(results_folder_name,data_times,1,parameters);
    %%% g(r) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %     GR = results2gr(results_folder_name,data_times,1,parameters);
    
    %%% depletions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %     DEPLETIONS = gr2depletions(GR,parameters);
    
    %%% density(R) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% erosion, dilation
    DILATIONS = results2dilations(results_folder_name,data_times,1,parameters);
    EROSIONS2 = results2erosions(results_folder_name,data_times,1,parameters);
    DENSITIES = results2densities(results_folder_name,data_times,1,DILATIONS,EROSIONS2);
    plot_DENSITIES(DENSITIES);
    
    %%% Minkowsky functionals %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    data_times = 0:100; %[10 20 30 40 50 60 70];
    MINKOWSKI     = results2minkowski(results_folder_name,data_times,1,parameters);
    normMINKOWSKI = results2normminkowski(results_folder_name,data_times,1,parameters);
    plot_MINKOWSKI(MINKOWSKI)
    plot_normMINKOWSKI(normMINKOWSKI)
    
    %%% combined plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end









