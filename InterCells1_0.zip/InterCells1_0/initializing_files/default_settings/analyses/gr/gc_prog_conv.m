function gr = gc_prog_conv(linind_data1,linind_data2,c1,c2,size_x,size_y,linind_rings)

A1_points_np1 = zeros(size_x,size_y);
A1_points_np1(linind_data1) = c1; % number of points1 in every pixel

max_R = length(linind_rings);
gr = zeros(1,max_R);

for ring_radius = 1:max_R % 0:max_R-1 % 
    linind_one_ring_points = linind_rings{ring_radius};
    frame_size = 2*(ring_radius-1) + 1;
    h = zeros(frame_size); 
    h(linind_one_ring_points) = 1; 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    A1convh_np1 = conv2(A1_points_np1,h,'same');
    number_of_points2_in_rings1 = sum(sum(A1convh_np1(linind_data2).*c2));
    rings_areas_np = sum(sum(A1convh_np1));

    normalization = rings_areas_np*sum(c2)/((size_x)*(size_y));
    gr(ring_radius) = number_of_points2_in_rings1./normalization;
end
end



