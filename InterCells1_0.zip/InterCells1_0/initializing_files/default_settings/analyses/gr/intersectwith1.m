function depletion = intersectwith1(gr,parameters)

max_R = parameters.analyses.max_R;
depletion = max_R; % 0
r = 0:max_R;
smooth_range = 5;
smoothed_gr  = smooth(gr,smooth_range);
y = 1;
[x_int,~] = polyxpoly(r,smoothed_gr,[0 max_R],[y y]);
if ~isnan(x_int)
    depletion = min(x_int);
end
end

