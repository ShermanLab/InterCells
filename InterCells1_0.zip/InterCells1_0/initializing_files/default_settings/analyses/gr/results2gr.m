function GR = results2gr(folder_name,data_times,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(folder_name);
% t = 0;
clockname = folder_name(14:end);
%%% parameters
% a      = parameters.global.pixel_size;
linind_rings = parameters.analyses.linind_rings;
max_R        = parameters.analyses.max_R;
c2 = 1;
c3 = 1;
c4 = 1;

GR  = cell(3,3);
G22 = zeros(size(data_times,2),max_R+1);
G23 = zeros(size(data_times,2),max_R+1);
G32 = zeros(size(data_times,2),max_R+1);
G33 = zeros(size(data_times,2),max_R+1);

G24 = zeros(size(data_times,2),max_R+1);
G42 = zeros(size(data_times,2),max_R+1);
G44 = zeros(size(data_times,2),max_R+1);

G34 = zeros(size(data_times,2),max_R+1);
G43 = zeros(size(data_times,2),max_R+1);

%%% reading data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
size_x      = global_data.array_size_x;
size_y      = global_data.array_size_y;
L           = global_data.L;

for t = data_times(1:end)
    %%% TOP
    TOP_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.TOP;
    id_linind_type_Z_E_TOP  = TOP_data.id_linind_type_Z_E_TOP;
    id       = id_linind_type_Z_E_TOP(:,1);
    id_dype2 = id(id_linind_type_Z_E_TOP(:,3) == 2);
    id_dype3 = id(id_linind_type_Z_E_TOP(:,3) == 3);
    id_dype4 = id(id_linind_type_Z_E_TOP(:,3) == 4);
    id_dype5 = id(id_linind_type_Z_E_TOP(:,3) == 5);
    id_dype6 = id(id_linind_type_Z_E_TOP(:,3) == 6);
    
    linind_type2  = id_linind_type_Z_E_TOP(id_dype2,2);
    linind_type3  = id_linind_type_Z_E_TOP(id_dype3,2);
    linind_type4  = id_linind_type_Z_E_TOP(id_dype4,2);
%     linind_type5  = id_linind_type_Z_E_TOP(id_dype5,2);
%     linind_type6  = id_linind_type_Z_E_TOP(id_dype6,2);
       
    gr22 = gc_prog_conv(linind_type2,linind_type2,c2,c2,size_x,size_y,linind_rings);
    gr23 = gc_prog_conv(linind_type2,linind_type3,c2,c3,size_x,size_y,linind_rings);
    gr32 = gc_prog_conv(linind_type3,linind_type2,c3,c2,size_x,size_y,linind_rings);
    gr33 = gc_prog_conv(linind_type3,linind_type3,c3,c3,size_x,size_y,linind_rings);
    
    gr24 = gc_prog_conv(linind_type2,linind_type4,c2,c4,size_x,size_y,linind_rings);
    gr42 = gc_prog_conv(linind_type4,linind_type2,c4,c2,size_x,size_y,linind_rings);
    gr44 = gc_prog_conv(linind_type4,linind_type4,c4,c4,size_x,size_y,linind_rings);

    gr34 = gc_prog_conv(linind_type3,linind_type4,c3,c4,size_x,size_y,linind_rings);
    gr43 = gc_prog_conv(linind_type4,linind_type3,c4,c3,size_x,size_y,linind_rings);
    
    G22(t+1,:) = gr22;
    G23(t+1,:) = gr23;
    G24(t+1,:) = gr24;
        
    G32(t+1,:) = gr32;
    G33(t+1,:) = gr33;
    G34(t+1,:) = gr34;
    
    G42(t+1,:) = gr42;
    G43(t+1,:) = gr43;
    G44(t+1,:) = gr44;
    
end

GR{1,1} = G22;
GR{1,2} = G23;
GR{1,3} = G24;

GR{2,1} = G32;
GR{2,2} = G33;
GR{2,3} = G34;

GR{3,1} = G42;
GR{3,2} = G43;
GR{3,3} = G44;

%%% plot test %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for p = 1:1
    % G22 = GR{1,1};
    % G23 = GR{1,2};
    % G24 = GR{1,3};
    % 
    % G32 = GR{2,1};
    % G33 = GR{2,2};
    % G34 = GR{2,3};
    % 
    % G42 = GR{3,1};
    % G43 = GR{3,2};
    % G44 = GR{3,3};

    figure(3)
    clf
    subplot(3,3,1)
    surf(G22','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,2)
    surf(G23','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,3)
    surf(G24','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,4)
    surf(G32','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,5)
    surf(G33','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,6)
    surf(G34','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,7)
    surf(G42','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,8)
    surf(G43','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,9)
    surf(G44','EdgeColor','none')
    view(2)
    axis tight
end


















