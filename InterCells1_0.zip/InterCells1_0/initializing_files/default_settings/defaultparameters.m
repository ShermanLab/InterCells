function default_parameters = defaultparameters()

%%% global %%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.global          = defaultglobalparameters();

%%% T-cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.Cells.Tcell     = defaultTCELLparameters;

%%% APC %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.Cells.APC       = defaultAPCparameters;

%%% Coverslip %%%%%%%%%%%%%%%%%%%%%%%%%
parameters.Cells.Coverslip = defaultCOVERSLIPparameters;

%%% Analyses %%%%%%%%%%%%%%%%%%%%%%%%%%
parameters.analyses        = defaultANALYSESparameters();

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_parameters = parameters;
end















