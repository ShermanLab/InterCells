function global_simulation_data = initialglobalsimulationdata(simulation_data,parameters)

array_size_x = parameters.global.array_size_x;
array_size_y = parameters.global.array_size_y;

K_Cell1 = simulation_data.Cell1.K;
K_Cell2 = simulation_data.Cell2.K;
K       = (K_Cell1.*K_Cell2)./(K_Cell1 + K_Cell2);

L       = parameters.global.membrane.z0*ones(array_size_x,array_size_y);

E_membrane = Emembrane(L,K,parameters);

global_simulation_data.array_size_x = array_size_x;
global_simulation_data.array_size_y = array_size_y;
global_simulation_data.L            = L;
global_simulation_data.K            = K;
global_simulation_data.E_membrane   = E_membrane;




