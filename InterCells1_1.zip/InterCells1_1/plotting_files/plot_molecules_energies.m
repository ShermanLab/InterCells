function plot_molecules_energies(simulation_data,parameters)


id_linind_type_Z_E_Cell1 = simulation_data.Cell1.molecules;
iter   = simulation_data.iter;

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

Z1      = simulation_data.Cell1.membrane.Z;

U1_1 = parameters.Cells.Cell1.molecules.type1.binding_strength;
U1_2 = parameters.Cells.Cell1.molecules.type2.binding_strength;
U1_3 = parameters.Cells.Cell1.molecules.type3.binding_strength;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E_molecules = zeros(size(Z1));
E_molecules(id_linind_type_Z_E_Cell1(:,2)) = id_linind_type_Z_E_Cell1(:,5);

%%% plot %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hFig = figure(15);
clf
set(hFig, 'Position', [915 100 800 800])

xplot = 0:size_x;
yplot = 0:size_y;
[Xplot,Yplot] = meshgrid(xplot,yplot);
Lplot0 = [Z1,Z1(:,end)];
Lplot  = [Lplot0;Lplot0(end,:)];
E_molecules_plot0 = [E_molecules,E_molecules(:,end)];
E_molecules_plot  = [E_molecules_plot0;E_molecules_plot0(end,:)];

%%% 
h1 = pcolor(Xplot,Yplot,E_molecules_plot');
set(h1, 'EdgeColor', 'none');

hold on
axis equal
axis([0 size_x 0 size_y]);
min_E = min([U1_1,U1_2,U1_3]);
max_E = 10;
caxis([min_E max_E])
colorbar
set(gcf, 'renderer', 'zbuffer');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cdx = 0.5;
cdy = 0.5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
title(['\fontsize{16}{\color[rgb]{0 0 0}Proteins energies,   t = ',int2str(ceil(iter/100)),' sec}' ])
xlabel('x (nm)','fontsize',14)
ylabel('y (nm)','fontsize',14)
set(gca,'XTick',0:50:size_x)
set(gca,'XTickLabel',{a*[0:50:size_x]})
set(gca,'YTick',0:50:size_y)
set(gca,'YTickLabel',{a*[0:50:size_y]})

hold off






