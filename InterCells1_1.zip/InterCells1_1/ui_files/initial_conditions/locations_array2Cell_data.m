function Cell_data = locations_array2Cell_data(...
    parameters,locations_array,cn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data
output     : simulation_data
called by  : run_simulation
calling    : Emembrane
description: calculates the new locations of the molecules
and the new membranes values
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

size_x = size(locations_array,1);
size_y = size(locations_array,2);
n_types = max(max(locations_array));

%%% set initial membrane Z
Z = ones(size_x,size_y)*parameters.Cells(cn).membrane.Z0;

linindm_all = [];
typesm_all  = [];
zm_all      = [];
idm_all     = [];
e           = [];

for tn = 1:n_types
    
    %%% set lininds vector
    linindm     = find(locations_array == tn);
    linindm_all = [linindm_all;linindm];
    
    %%% set types vector
    typesm      = tn*ones(size(linindm));
    typesm_all  = [typesm_all;typesm];
        
    %%% set z vector
    h           = parameters.Cells(cn).molecule_type(tn).vertical_size;
    z           = h*ones(size(linindm));...
    zm_all      = [zm_all;z];   

end

%%% set id vector
idm_all = 1:size(linindm_all,1);

%%% set e vector
e   = zeros(size(idm_all));

%%% set membrane height at molecules locations
Z(linindm_all) = zm_all;

%%% set initial rigidity
K = ones(size_x,size_y)*parameters.Cells(cn).membrane.rigidity;

%%% set initial diffusivity
D = ones(size_x,size_y)*parameters.Cells(cn).membrane.diffusivity;

%%% set initial energy
E = zeros(size_x,size_y);

%%% set simulation_data.Cells(cn)

Cell_data.Z    = Z;
Cell_data.K    = K;
Cell_data.D    = D;
Cell_data.Emem = E;
Cell_data.Emol = E;
Cell_data.LOC  = locations_array;

if n_types > 0
    Cell_data.molecules(idm_all,1) = idm_all;
    Cell_data.molecules(idm_all,2) = linindm_all;
    Cell_data.molecules(idm_all,3) = typesm_all;
    Cell_data.molecules(idm_all,4) = zm_all;
    Cell_data.molecules(idm_all,5) = e;
else
    Cell_data.molecules(idm_all,1) = 1;
    Cell_data.molecules(idm_all,2) = 1;
    Cell_data.molecules(idm_all,3) = 1;
    Cell_data.molecules(idm_all,4) = 0;
    Cell_data.molecules(idm_all,5) = 0;
end

end










