function picked_name = update_cell2_name(cellname_pick) % src,ev
%     picked_name
%     cellname_pick = get(get(bg,'SelectedObject'),'String');
    if strcmp(cellname_pick,'APC')
        picked_name = 'APC';
    elseif strcmp(cellname_pick,'Coverslip')
        picked_name = 'Coverslip';
    end
    
end