function simulation_data = ...
    ui_initial_locations_Tcell_Coverslip(...
    parameters,old_simulation_data,locations_array1,locations_array2)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data
output     : simulation_data
called by  : ui_main
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% set new locations_arrays size 
size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;

%%% initialize new locations_arrays and new simulation_data
locations_array1 = zeros(size_x,size_y);
locations_array2 = zeros(size_x,size_y);

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

fs8  = 8;
fs10 = 10;
fs12 = 12;

gapx = 2;
gapy = 2;

px   = x0+100;
py   = y0+200;
pw   = 1000;
ph   = 800; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 130;
pbh  = 30;

% bgh   = ph;

%%% panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(8);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');
    set(p,'Name','Initial locations','NumberTitle','off');
    
% Title 
uicontrol(p,'Style','text',...
  'String','Initial locations',...
  'FontSize',24,...
  'Position',[ph/2-0 ph-60 300 50]);

%%% text1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
text1 = uicontrol(p,'Style','text',...
  'String','Cell1 molecules',...
  'FontSize',fs12,...
  'Position',[2 ph*0.88 pbw pbh]);

%%% text2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
text2 = uicontrol(p,'Style','text',...
  'String','Cell2 molecules',...
  'FontSize',fs12,...
  'Position',[2 ph*0.72 pbw pbh]);

%%% button group %%%%%%%%%%%%%%%%%%%%%%
bg = uibuttongroup(p,'visible','on',...
  'Position',[0 0 1 1]);

%%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cells(1) molecule_type(1) %%%%%%%%%
pb1_1 = uicontrol(bg,'Style','PushButton',...
  'String',parameters.Cells(1).molecule_type(1).name,...
  'FontSize',fs10,...
  'Position',[gapx ph*0.88-1*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(1).molecule_type(1).color,...
  'Callback',@points1_1);

%%% @points1_1 %%%%%%%%%%%%%%%%%%%%%%%%
function points1_1(varargin)
    locations_array1 = make_locations_array(...
        parameters,locations_array1,1,1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(1) molecule_type(2) %%%%%%%%%
pb1_2 = uicontrol(bg,'Style','PushButton',...
  'String',parameters.Cells(1).molecule_type(2).name,...
  'FontSize',fs10,...
  'Position',[gapx ph*0.88-2*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(1).molecule_type(2).color,...
  'Callback',@points1_2);

%%% @points1_2 %%%%%%%%%%%%%%%%%%%%%%%%
function points1_2(varargin)
    locations_array1 = make_locations_array(...
        parameters,locations_array1,1,2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(1) molecule_type(3) %%%%%%%%%
pb1_3 = uicontrol(bg,'Style','PushButton',...
  'String',parameters.Cells(1).molecule_type(3).name,...
  'FontSize',fs10,...
  'Position',[gapx ph*0.88-3*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(1).molecule_type(3).color,...
  'Callback',@points1_3);

%%% @points1_3 %%%%%%%%%%%%%%%%%%%%%%%%
function points1_3(varargin)
    locations_array1 = make_locations_array(...
        parameters,locations_array1,1,3);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cells(2) molecule_type(1) %%%%%%%%%
pb2_1 = uicontrol(bg,'Style','PushButton',...
  'String',parameters.Cells(2).molecule_type(1).name,...
  'FontSize',fs10,...
  'Position',[gapx ph*0.88-5*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(2).molecule_type(1).color,...
  'Callback',@points2_1);

%%% @points2_1 %%%%%%%%%%%%%%%%%%%%%%%%
function points2_1(varargin)
    locations_array2 = make_locations_array(...
        parameters,locations_array2,2,1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(2) molecule_type(2) %%%%%%%%%
pb2_2 = uicontrol(bg,'Style','PushButton',...
  'String',parameters.Cells(2).molecule_type(2).name,...
  'FontSize',fs10,...
  'Position',[gapx ph*0.88-6*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(2).molecule_type(2).color,...
  'Callback',@points2_2);

%%% @points2_2 %%%%%%%%%%%%%%%%%%%%%%%%
function points2_2(varargin)
    locations_array2 = make_locations_array(...
        parameters,locations_array2,2,2);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(2) molecule_type(3) %%%%%%%%%
pb2_3 = uicontrol(bg,'Style','PushButton',...
  'String',parameters.Cells(2).molecule_type(3).name,...
  'FontSize',fs10,...
  'Position',[gapx ph*0.88-7*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(2).molecule_type(3).color,...
  'Callback',@points2_3);

%%% @points2_3 %%%%%%%%%%%%%%%%%%%%%%%%
function points2_3(varargin)
    locations_array2 = make_locations_array(...
        parameters,locations_array2,2,3);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% plot molecules locations %%%%%%%%%%
ox = 0.15; % ratio of x origin location
oy = 0.10; % ratio of y origin location
rw = 0.80; % ratio of subplot width
rh = 0.80; % ratio of subplot height

pos1 = [ox oy rw rh];
subp = subplot('Position',pos1);
set(gca,'position',pos1)
axis equal
axis([0 size_x 0 size_y])
box on

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(bg,'Style','pushbutton',...
  'String','Ok',...
  'FontSize',fs8,...
  'Position',[pbx pby pbw/2 pbh],...
  'Callback',@Ok_callback); 

%%% @Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Ok_callback(varargin)

    Cell_data1 = locations_array2Cell_data(...
    parameters,locations_array1,1);
    
    Cell_data2 = locations_array2Cell_data(...
    parameters,locations_array2,2);
    
    simulation_data.Cells(1) = Cell_data1;
    simulation_data.Cells(2) = Cell_data2;
    uiresume
    close(8)
    plot_ui_main(parameters,simulation_data);
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cancel_pb %%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pb = uicontrol(bg,'Style','pushbutton',...
  'String','Cancel',...
  'FontSize',fs8,...
  'Position',[pbx+pbw/2+gapx pby pbw/2 pbh],...
  'Callback',@Cancel);

%%% @Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cancel(varargin)
    
    simulation_data = old_simulation_data;
    close(8)
    plot_ui_main(parameters,simulation_data);
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align([text1],'Fixed',3,'Fixed',3)
align([text1 subp],'none','Top')
align([text1,pb1_1,pb1_2,pb1_3,...
       text2,pb2_1,pb2_2,pb2_3],'Left','Fixed',1)

align([Ok_pb],'Fixed',3,'Fixed',3)
align([Ok_pb,Cancel_pb],'Fixed',3,'Bottom')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

waitfor(Ok_pb)

end










