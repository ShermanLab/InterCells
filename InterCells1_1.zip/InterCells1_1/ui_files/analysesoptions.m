function analyses_options = analysesoptions()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : plotting_options
called by  : start_interface_simulation
calling    : none
description: sets what type of analyses to do after
the simulation ends
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
analyses_options.pair_correlation_function = 1;
analyses_options.pair_correlation_analyses = 1;
analyses_options.clusters                  = 0;
analyses_options.dilations                 = 0;
analyses_options.minkowski_functionals     = 0;
analyses_options.clustering                = 0;
analyses_options.entropy                   = 0;

end