function [molecules_data,clusters_data] = ui_clusters(results_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;
a        = parameters.global.pixel_size;
max_R    = parameters.analyses.max_R;
%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 5;
gapy = 5;

px   = x0+100;
py   = y0+100;
pw   = 800; %650;
ph   = 800; 

pbx  = 3;
pby  = 3;
pbw  = 95;
pbh  = 30;
cbh  = 25;

%%% figures locations %%%%%%%%%%%%%%%%%
ox1 = 0.08; % 0.50;
ox2 = 0.56; % 0.50;
oy1 = 0.08; % 0.50;
oy2 = 0.54;
rw  = 0.36;
rh  = 0.36;

pos0 = [ox1 oy2 rw rh];
pos1 = [ox1 oy1 rw rh];
pos2 = [ox2 oy1 rw rh];
pos3 = [ox2 oy2 rw rh];

%%% get molecules names %%%%%%%%%%%%%%%
% types_n1 = size(parameters.Cells(1).molecule_type(:),1);
% types_n2 = size(parameters.Cells(2).molecule_type(:),1);

molecules_names  = cell(2,3);
molecules_colors = cell(2,3);
clusters_data    = cell(2,3);

max_gr = 10;

for cn = 1:2 % cell number
    types_n = size(parameters.Cells(cn).molecule_type(:),1);
    for tn = 1:types_n % type number
        
        %%% names
        molecules_name = parameters.Cells(cn).molecule_type(tn).name;
        molecules_names{cn,tn} = molecules_name;
        
        %%% colors
        molecule_color = parameters.Cells(cn).molecule_type(tn).color;
        molecules_colors{cn,tn} = molecule_color;
        
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(23);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Clusters','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Clusters',...
    'FontSize',20,...
    'Position',[pw*0.33 ph-50 300 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',pos0); 

%%% Cell1 text %%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Cell1',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx rh*ph-(1*pbh+gapy) pbw pbh]);

%%% Cells(1) molecule_type(1) %%%%%%%%%
cb1_1 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{1,1},...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[gapx rh*ph-(2*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{1,1},...
     'Callback',{@checkBoxCallback,1});

%%% Cells(1) molecule_type(2) %%%%%%%%% 
cb1_2 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{1,2},...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[gapx rh*ph-(3*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{1,2},...
     'Callback',{@checkBoxCallback,2});

%%% Cells(1) molecule_type(3) %%%%%%%%%
cb1_3 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{1,3},...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[gapx rh*ph-(4*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{1,3},...
     'Callback',{@checkBoxCallback,3});

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cell2 text %%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Cell2',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[pbw+2*gapx rh*ph-(1*pbh+gapy) pbw pbh]);

%%% Cells(2) molecule_type(1) %%%%%%%%%
cb2_1 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{2,1},...
     'FontSize',fs3,...
     'Value',0,...
     'Position',[pbw+2*gapx rh*ph-(2*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{2,1},...
     'Callback',{@checkBoxCallback,4});

%%% Cells(2) molecule_type(2) %%%%%%%%% 
cb2_2 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{2,2},...
     'FontSize',fs3,...
     'Value',0,...
     'Position',[pbw+2*gapx rh*ph-(3*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{2,2},...
     'Callback',{@checkBoxCallback,5});

%%% Cells(1) molecule_type(3) %%%%%%%%%
cb2_3 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{2,3},...
     'FontSize',fs3,...
     'Value',0,...
     'Position',[pbw+2*gapx rh*ph-(4*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{2,3},...
     'Callback',{@checkBoxCallback,6});


%%% assigning choises %%%%%%%%%%%%%%%%%
function checkBoxCallback(varargin)
    
    molecules_data.checkbox(1,1) = get(cb1_1,'Value');
    molecules_data.checkbox(1,2) = get(cb1_2,'Value');
    molecules_data.checkbox(1,3) = get(cb1_3,'Value');

    molecules_data.checkbox(2,1) = get(cb2_1,'Value');
    molecules_data.checkbox(2,2) = get(cb2_2,'Value');
    molecules_data.checkbox(2,3) = get(cb2_3,'Value');

end

%%% @molecule1 %%%%%%%%%%%%%%%%%%%%%%%%




%%% @molecule2 %%%%%%%%%%%%%%%%%%%%%%%%

%%% plot_data %%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[gapx rw*pw-160 pbw pbh],...
    'Callback',@plot_data); 

function plot_data(varargin)
   
%%% start subplot %%%%
sp1 = subplot(2,2,3); 
set(gca,'position',pos1)
cla
%%%%%%%%%%%%%%%%%%%%%%   

    t = 1;
	for cn = 1:2
        for tn = 1:3
            if molecules_data.checkbox(cn,tn); 
                molecules_data.array = results_data{t}.Cells(cn).LOC == tn;
                molecules_data.color = parameters.Cells(cn).molecule_type(tn).color;
                molecules_data.name  = parameters.Cells(cn).molecule_type(tn).name;
                [X,Y] = find(molecules_data.array);

                %%% plot locations
                %%% get array size
                size_x  = size(molecules_data.array,1);
                size_y  = size(molecules_data.array,2);

                hold on
                plot(X,Y,'.','Color',molecules_data.color)
                hold off
                axis equal
                axis([0 size_x 0 size_y])
                box on
                
                title('Molecules locations','FontSize',fs4)
                set(gca,'XTick',0:50:size_x)
                set(gca,'YTick',0:50:size_y)
                set(gca,'XTickLabel',a*[0:50:size_x])
                set(gca,'YTickLabel',a*[0:50:size_y])

                xlabel('X (nm)','FontSize',fs3)
                ylabel('Y (nm)','FontSize',fs3)

                xlabel('r (nm)','FontSize',fs3)
                ylabel('g(r)'  ,'FontSize',fs3)
                
                
                
            end 
        end % tn
    end % cn
end



%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Crop_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Crop data',...
    'FontSize',fs2,...
    'Position',[pbw+2*gapx rw*pw-160 pbw pbh],...
    'Callback',@crop_data); 



%%% PCF_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
PCF_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Univariate PCF',...
    'FontSize',fs2,...
    'Position',[gapx rw*pw-195 pbw pbh],...
    'Callback',@calculate_pcf); 

%%% @calculate_pcf %%%%%%%%%%%%%%%%%%%%
function calculate_pcf(varargin)
    subplot(2,2,4)
    set(gca,'position',pos2)
    
    t = 1;
	for cn = 1:2
        for tn = 1:3
            if molecules_data.checkbox(cn,tn); 
                molecules_data.array = results_data{t}.Cells(cn).LOC == tn;
                molecules_data.color = parameters.Cells(cn).molecule_type(tn).color;
                molecules_data.name  = parameters.Cells(cn).molecule_type(tn).name;
                
                array1 = molecules_data.array;
                array2 = molecules_data.array;
                
                %%% calculate PCF
                gr = gr_arrays(array1,array2,parameters);
                
                %%% calculate cluster size
                cluster_size = intersectwith1(gr,parameters);
%                 molecules_data.cluster_size = cluster_size;
                hold on
                h1 = plot(1:max_R,gr(2:end),'.-','Color',molecules_data.color);
                plot([0 max_R],[1 1],'-k')
                plot(cluster_size,1,'o','Color',molecules_data.color,...
                    'MarkerSize',10,'LineWidth',2)
                hold off
                axis([0 max_R 0 max_gr])
                axis square
                box on
                
                title('Univariate PCF','FontSize',fs4)
                set(gca,'XTick',0:10:max_R)
                set(gca,'YTick',0:1:max_gr)
                set(gca,'XTickLabel',a*[0:10:max_R])
                set(gca,'YTickLabel',0:1:max_gr)

                xlabel('r (nm)','FontSize',fs3)
                ylabel('g(r)','FontSize',fs3)

%                 legend([h1],{[data1.name,'-',data2.name]})
            end
        end
    end

    uiresume
end % @calculate_pcf

%%% Clusters_pb %%%%%%%%%%%%%%%%%%%%%%%
Clusters_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Clusters',...
    'FontSize',fs2,...
    'Position',[gapx rw*pw-230 pbw pbh],...
    'Callback',@calculate_clusters); 

%%% @calculate_pcf %%%%%%%%%%%%%%%%%%%%
function calculate_clusters(varargin)
    subplot(2,2,2)
    set(gca,'position',pos3)
    
    t = 1;
	for cn = 1:2
        for tn = 1:3
            if molecules_data.checkbox(cn,tn);
                size_times = size(results_data,1);
                cluster_sizes = zeros(size(results_data));
                for t = 1:size_times;
                molecules_data.array = results_data{t}.Cells(cn).LOC == tn;
                molecules_data.color = parameters.Cells(cn).molecule_type(tn).color;
                molecules_data.name  = parameters.Cells(cn).molecule_type(tn).name;
                
                array1 = molecules_data.array;
                array2 = molecules_data.array;
                
                %%% calculate PCF
                gr = gr_arrays(array1,array2,parameters);
                %%% calculate cluster size
                cluster_size = intersectwith1(gr,parameters);
                cluster_sizes(t) = cluster_size;
%                 t
                end
                
                clusters_data{cn,tn} = cluster_sizes;
                
                hold on
                h1 = plot(cluster_sizes,[0:size_times-1],'.-','Color',molecules_data.color);
%                 1:max_R,
                hold off
                axis([0 100 0 size_times-1])
                axis square
                box on
                
                title('Cluster size','FontSize',fs4)
                set(gca,'XTick',0:10:max_R)
                set(gca,'YTick',0:10:size_times-1)
                set(gca,'XTickLabel',a*[0:10:max_R])
                set(gca,'YTickLabel',0:10:size_times-1)

                xlabel('Cluster diameter (nm)','FontSize',fs3)
                ylabel('t (sec)','FontSize',fs3)
            
%                 legend([h1],{[data1.name,'-',data2.name]})
            end
        end
    end
    
%     uiresume
end % @calculate_pcf




%%% Save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Save_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Save',...
    'FontSize',fs1,...
    'Position',[gapx gapy 0.6*pbw pbh],...
    'Callback',@Save_callback); 

%%% @Save_callback %%%%%%%%%%%%%%%%%%%%
function Save_callback(~,~)
    
%     results.data1 = data1;
%     results.data2 = data2;
%     results.gr    = gr;
%     results.t     = data1.t-1;
%     
%     save('results_gr.mat','results') 
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[pbw+gapx gapy 0.6*pbw pbh],...
    'Callback',@Close_callback); 

%%% 
molecules_data.checkbox(1,1) = get(cb1_1,'Value');
molecules_data.checkbox(1,2) = get(cb1_2,'Value');
molecules_data.checkbox(1,3) = get(cb1_3,'Value');

molecules_data.checkbox(2,1) = get(cb2_1,'Value');
molecules_data.checkbox(2,2) = get(cb2_2,'Value');
molecules_data.checkbox(2,3) = get(cb2_3,'Value');

%%% initialize subplots %%%%%%%%%%%%%%%
%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(gca,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% subplot2 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp2  = subplot(2,2,4); 
set(gca,'position',pos2)

title('Univariate PCF','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('r (nm)','FontSize',fs3)
ylabel('g(r)','FontSize',fs3)
box on
axis square

%%% subplot2 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp3  = subplot(2,2,2); 
set(gca,'position',pos3)

title('Cluster size','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('Cluster diameter (nm)','FontSize',fs3)
ylabel('t(sec)','FontSize',fs3)
box on
axis square

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(Save_pb,'Fixed',3,'Fixed',3);
align([Save_pb Close_pb],'Fixed',3,'Bottom');
% uiwait

end




