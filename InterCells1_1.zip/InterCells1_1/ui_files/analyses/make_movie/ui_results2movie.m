function ui_results2movie(results_folder_name,selected_times,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(results_folder_name);
% t = 0;
clockname = results_folder_name(9:end);
%%% parameters
% a      = parameters.global.pixel_size;
for t = selected_times(1:end)
    
    %%% global %%%%%%%%%%%%%%%%%%%%%%%%
    global_data = all_results.RUNS_RESULTS{1,run}{t+1,1}.global;
    size_x      = global_data.array_size_x;
    size_y      = global_data.array_size_y;
    L           = global_data.L;
    K           = global_data.K;
    E_membrane  = global_data.E_membrane;
    iter        = global_data.iter;
    
    %%% Cell1 %%%%%%%%%%%%%%%%%%%%%%%%%
    Cell1_data               = all_results.RUNS_RESULTS{1,1}{t+1,1}.Cell1;
    K1                       = Cell1_data.K;
    M1                       = Cell1_data.M;
    id_linind_type_Z_E_Cell1 = Cell1_data.id_linind_type_Z_E_Cell1;
    
    %%% Cell2 %%%%%%%%%%%%%%%%%%%%%%%%%
    Cell2_data               = all_results.RUNS_RESULTS{1,1}{t+1,1}.Cell2;
    K2                       = Cell2_data.K;
    M2                       = Cell2_data.M;
    id_linind_type_Z_E_Cell2 = Cell2_data.id_linind_type_Z_E_Cell2;
    
    %%% plotting %%%%%%%%%%%%%%%%%%%%%%
    hFig = figure(36);
    clf
    set(hFig, 'Position', [100 100 500 500]) % 800 800
    disp_ticks    = 0;
    disp_text     = 0;
    disp_colorbar = 0;
    msp = 5; % MarkerSize
    msc = 5; % MarkerSize
    
    % msx = 7;
    sx = 0.5;
    sy = 0.5;
    %%% plot data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for plot_data = 1:1
        %%% TOP = Tcell
        if strcmp(parameters.Cell1.name,'Tcell')
            
            color1_2 = parameters.Cell1.type2.color;
            color1_3 = parameters.Cell1.type3.color;
            color1_4 = parameters.Cell1.type4.color;
            color1_5 = parameters.Cell1.type5.color;
            color1_6 = parameters.Cell1.type6.color;
            
%             name1_2  = 'TCR';
%             name1_3  = 'LFA';
%             name1_4  = 'CD45';
%             name1_5  = 'CD43';
%             name1_6  = 'CD148';
            
        end
        %%% BOT = Coverslip
        if strcmp(parameters.Cell2.name,'Coverslip')
            
            color2_2 = parameters.Cell2.type2.color;
            color2_3 = parameters.Cell2.type3.color;
            color2_4 = parameters.Cell2.type4.color;
            
%             name2_2  = '\alphaCD3';
%             name2_3  = '\alphaCD11';
%             name2_4  = '\alphaCD45';
        end
        %%% BOT = APC
        if strcmp(parameters.Cell2.name,'APC')
            
            color2_2 = parameters.Cell2.type2.color;
            color2_3 = parameters.Cell2.type3.color;
            
%             name2_2  = 'pMHC';
%             name3_3  = 'ICAM';
        end
        %%% separating different Cell1 molecules to types %%%%%%%%%%%%
        m1_2 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 2),:);
        m1_3 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 3),:);
        m1_4 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 4),:);
        m1_5 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 5),:);
        m1_6 = id_linind_type_Z_E_Cell1((id_linind_type_Z_E_Cell1(:,3) == 6),:);
        
        %%% getting coordinates of the different types %%%%%%%%%%%%
        [X1_2,Y1_2] = ind2sub([size_x,size_y],m1_2(:,2));
        [X1_3,Y1_3] = ind2sub([size_x,size_y],m1_3(:,2));
        [X1_4,Y1_4] = ind2sub([size_x,size_y],m1_4(:,2));
        [X1_5,Y1_5] = ind2sub([size_x,size_y],m1_5(:,2));
        [X1_6,Y1_6] = ind2sub([size_x,size_y],m1_6(:,2));
        
        %%% separating different BOT proteims to types %%%%%%%%%%%%
        m2_2 = id_linind_type_Z_E_Cell2((id_linind_type_Z_E_Cell2(:,3) == 2),:);
        m2_3 = id_linind_type_Z_E_Cell2((id_linind_type_Z_E_Cell2(:,3) == 3),:);
        m2_4 = id_linind_type_Z_E_Cell2((id_linind_type_Z_E_Cell2(:,3) == 4),:);
        
        %%% getting coordinates for the different types %%%%%%%%%%%
        [X2_2,Y2_2] = ind2sub([size_x,size_y],m2_2(:,2));
        [X2_3,Y2_3] = ind2sub([size_x,size_y],m2_3(:,2));
        [X2_4,Y2_4] = ind2sub([size_x,size_y],m2_4(:,2));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% plotting proteins coordinates and L %%%%%%%%%%%%%%%%%%%
        
        %%% plot coverslip ligands %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         if strcmp(parameters.Cell2.name,'Coverslip')
%             plot(X2_2-sx,Y2_2-sy,'.','MarkerSize',msc,'color',color2_2) %dark
%             hold on
%             plot(X2_3-sx,Y2_3-sy,'.','MarkerSize',msc,'color',color2_3)
%             plot(X2_4-sx,Y2_4-sy,'.','MarkerSize',msc,'color',color2_4)
%         end
%         
%         if strcmp(parameters.Cell2.name,'APC')
%             plot(X2_2-sx,Y2_2-sy,'.','MarkerSize',msc,'color',color2_2) %dark
%             hold on
%             plot(X2_3-sx,Y2_3-sy,'.','MarkerSize',msc,'color',color2_3)
%         end
        %%% plot T-cell proteins %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        plot(X1_2-sx,Y1_2-sy,'.','MarkerSize',msp,'color',color1_2)
        hold on
        plot(X1_3-sx,Y1_3-sy,'.','MarkerSize',msp,'color',color1_3)
        plot(X1_4-sx,Y1_4-sy,'.','MarkerSize',msp,'color',color1_4)
%         plot(X1_5-sx,Y1_5-sy,'.','MarkerSize',msp,'color',color1_5)
%         plot(X1_6-sx,Y1_6-sy,'.','MarkerSize',msp,'color',color1_6)
        
        %%% plot active proteins %%%%%%%%%%%%%%%%%%%%%%%%%%
        axis([0 size_x 0 size_y])
        if disp_ticks
            set(gca,'XTick',0:50:size_x)
            set(gca,'XTickLabel',{a*[0:50:size_x]})
            set(gca,'YTick',0:50:size_y)
            set(gca,'YTickLabel',{a*[0:50:size_y]})
        end % disp_ticks
        % title(['\fontsize{16}{\color[rgb]{0 0 0}Coverslip, T-cell and L,   t = ',int2str(ceil(iter/100)),' sec}'])
        title(['\fontsize{14}{\color[rgb]{0 0 0}',...
            parameters.Cell1.name,' - ', parameters.Cell2.name ,...
            '   t = ',int2str(t),' sec}'])
        %     xlabel('x (nm)','fontsize',14)
        %     ylabel('y (nm)','fontsize',14)
        
        xplot = 0:size_x;
        yplot = 0:size_y;
        [Xplot,Yplot] = meshgrid(xplot,yplot);
        Lplot0 = [L,L(:,end)];
        Lplot  = [Lplot0;Lplot0(end,:)];
        %     cdx = 0.5;
        %     cdy = 0.5;
        
        %%% plot membrane %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        h1 = pcolor(Xplot,Yplot,Lplot'-51); %[1 1 0]flipud
        
        colormap(gray)
        % colormap(jet)
        set(h1, 'EdgeColor', 'none');
        
        zlim([-50 0])
        caxis([-50 0])
        if disp_colorbar
            colorbar
%             colorbar('YTickLabel',{0:5:50})
        end
        set(gcf, 'renderer', 'zbuffer');
                
        hold off
        axis equal
        axis([0 size_x 0 size_y])
        axis off
        view(2)
        
        box on
    end % for_plot_data
    
%     figure(36)
    mov(t+1) = getframe(gcf);
    
end

%%% save image %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
movie_savename = [parameters.Cell1.name,parameters.Cell2.name,'_',clockname];
movie2avi(mov, [movie_savename,'.avi'], 'compression', 'None');




