function [gr_min,gr_max] = complete_spatial_randomnes(arrayn,parameters,N_samples)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : arrayn, parameters, N_samples
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gr0 = gr_arrays(arrayn,arrayn,parameters);

%%% make rand arrays %%%%%%%%%%%%%%
%%% number of points 
N = sum(sum(arrayn));

gr_min = ones(size(gr0));
gr_max = ones(size(gr0));

for s = 1:N_samples

    %%% make rand arrays
    rand_array = rand(size(arrayn));

    %%% find X, Y, val
    [randX,randY,randval] = find(rand_array);

    %%% sort rows by val
    sorted1 = sortrows([randX,randY,randval],3);

    %%% get first N
    N_XYR = sorted1(1:N,1:2);

    %%% get linind
    N_linind = sub2ind(size(arrayn),N_XYR(:,1),N_XYR(:,2));

    %%% initialize sample arrays
    sample_arrayn = zeros(size(arrayn));

    %%% sample locations arrays 
    sample_arrayn(N_linind) = 1;

    %%% gr(sample locations arrays)
    gr = gr_arrays(sample_arrayn,sample_arrayn,parameters);

    gr_min(gr < gr_min) = gr(gr < gr_min);
    gr_max(gr > gr_max) = gr(gr > gr_max);
    
end


end