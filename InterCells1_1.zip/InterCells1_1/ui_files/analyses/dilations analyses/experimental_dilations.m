function linind_dilations = experimental_dilations(linind_data,size_x,size_y,max_R)

% max_R        = parameters.analyses.max_R;

A0 = zeros(size_x,size_y);
A0(linind_data) = 1;
% A1 = A0;
linind_dilations = cell(max_R+1,1);

for r = 0:max_R
    if r == 0
        A1 = A0;
        perim_A1 = A1;
    else
         h  = fspecial('disk', r);
         A1 = filter2(h,A0,'same');
         perim_A1 = bwmorph(A1,'remove');
    end
    linind_perim = find(perim_A1);
    linind_dilations{r+1} = linind_perim;
    %%%%%%%%%%%%%%%%%%%%%%%%%
    plot1 = 0;
    if plot1
        figure(7)
        clf
        spy(A1,'b')
        hold on
        spy(perim_A1,'r')
        hold off
        drawnow
%         pause
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%
end
% linind_dilations = linind_data;












