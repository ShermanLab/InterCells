function [normArea,normPerim,normEuler] = normminkowski(linind_data,parameters)

linind_rings = parameters.analyses.linind_rings;
max_R        = length(linind_rings);
size_x       = parameters.global.array_size_x;
size_y       = parameters.global.array_size_y;

N  = size(linind_data,1);

%%% setting array %%%%%%%%%%%
A1 = zeros(size_x,size_y);
A1(linind_data) = 1; % number of points1 in every pixel

%%% initializing results vectors
normArea  = zeros(1,max_R);
normPerim = zeros(1,max_R);
normEuler = zeros(1,max_R);

for disk_radius = 0:max_R-1 % 0:max_R-1 % 
    if disk_radius == 0
       normArea(disk_radius+1)  = 1;
       normPerim(disk_radius+1) = 1;
       normEuler(disk_radius+1) = 1;
    else
        
    h = fspecial('disk', disk_radius);
    a_disk = bwarea(h);
    p_disk = sum(sum(bwperim(h)));
    
    A1_convh = conv2(A1,h,'same');
    
    normArea(disk_radius+1)  = bwarea(A1_convh)/(N*a_disk);
    normPerim(disk_radius+1) = sum(sum(bwperim(A1_convh)))/(N*p_disk);
    normEuler(disk_radius+1) = bweuler(A1_convh)/(N);
    
    end
end

end














