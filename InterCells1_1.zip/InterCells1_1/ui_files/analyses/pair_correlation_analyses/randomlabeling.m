function [gr_min,gr_max] = randomlabeling(array1,array2,parameters,N_samples)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : arrayn, parameters, N_samples
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gr0 = gr_arrays(array1,array2,parameters);

%%% make rand arrays %%%%%%%%%%%%%%
%%% number of points 
N = sum(sum(array1));

gr_min = gr0; %ones(size(gr0));
gr_max = gr0; %ones(size(gr0));

for s = 1:N_samples

    %%% find linind
    linind1 = find(array1);
    linind2 = find(array2);
    linind_all = [linind1;linind2];
    
    %%% get N1, N2
    N1 = size(linind1,1);
    N2 = size(linind2,1);
    randperm_id = randperm(N1 + N2);
    
    %%% randomly permuting the lininds
    rand_linind1 = linind_all(randperm_id(1:N1));
    rand_linind2 = linind_all(randperm_id(N1+1:N1+N2));
    
    %%% initialize relocations arrays
    relocations_array1 = zeros(size(array1));
    relocations_array2 = zeros(size(array2));
    
    %%% assign mixed locatioms to relocations arrays
    relocations_array1(rand_linind1) = 1;
    relocations_array2(rand_linind2) = 1;
    
    %%% gr(relocations arrays)
    gr = gr_arrays(relocations_array1,relocations_array2,parameters);

    %%% get new gr_nim and gr_max
    if s == 1
        gr_min = gr;
        gr_max = gr;
    else
        gr_min(gr < gr_min) = gr(gr < gr_min);
        gr_max(gr > gr_max) = gr(gr > gr_max);
    end
    
end


end