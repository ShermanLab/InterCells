function [parameters,simulation_data] = ui_global_parameters(parameters,simulation_data) 

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : global_parameters_table
called by  : ui_main
calling    : globalparameters2table
description: make tabel from parameters.global 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% global parameters panel setup %%%%%

%%% craete global parameters table
global_parameters_table = globalparameters2table(parameters);
dat   = global_parameters_table;
nrows = size(dat,1);
%%% getting ui_parameters %%%%%%%%%
x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

fs1  = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
pw   = 305;
ph   = nrows*rowh+100; 
px   = x0+150;
py   = y0+500;

gapx = 2;

p = figure(3);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');


%%% title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Global parameters','FontSize',fs3,...
    'Position',[0 ph-30 pw 30]);

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {150,60,60};
columneditable = [false false true]; 

tx   = 0;
ty   = 25;
tw   = pw;
th   = ph-65;   

t = uitable(p,'Data',dat,...
    'ColumnName',columnname,...
    'ColumnFormat',columnformat,...
    'ColumnWidth',columnwidth,...
    'ColumnEditable',columneditable,...
    'Position',[tx ty tw th]); 


%%% Cencel %%%%%%%%%%%%%%%%%%%%%%%%%%%%    
pbw = 50;
pbh = 20;
Cancel_pbx = pw - 2*pbw - 5;
Cancel_pby = 3;

Cancel_pb = uicontrol(p,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position', [Cancel_pbx Cancel_pby pbw pbh],...
    'Callback',@Cancel); 

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pbx = Cancel_pbx + pbw + gapx;
Ok_pby = 3;
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position', [Ok_pbx Ok_pby pbw pbh],...
    'Callback',@Ok); 

%%% @Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cancel(~,~)
    uiresume
    figure(1)
    plot_ui_main(parameters,simulation_data)
    close(3)
end

%%% @Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Ok(~,~)
    table = get(t,'Data');
    new_global_parameters = table2globalparameters(parameters,table);
    new_size_x     = new_global_parameters.array_size_x;
    new_size_y     = new_global_parameters.array_size_y;
    
    default_size_x = parameters.global.array_size_x;
    default_size_y = parameters.global.array_size_y;
    
    if new_size_x ~= default_size_x || new_size_y ~= default_size_y
        
        simulation_data.Cells(1).Z = [];
        simulation_data.Cells(1).K = [];
        simulation_data.Cells(1).D = [];
        simulation_data.Cells(1).LOC = [];
        simulation_data.Cells(1).molecules = [];
        
        simulation_data.Cells(2).Z = [];
        simulation_data.Cells(2).K = [];
        simulation_data.Cells(2).D = [];
        simulation_data.Cells(2).LOC = [];
        simulation_data.Cells(2).molecules = [];
        
    end
    parameters.global = new_global_parameters;
    uiresume
    figure(1)
    plot_ui_main(parameters,simulation_data)
    close(3)
end

uiwait
end













