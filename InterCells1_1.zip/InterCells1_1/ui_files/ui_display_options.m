function display_options = ui_display_options(parameters)
  
%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : ui_parameters
output     : plotting_options
called by  : ui_main
calling    : none
description: picking with a checkbox what plots to plot
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0   = parameters.ui.mainfig.x0;
y0   = parameters.ui.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2 = 10;
fs3 = 12;

gapx = 2;
gapy = 2;

px   = x0+20;
py   = y0+250;
pw   = 175;
ph   = 190; 

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 30;
cbh  = 20;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(15);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Display options','NumberTitle','off');

%%% text Cell1 molecules %%%%%%%%%%%%%%
text1 = uicontrol(p,'Style','text',...
  'String','Display options',...
  'FontSize',fs3,...
  'Position',[2 ph-pbh pw pbh]);

%%% Molecules and membrane %%%%%%%%%%%%
 cb1 = uicontrol(p,'Style','checkbox',...
     'String','Molecules and membrane',...
     'FontSize',fs2,...
     'Value',1,...
     'Position',[2 ph-3*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,1});

%%% Molecules energy %%%%%%%%%%%%%%%%%% 
cb2 = uicontrol(p,'Style','checkbox',...
     'String','Molecules energy',...
     'FontSize',fs2,...
     'Value',0,...
     'Position',[2 ph-4*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,2});

%%% Membrane energy %%%%%%%%%%%%%%%%%%% 
cb3 = uicontrol(p,'Style','checkbox',...
     'String','Membrane energy',...
     'FontSize',fs2,...
     'Value',0,...
     'Position',[2 ph-5*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,3});
 
%%% Membrane rigidity %%%%%%%%%%%%%%%%%
cb4 = uicontrol(p,'Style','checkbox',...
     'String','Membrane rigidity',...
     'FontSize',fs2,...
     'Value',0,...
     'Position',[2 ph-6*cbh pw-4 cbh],...
     'Callback',{@checkBoxCallback,4});
 
%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(p,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[pbx pby pbw 20],...
    'Callback','close(15)'); 

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(text1,'Left'   ,'Top');
align(cb1  ,'Fixed',2,'none');
% align(Close_pb,'Fixed',2,'none');
align([text1 cb1 cb2 cb3 cb4],'Left','Fixed',gapy);

%%% assigning choises %%%%%%%%%%%%%%%%%
display_options.molecules_and_membranes = get(cb1,'Value');
display_options.molecules_energy        = get(cb2,'Value');
display_options.membrane_energy         = get(cb3,'Value');
display_options.membrane_rigidity       = get(cb4,'Value');

set([cb2 cb3 cb4],'Enable','off')

end