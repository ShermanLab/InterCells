function display_options = displayoptions()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : plotting_options
called by  : start_interface_simulation
calling    : none
description: sets what type of plot to plot while the simulation runs
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

display_options.molecules_and_membranes   = 1;
display_options.molecules_energy          = 0;
display_options.membrane_energy           = 0;
display_options.membrane_rigidity         = 0;

end




