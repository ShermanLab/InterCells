function [parameters,simulation_data] = ui_Cells_types(parameters,...
    simulation_data,default_parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;
%%%

fs1  = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 2;
gapy = 2;

px   = x0+170;
py   = y0+610;
pw   = 110;
ph   = 200; %150; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 20;

p = figure(4);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');

rbh   = 25;

bg1 = uibuttongroup(p,...
    'visible','on',...
    'Position',[0 0.65 1 1]);

text1 = uicontrol(p,...
    'Style','text',...
    'String','Cell1 type',...
    'FontSize',fs3,...
    'BackgroundColor',[1 1 1],...
    'Position',[2 ph-30 pw rbh]);

rb1_1 = uicontrol(bg1,...
    'Style','Radio',...
    'String','T-cell',...
    'FontSize',fs2,...
    'Position',[gapx 10 pw rbh]);

% Cell1_name = get(get(bg1,'SelectedObject'),'String');
% parameters.Cells(1).cellname = Cell1_name;

%%% title2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bg2 = uibuttongroup(p,...
    'visible','on',...
    'Position',[0 0 1 0.65]);

text2 = uicontrol(bg2,...
    'Style','text',...
    'String','Cell2 type',...
    'FontSize',fs3,...
    'ForegroundColor',[1 1 1],...
    'BackgroundColor',0.2*[1 1 1],...
    'Position',[2 95 pw 30]);

rb2_1 = uicontrol(bg2,'Style','Radio',...
    'String','Coverslip',...
    'FontSize',fs2,...
    'Position',[gapx 60 pw rbh]);

rb2_2 = uicontrol(bg2,'Style','Radio',...
    'String','APC',...
    'FontSize',fs2,...
    'Position',[gapx 30 pw rbh]);

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(bg2,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position',[pbx pby pbw pbh],...
    'Callback','close(4)'); 

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(bg2,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[pbx+pbw+gapx pby pbw pbh],...
    'Callback',@Ok); 


function Ok(~,~) 
    
    parameters.Cells(1).cellname = get(get(bg1,'SelectedObject'),'String');
    parameters.Cells(2).cellname = get(get(bg2,'SelectedObject'),'String');

    %%% Cells(1)
    simulation_data.Cells(1) = make_initial_Cell1_data(parameters);
    if strcmp(parameters.Cells(1).cellname,'Tcell')
        parameters.Cells(1) = default_parameters.Tcell_parameters;
        simulation_data.Cells(1) = make_initial_Cell1_data(parameters);
    end

    %%% Cells(2)
    if strcmp(parameters.Cells(2).cellname,'Coverslip')
        
        parameters.Cells(2) = default_parameters.Coverslip_parameters;
        simulation_data.Cells(2) = make_initial_Cell2_data(parameters);
        %%%
        [parameters,simulation_data] = ui_main(parameters,simulation_data);
        %%%
        figure(1)
        plot_ui_main(parameters,simulation_data)
        close(4)
    end
    if strcmp(parameters.Cells(2).cellname,'APC')
        
        parameters.Cells(2) = default_parameters.APC_parameters;
        simulation_data.Cells(2) = make_initial_Cell2_data(parameters);
        %%%
        [parameters,simulation_data] = ui_main(parameters,simulation_data);
        %%%
        figure(1)
        plot_ui_main(parameters,simulation_data)
        close(4)
    end
end

% uiwait
end






