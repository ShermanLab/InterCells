function [parameters,simulation_data] = ui_Cells_types(...
    parameters,simulation_data)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

fs1 = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 3;
gapy = 3;

px   = x0+170;
py   = y0+610;
pw   = 110;
ph   = 200; %150; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 20;

p = figure(4);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');

rbh   = 25;
%%% button group1 %%%%%%%%%%%%%%%%%%%%%
bg1 = uibuttongroup(p,...
    'visible','on',...
    'Position',[0 0.65 1 1]);

%%% title1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
text1 = uicontrol(p,...
    'Style','text',...
    'String','Cell1 type',...
    'FontSize',fs3,...
    'BackgroundColor',[1 1 1],...
    'Position',[2 ph-30 pw rbh]);

%%% radio button Cells(1),1 %%%%%%%%%%%
rb1_1 = uicontrol(bg1,...
    'Style','Radio',...
    'String','T-cell',...
    'FontSize',fs2,...
    'Position',[gapx 10 pw rbh]);

%%% button group2 %%%%%%%%%%%%%%%%%%%%%
bg2 = uibuttongroup(p,...
    'visible','on',...
    'Position',[0 0 1 0.65]);

%%% title1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
text2 = uicontrol(bg2,...
    'Style','text',...
    'String','Cell2 type',...
    'FontSize',fs3,...
    'ForegroundColor',[1 1 1],...
    'BackgroundColor',0.2*[1 1 1],...
    'Position',[2 95 pw 30]);

%%% radio button Cells(2),1 %%%%%%%%%%%
rb2_1 = uicontrol(bg2,'Style','Radio',...
    'String','Coverslip',...
    'Value',strcmp(parameters.Cells(2).cellname,'Coverslip'),...
    'FontSize',fs2,...
    'Position',[gapx 60 pw rbh]);

%%% radio button Cells(2),2 %%%%%%%%%%%
rb2_2 = uicontrol(bg2,'Style','Radio',...
    'String','APC',...
    'Value',strcmp(parameters.Cells(2).cellname,'APC'),...
    'FontSize',fs2,...
    'Position',[gapx 30 pw rbh]);

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(bg2,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position',[pbx pby pbw pbh],...
    'Callback','close(4)'); 

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(bg2,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[pbx+pbw+gapx pby pbw pbh],...
    'Callback',@Ok_callback); 

%%%
% if strcmp(parameters.Cells(2).cellname,'Coverslip')
%     rb2_1('Value') = 1;
% end
% if strcmp(parameters.Cells(2).cellname,'APC')
%     rb2_2('Value') = 1;
% end

%%% apply changes to Cells %%%%%%%%%%%%
function Ok_callback(varargin) 
    
    parameters.Cells(1).cellname = get(get(bg1,'SelectedObject'),'String');
    parameters.Cells(2).cellname = get(get(bg2,'SelectedObject'),'String');

    %%% compare current and default sizes 
    default_size_x = parameters.default_global.array_size_x;
    default_size_y = parameters.default_global.array_size_y;
    
    size_x         = parameters.global.array_size_x;
    size_y         = parameters.global.array_size_y;
    
    if size_x == default_size_x && size_y == default_size_y
    %%% use default locations arrays %%
        if strcmp(parameters.Cells(1).cellname,'Tcell')
            parameters.Cells(1)          = parameters.Tcell;
            %%% use default Cell1
            simulation_data.Cells(1)     = make_initial_Cell1_data(parameters);
            %%% maybe later
            [parameters,simulation_data] = ui_main(parameters,simulation_data);
        end

        %%% Cells(2) = Coverslip %%%%%%%%%%
        if strcmp(parameters.Cells(2).cellname,'Coverslip')

            parameters.Cells(2)          = parameters.Coverslip;
            simulation_data.Cells(2)     = make_initial_Cell2_data(parameters);
            %%% maybe later
            [parameters,simulation_data] = ui_main(parameters,simulation_data);

    %         uiresume
            %%% update main figure
%             figure(1)
%             plot_ui_main(parameters,simulation_data)
%             close(4)
        end

        %%% Cells(2) = APC %%%%%%%%%%%%%%%%
        if strcmp(parameters.Cells(2).cellname,'APC')

            parameters.Cells(2)          = parameters.APC;
            simulation_data.Cells(2)     = make_initial_Cell2_data(parameters);
            %%% maybe later
            [parameters,simulation_data] = ui_main(parameters,simulation_data);
    %         uiresume
            %%% update main figure
%             figure(1)
%             plot_ui_main(parameters,simulation_data)
%             close(4)
        end
        
    else 
        
        %%% use empty locations arrays %%%%   
        %%%
        locations_array1 = zeros(size_x,size_y);
        
        Cell1_data = locations_array2Cell_data(...
            parameters,locations_array1,1);
        
        simulation_data.Cells(1) = Cell1_data;
        %%%  

        %%%
        locations_array2 = zeros(size_x,size_y);
        
        Cell2_data = locations_array2Cell_data(...
            parameters,locations_array2,2);
        
        simulation_data.Cells(2) = Cell2_data;        %%%    

    end % default / new
    uiresume
    figure(1)
    plot_ui_main(parameters,simulation_data)
    close(4)

end

waitfor(Ok_pb)

end






