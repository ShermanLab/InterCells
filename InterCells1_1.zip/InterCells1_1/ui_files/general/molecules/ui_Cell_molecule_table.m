function parameters = ui_Cell_molecule_table(parameters,cn,tn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Cell_Molecule_parameters = parameters.Cells(cn).molecule_type(tn);
table_Cell_molecule = Cell_molecule_parameters2table(Cell_Molecule_parameters);

dat            = table_Cell_molecule;
nrows          = size(dat,1);
%%% 
color           = Cell_Molecule_parameters.color;
mname           = Cell_Molecule_parameters.name;

columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {180,60,60};
columneditable = [false false true]; 

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

rowh = 18;
pw   = 335;
ph   = nrows*rowh+90; % nrows*rowh+80
px   = x0+150;
py   = y0+408;

pbw = 50;
pbh = 20;
% gapx = 2;

fs1 = 8;
fs2 = 10;
fs3 = 12;

p = figure(17);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name',['Cell molecule table'],'NumberTitle','off');

%%% text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% edit color?
text1 = uicontrol('Parent',p,...
        'Style', 'Text',...
        'String',[mname,' parameters'],...
        'Position',[0 ph-30 350 30],...
        'BackgroundColor',color,...
        'FontSize',fs3); 

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
gapx = 3;
gapy = 3;
% tx   = 200; %150+6+360;
% ty   = 417; %156;
tw   = 350;
th   = nrows*rowh+57;

t = uitable('Parent',p,'Data',dat,...
    'ColumnName',columnname,...
    'ColumnFormat',columnformat,...
    'ColumnWidth',columnwidth,...
    'ColumnEditable',columneditable,...
    'Position',[0 0 tw th]); 

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pbx = 230;

%     Cancel_pb = 
uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Cancel',...
    'Position', [Cancel_pbx gapy pbw pbh],...
    'FontSize',fs1,...
    'Callback',@Cancel); 

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pbx = Cancel_pbx + pbw + gapx;

% Ok_pb = 
uicontrol('Parent',p,...
    'Style', 'pushbutton',...
    'String','Ok',...
    'Position', [Ok_pbx gapy pbw pbh],...
    'FontSize',fs1,...
    'Callback',@Ok); 

%%% funtions %%%%%%%%%%%%%%%%%%%%%%%%%%
%%% @Cancel
function Cancel(~,~)
        
    uiresume
    close(17)
end

%%% @Ok
function Ok(~,~)
    table = get(t,'Data');
%     parameters = table2moleculeparameters(table,parameters,cn,tn);
    parameters.Cells(cn).molecule_type(tn) = ...
        table2moleculeparameters(table,parameters,cn,tn);
    uiresume
    close(17)
end

uiwait
end
















