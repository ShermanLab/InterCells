function table_Cell_molecule = Cell_molecule_parameters2table(Cell_molecule_parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters, Cell_number
output     : table_Cell_membrane
called by  : 
calling    : none
description: Generates the Cell_membrabe table. Reads the selected
data from parameters.Cells(cn).membrane and putting it in columns
2 and 3 of the table
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

table_Cell_molecule = cell(18,3);
%%% first column of table %%%%%%%%%%%%%
%%% molecules
%%% inner properties
table_Cell_molecule{1,1}  = 'Molecule name';
table_Cell_molecule{2,1}  = 'Lateral size (nm)';
table_Cell_molecule{3,1}  = 'Vertical size (nm)';
%%% binding properties
table_Cell_molecule{5,1}  = 'Binding well top (nm)';
table_Cell_molecule{6,1}  = 'Binding well bottom (nm)';
table_Cell_molecule{7,1}  = 'Binding strength (KT)';
table_Cell_molecule{8,1}  = 'Spring strength (KT/nm^2)';
table_Cell_molecule{9,1}  = 'Force membrane to mol. height (1/0)';
%%% clusters prperties
table_Cell_molecule{11,1} = 'Diffusion constant (um^2/sec)';
table_Cell_molecule{12,1} = 'Global density (#/um^2)';
table_Cell_molecule{13,1} = 'Cluster Density (#/um^2)';
table_Cell_molecule{14,1} = 'Density of clusters (#/um^2)';

%%% second column of table %%%%%%%%%%%%
table_Cell_molecule{1,2}  = Cell_molecule_parameters.name;
table_Cell_molecule{2,2}  = Cell_molecule_parameters.lateral_size;
table_Cell_molecule{3,2}  = Cell_molecule_parameters.vertical_size;

table_Cell_molecule{5,2}  = Cell_molecule_parameters.binding_top;
table_Cell_molecule{6,2}  = Cell_molecule_parameters.binding_bottom;
table_Cell_molecule{7,2}  = Cell_molecule_parameters.binding_strength;
table_Cell_molecule{8,2}  = Cell_molecule_parameters.spring_k;
table_Cell_molecule{9,2}  = Cell_molecule_parameters.force_z;

table_Cell_molecule{11,2} = Cell_molecule_parameters.diffusion_constant;
table_Cell_molecule{12,2} = Cell_molecule_parameters.global_density;
table_Cell_molecule{13,2} = Cell_molecule_parameters.cluster_density;
table_Cell_molecule{14,2} = Cell_molecule_parameters.density_of_clusters;

%%% third column of table %%%%%%%%%%%%%
table_Cell_molecule(:,3)  = table_Cell_molecule(:,2);

end














