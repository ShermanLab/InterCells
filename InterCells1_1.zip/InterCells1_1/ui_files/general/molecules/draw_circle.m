function circle_boundary = draw_circle(parameters)

size_x     = parameters.global.array_size_x;
size_y     = parameters.global.array_size_y;

figure(8)

axis equal
axis([0 size_x 0 size_y])

% the initial list of points is empty 

% picking up the polygon points 
disp('Left mouse button picks center point')
disp('Right mouse button picks radius')

% drawing circle 
n  = 20; % point index
theta = 0:2*pi/n:2*pi;

[x,y] = ginput(2);
x0 = x(1);
y0 = y(1);
xr = x(2);
yr = y(2);
r  = sqrt((x0 - xr)^2 + (y0 - yr)^2);

circle_x = x0 + r*cos(theta);
circle_y = y0 + r*sin(theta);

% keeping circle inside boundary
if circle_x < 0
    circle_x = 0;
end
if circle_x > size_x
    circle_x = size_x;
end
if circle_y < 0
    circle_y = 0;
end
if circle_y > size_y
    circle_y = size_y;
end
circle_boundary = [circle_x',circle_y'];

%%% plot
hold on
plot(x0,y0,'k+')
plot(circle_x,circle_y,'-','Color','k');
hold off
end









