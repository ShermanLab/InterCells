function [parameters,simulation_data] = ...
    ui_Cell_molecule_types_Tcell_Coverslip(parameters,simulation_data)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters.
called by  : 
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;

n_types1 = size(parameters.Cells(1).molecule_type,2); 
n_types2 = size(parameters.Cells(2).molecule_type,2); 

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;

gapx = 3;
gapy = 3;

px   = x0+150;
py   = y0+580;
pw   = 155;


pbx  = 3;
pby  = 3;
pbw  = pw - 2*gapx;
pbh  = 25;

ph   = (pbh + gapy)*(n_types1 + n_types2 + 4); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(16);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Molecules types','NumberTitle','off');
 
%%% text Cell1 molecules %%%%%%%%%%%%%%
text1 = uicontrol('Parent',p,...
'Style','text',...
'String',['Cell1 molecule types'],...
'FontSize',fs3,...
'Position',[2 ph-(gapy+pbh) pbw pbh]);

%%% Cells(1) molecule_type(1) %%%%%%%%%
pb1_1 = uicontrol(p,'Style','PushButton',...
  'String',parameters.Cells(1).molecule_type(1).name,...
  'FontSize',fs2,...
  'Position',[gapx ph-((n_types1+1)*(1-1)+(1+1))*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(1).molecule_type(1).color,...
  'Callback',@ui_Cell_molecule_table1_1);

%%% @ui_Cell_molecule_table1_1 %%%%%%%%
function ui_Cell_molecule_table1_1(varargin)
    parameters = ui_Cell_molecule_table(parameters,1,1);
%     uiresume
    figure(1);
    plot_ui_main(parameters)
%     uiwait
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(1) molecule_type(2) %%%%%%%%%
pb1_2 = uicontrol(p,'Style','PushButton',...
  'String',parameters.Cells(1).molecule_type(2).name,...
  'FontSize',fs2,...
  'Position',[gapx ph-((n_types1+1)*(1-1)+(1+2))*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(1).molecule_type(2).color,...
  'Callback',@ui_Cell_molecule_table1_2);

%%% @ui_Cell_molecule_table1_2 %%%%%%%%
function ui_Cell_molecule_table1_2(varargin)
    parameters = ui_Cell_molecule_table(parameters,1,2);
%     uiresume
    figure(1);
    plot_ui_main(parameters)
%     uiwait
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(1) molecule_type(3) %%%%%%%%%
pb1_3 = uicontrol(p,'Style','PushButton',...
  'String',parameters.Cells(1).molecule_type(3).name,...
  'FontSize',fs2,...
  'Position',[gapx ph-((n_types1+1)*(1-1)+(1+3))*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(1).molecule_type(3).color,...
  'Callback',@ui_Cell_molecule_table1_3);

%%% @ui_Cell_molecule_table1_3 %%%%%%%%
function ui_Cell_molecule_table1_3(varargin)
    parameters = ui_Cell_molecule_table(parameters,1,3);
%     uiresume
    figure(1);
    plot_ui_main(parameters)
%     uiwait
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(2) %%%%%%%%%%%%%%%%%%%%%%%%%% 
%%% text Cell2 molecules %%%%%%%%%%%%%%
text2 = uicontrol('Parent',p,...
'Style','text',...
'String',['Cell2 molecule types'],...
'FontSize',fs3,...
'Position',[2 ph-(n_types1+2)*(gapy+pbh) pbw pbh]);

%%% Cells(2) molecule_type(1) %%%%%%%%%
pb2_1 = uicontrol(p,'Style','PushButton',...
  'String',parameters.Cells(2).molecule_type(1).name,...
  'FontSize',fs2,...
  'Position',[gapx ph-((n_types1+1)*(2-1)+(1+1))*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(2).molecule_type(1).color,...
  'Callback',@ui_Cell_molecule_table2_1);

%%% @ui_Cell_molecule_table2_1 %%%%%%%%
function ui_Cell_molecule_table2_1(varargin)
    parameters = ui_Cell_molecule_table(parameters,2,1);
%     uiresume
    figure(1);
    plot_ui_main(parameters)
%     uiwait
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(2) molecule_type(2) %%%%%%%%%
pb2_2 = uicontrol(p,'Style','PushButton',...
  'String',parameters.Cells(2).molecule_type(2).name,...
  'FontSize',fs2,...
  'Position',[gapx ph-((n_types1+1)*(2-1)+(1+2))*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(2).molecule_type(2).color,...
  'Callback',@ui_Cell_molecule_table2_2);

%%% @ui_Cell_molecule_table2_2 %%%%%%%%
function ui_Cell_molecule_table2_2(varargin)
    parameters = ui_Cell_molecule_table(parameters,2,2);
    
    %%%
    simulation_data.Cells(2) = make_initial_Cell2_data(parameters);

    %%%
%     uiresume
    figure(1);
    plot_ui_main(parameters,simulation_data)
%     uiwait
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cells(2) molecule_type(1) %%%%%%%%%
pb2_3 = uicontrol(p,'Style','PushButton',...
  'String',parameters.Cells(2).molecule_type(3).name,...
  'FontSize',fs2,...
  'Position',[gapx ph-((n_types1+1)*(2-1)+(1+3))*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',parameters.Cells(2).molecule_type(3).color,...
  'Callback',@ui_Cell_molecule_table2_3);

%%% @ui_Cell_molecule_table2_3 %%%%%%%%
function ui_Cell_molecule_table2_3(varargin)
    parameters = ui_Cell_molecule_table(parameters,2,3);
%     uiresume
    figure(1);
    plot_ui_main(parameters)
%     uiwait
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[pbx pby 0.4*pbw pbh],...
    'Callback',@Ok_callback); 

%%% @Ok_callback %%%%%%%%%%%%%%%%%%%%%%
function Ok_callback(varargin)
    uiresume
    figure(1);
    plot_ui_main(parameters,simulation_data)
    close(16)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pb = uicontrol(p,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position',[pbx+pbw+gapx pby 0.4*pbw pbh],...
    'Callback',@Cancel_callback); 

%%% @Cancel_callback %%%%%%%%%%%%%%%%%%
function Cancel_callback(varargin)
    uiresume
    figure(1)
    close(16)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align([Ok_pb],'Fixed',3,'Fixed',3);
align([Ok_pb Cancel_pb],'Fixed',2,'Bottom');
% align([Ok_pb text1 pb1_1 pb1_2 pb1_3...
%                 text2 pb2_1 pb2_2 pb2_3],'Left','Fixed',1);

% uiwait
waitfor(Ok_pb)

end






