function logical_accepted = metropolis(E_linind_old,E_linind_new,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : E_linind_old, E_linind_new, parameters
output     : logical_accepted
called by  : new_locations_attempt(simulation_data,cn,parameters)
calling    : none
description: Gives the accepted and rejected attempts according
to their energies and Metropolis criterion.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% genrating rand values %%%%%%%%%%%%% 
rand_values = rand(size(E_linind_old)); 

%%% calculating delta_E %%%%%%%%%%%%%%%
% delta_E is negative if energy is gained
delta_E3 = E_linind_new - E_linind_old;

%%% one step metropolis %%%%%%%%%%%%%%%
logical_accepted = exp(-delta_E3) > rand_values;

%%% two step metropolis %%%%%%%%%%%%%%%
if parameters.global.metropolis_steps == 2
    delta_E31 = -E_linind_old;
    delta_E32 =  E_linind_new;
    
    %%% accepted: exp_delta_E >= 1
    logical_accepted1 = exp(-delta_E31) > rand_values; 
    logical_accepted2 = exp(-delta_E32) > rand_values; 
    logical_accepted = logical_accepted1 & logical_accepted2;
end

end













