function simulation_data = newZ(simulation_data,cn,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data
output     : simulation_data
called by  : 
calling    : Emembrane, Emolecules
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% gravity %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% gravity_force/pixel
% use_gravity = parameters.global.use_gravity;
% if use_gravity
%     e_gravity = parameters.global.e_gravity;
% else
%     e_gravity = 0;
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

oldZ = simulation_data.Cells(cn).Z;

K    = simulation_data.Cells(cn).K;

%%% calculating elastic energy of the membrane
%%% old E membrane
oldE_membrane  = Emembrane(oldZ,K,parameters); 

%%% old E molecules
simulation_data = Emolecules(simulation_data,parameters);
oldE_molecules = simulation_data.Cells(cn).Emol;

%%% oldE is the total energy at every pixel
oldE = oldE_membrane + oldE_molecules;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% generating new Z attempt %%%%%%%%%%
sigma_dz = parameters.Cells(cn).membrane.dz;

rand_dZ = sigma_dz*randn(size(oldZ));
newZn   = abs(oldZ + rand_dZ);

%%% calculating the new attempted membrane energy
%%% new E membrane
newE_membrane = Emembrane(newZn,K,parameters);

%%% new E molecules
% simulation_data = Emolecules2(simulation_data,parameters); %!!!
newE_molecules = simulation_data.Cells(cn).Emol;

%%% oldE is the total energy at every pixel
newE = newE_membrane + newE_molecules;

delta_E = newE - oldE;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% accepting/rejecing the dLs according to Metropolis criterion
logical_accepted_dZ = logical(rand(size(oldZ)) <= exp(-delta_E));
dZ                  = rand_dZ.*logical_accepted_dZ; 
new_Z               = abs(oldZ + dZ);

%%% update Z array
simulation_data.Cells(cn).Z = new_Z;

%%% update z list
linind_all = simulation_data.Cells(cn).molecules(:,2);
imulation_data.Cells(cn).molecules(:,4) = new_Z(linind_all);

end











