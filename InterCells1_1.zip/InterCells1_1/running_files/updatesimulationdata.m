function simulation_data = updatesimulationdata(simulation_data,current_experimental_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data
output     : simulation_data
called by  : run_simulation
calling    : Emembrane
description: Updates all the simulation_data.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

iter = simulation_data.iter;

%%% new molecules locations
simulation_data = new_locations_two_cells(simulation_data,parameters);

%%% update values for each cell separately

for cn = 1:2
    
    linind_all = simulation_data.Cells(cn).molecules(:,2);
    types_all  = simulation_data.Cells(cn).molecules(:,3);
    max_types  = max(types_all);
    
    %%% new Z
    simulation_data = newZ(simulation_data,cn,parameters);
    Z = simulation_data.Cells(cn).Z;
    for tn = 1:max_types
        
        linind_tn = linind_all(types_all == tn);
        
        %%% force_z %%%%%%%%%%%%%%%%%%%%%%%%%%%
        if parameters.Cells(cn).molecule_type(tn).force_z
            h = parameters.Cells(cn).molecule_type(tn).vertical_size;
            Z(linind_tn)   = h;
        end

        %%% force_z by stick time %%%%%%%%%%%%%
        if iter < parameters.global.stick_time/parameters.global.iteration_time     
            if parameters.Cells(cn).molecule_type(tn).force_z
                Z(linind_tn) = parameters.Cells(cn).molecule_type(tn).vertical_size;
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end    

    %%% rigidity
    K = simulation_data.Cells(cn).K;

    %%% diffusivity
%     D = simulation_data.Cells(cn).D;
%     simulation_data.Cells(cn).D = D;

    %%% new Z
    simulation_data.Cells(cn).Z  = Z;
    linind_all = simulation_data.Cells(cn).molecules(:,2);
    
    simulation_data.Cells(cn).molecules(:,4) = Z(linind_all);
    
    %%% new E membrane
    simulation_data.Cells(cn).Emem = Emembrane(Z,K,parameters);

end

end








