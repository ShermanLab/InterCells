function simulation_data = new_locations_attempt(...
    simulation_data,cn,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data,
             cn (cell_number)
output     : simulation_data
called by  : new_linind_two_cells
calling    : none
description: attempts to change the molecules locations
on one membrane.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% read from parameters %%%%%%%%%%%%%%
size_x         = parameters.global.array_size_x;
size_y         = parameters.global.array_size_y;
a              = parameters.global.pixel_size;
iteration_time = parameters.global.iteration_time;

%%% read from simulation_data.Cells(cn)
D    = simulation_data.Cells(cn).D;
Emem = simulation_data.Cells(cn).Emem;

%%% read from simulation_data.Cells(cn).molecules
linind_all      = simulation_data.Cells(cn).molecules(:,2);
types_all       = simulation_data.Cells(cn).molecules(:,3);

%%%
D_linind_all    = D(linind_all);
Emem_linind_all = Emem(linind_all);
N_molecules     = size(linind_all,1);

diffusion_constants_types = zeros(size(linind_all));

%%% find number of molacule types
max_types = max(types_all);

for tn = 1:max_types
    
    %%% reading diffusion constant from parameters
    logical_type = types_all == tn;
    diffusion_constant_type = parameters.Cells(cn).molecule_type(tn).diffusion_constant;
    diffusion_constants_types(logical_type) = diffusion_constant_type;
end

%%% local diffusions %%%%%%%%%%%%%%
D_diffusions_type = diffusion_constants_types.*D_linind_all;
diffusion_pixels = sqrt(4*D_diffusions_type*iteration_time)*(1000/a);


%%% molecules locations
[X0,Y0]   = ind2sub([size_x,size_y],linind_all);

%%% setting descrete random jumps %
%%% getting new coordinates %%%%%%%
hop_r     = diffusion_pixels.*randn(N_molecules,1);
hop_theta = pi*rand(N_molecules,1); 
[dx0,dy0] = pol2cart(hop_theta,hop_r);
dx        = fix(dx0);
dy        = fix(dy0);

%%% new coordinates attempt %%%%%%%
X1 = ceil(mod(X0 + dx + size_x, size_x + 0.1)); 
Y1 = ceil(mod(Y0 + dy + size_y, size_y + 0.1)); 

%%% looking for hopping to patches that are already occupied 
occupied1 = ismember([X1,Y1],[X0,Y0],'rows');
X0Y0 = [X0,Y0];
X1Y1 = [X1,Y1];
X1Y1(occupied1) = X0Y0(occupied1);

%%% looking for multiple hoppings to the same free pixel
%%% unique new locations 
unique_X1Y1 = unique(X1Y1,'rows','stable');

%%% indices of X1Y1 that appear in unique_X1Y1
[~,locb1]   = (ismember(X1Y1,unique_X1Y1,'rows'));

%%% number of new locations repetitions and their indices
id_unique  = [1:size(unique_X1Y1,1)]';
[n2, bin2] = histc(locb1, id_unique);

%%% new locations repetitions and their indices where n > 1
multi_n2 = find(n2 > 1);

logical_multi_X1Y1 = ismember(bin2,multi_n2);

%%% keeping one of the multi to jump
X1Y1_multi_jump = X1Y1(multi_n2,:); % temp

%%% putting the multi_X1Y1 back to their source
X1Y1(logical_multi_X1Y1,:) = X0Y0(logical_multi_X1Y1,:);

%%% jumping to the kept jumps
X1Y1(multi_n2,:) = X1Y1_multi_jump;

%%% linind of X1Y1 %%%%%%%%%%%%%%%%
linind_attempt = sub2ind([size_x,size_y],X1Y1(:,1),X1Y1(:,2));

%%% old energy %%%%%%%%%%%%%%%%%%%%
E_linind_old = simulation_data.Cells(cn).molecules(:,5);

%%% new energy %%%%%%%%%%%%%%%%%%%%
%%% assign attempt locations to simulation_data.Cells(cn)
simulation_data.Cells(cn).molecules(:,2) = linind_attempt;

%%% calculates E_molecules for linind_attempt
simulation_data  = Emolecules(simulation_data,parameters);
E_linind_attempt = simulation_data.Cells(cn).molecules(:,5);

%%% Metropolis %%%%%%%%%%%%%%%%%%%%
%%% logical Metroplis
logical_accepted = metropolis(E_linind_old,E_linind_attempt,parameters);

%%% reject attempts according to Metropolis
linind_attempt(~logical_accepted) = linind_all(~logical_accepted);
linind_new = linind_attempt;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% assign linind_new to simulation_data
simulation_data.Cells(cn).molecules(:,2) = linind_new;

%%% assign new locations and types to simulation_data.LOC
new_LOC = zeros(size_x,size_y);
new_LOC(linind_new) = types_all;

simulation_data.Cells(cn).LOC = new_LOC;

end


