function simulation_data = new_locations_two_cells(simulation_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data,
             parameters
output     : new_Cell1,new_Cell2
called by  : updatesimulationdata
calling    : new_locations_attempt
             new_locations_attempt
             Emolecules
             
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% attempt to jump the molecules. The jumps are leagal (no jumping
%%% to occupied pixels and no multiple jumps to the same empty pixel).
%%% No energy (Metropolis) concidierations here.

%%% Cells(1)
simulation_data = new_locations_attempt(simulation_data,1,parameters);

%%% Cell(2)
simulation_data = new_locations_attempt(simulation_data,2,parameters);

%%% step 2 - calculating new energy at the newlininds
simulation_data = Emolecules(simulation_data,parameters); % ??

end
%


