function simulation_data = Emolecules(simulation_data,parameters)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data, parameters.
output     : id_linind_type_Z_newE_Cell1,
             id_linind_type_Z_newE_Cell2
called by  : new_linind_two_cells.
calling    : none.
description: updates the molecules' energy values.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a = parameters.global.pixel_size;

%%% Cells(1) %%%%%%%%%%%%%%%%%%%%%%%%%%
Z1    = simulation_data.Cells(1).Z;
K1    = simulation_data.Cells(1).K;

%%% read data from lists
linind_1_all = simulation_data.Cells(1).molecules(:,2);
types_1_all  = simulation_data.Cells(1).molecules(:,3);
% z1_all       = simulation_data.Cells(1).molecules(:,4);

%%% Cells(2) %%%%%%%%%%%%%%%%%%%%%%%%%%
Z2    = simulation_data.Cells(2).Z;
K2    = simulation_data.Cells(2).K;

%%% read data from lists
linind_2_all = simulation_data.Cells(2).molecules(:,2);
types_2_all  = simulation_data.Cells(2).molecules(:,3);
% z2_all       = simulation_data.Cells(2).molecules(:,4);
DZ = Z1 - Z2;

%%% finding max number of molacule types
max_type1 = max(types_1_all);
max_type2 = max(types_2_all);
max_types = max([max_type1,max_type2]);

E1 = zeros(size(linind_1_all));
E2 = zeros(size(linind_2_all));

for tn = 1:max_types
    
    %%% linind by type number
    logical_type_1_tn = types_1_all == tn;
    logical_type_2_tn = types_2_all == tn;
    
    linind_1_tn = linind_1_all(logical_type_1_tn);
    linind_2_tn = linind_2_all(logical_type_2_tn);
    
    E1_tn = zeros(size(linind_1_tn));
    E2_tn = zeros(size(linind_2_tn));
    %%% multual linind_1_tn
    logical_mutual_locations1 = ismember(linind_1_tn,linind_2_tn);
%     mutual_linind_1_tn = linind_1_tn(logical_mutual_locations1);
    
    %%% multual linind_2_tn
    logical_mutual_locations2 = ismember(linind_2_tn,linind_1_tn);
%     mutual_linind_2_tn = linind_2_tn(logical_mutual_locations2);
    
    %%% values from parameters %%%%%%%%
    %%% molecule vertical size
    try
        h1 = parameters.Cells(1).molecule_type(tn).vertical_size;
    catch
        h1 = 0;
    end
    
    try
        h2 = parameters.Cells(2).molecule_type(tn).vertical_size;
    catch
        h2 = 0;
    end
    %%% molecule spring constant
    try
        k1 = parameters.Cells(1).molecule_type(tn).spring_k;
    catch
        k1 = 0;
    end
        
    try
        k2 = parameters.Cells(2).molecule_type(tn).spring_k;
    catch
        k2 = 0;
    end
    %%% molecule binding strength
    try
        u1 = parameters.Cells(1).molecule_type(tn).binding_strength;
    catch
        u1 = 0;
    end
    
    try
        u2 = parameters.Cells(2).molecule_type(tn).binding_strength;
    catch
        u2 = 0;
    end
    %%% molecule binding range
    try
        b1bot = parameters.Cells(1).molecule_type(tn).binding_bottom;
    catch
        b1bot = 0;
    end
        
    try
        b1top = parameters.Cells(1).molecule_type(tn).binding_top;
    catch
        b1top = 0;
    end
        
    try    
        b2bot = parameters.Cells(2).molecule_type(tn).binding_bottom;
    catch
        b2bot = 0;
    end
    
    try
        b2top = parameters.Cells(2).molecule_type(tn).binding_top;
    catch
        b2top = 0; 
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% DZ at linind tn
    DZ_linind_1 = DZ(linind_1_tn);
    DZ_linind_2 = DZ(linind_2_tn);
    
    %%% calculating energies %%%%%%%%%%
    %%% binding energies
    %%% find molecule in binding range
    logical_in_binding_range1 = DZ_linind_1 >= b1bot & DZ_linind_1 <= b1top;
    logical_in_binding_range2 = DZ_linind_2 >= b2bot & DZ_linind_2 <= b2top;
    
    %%% logical_mutual_in_binding_range
    logical_mutual_in_binding_range1 = ...
        logical_mutual_locations1 & logical_in_binding_range1;
    
    logical_mutual_in_binding_range2 = ...
        logical_mutual_locations2 & logical_in_binding_range2;

    %%% energy of molecule in binding range that are in mutual locations
    %%% binding_energy_at_mutual_locations_in_binding_range1
    E_bind1_linind_1_tn = u1*logical_mutual_in_binding_range1;
    %%% binding_energy_at_mutual_locations_in_binding_range2
    E_bind2_linind_2_tn = u2*logical_mutual_in_binding_range2;
    
    %%% binding to PLL %%%%%%%%%%%%%%%%
    if strcmp(parameters.Cells(2).cellname,'Coverslip')
        if parameters.global.PLL.use
            u_PLL = parameters.global.PLL.binding_strength;
            logical_in_PLL_binding_range = (DZ_linind_1 <= h1 + 3);
            linind_1_tn_in_PLL_binding_range = ...
                linind_1_tn(logical_in_PLL_binding_range);
            E_PLL_linind_1_tn = u_PLL.*logical_in_PLL_binding_range;
        end
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% spring energies %%%%%%%%%%%%%%%
    %%% K at linind tn
    K1_linind_1_tn = K1(linind_1_tn);
    K2_linind_2_tn = K2(linind_2_tn);
    
    %%% finding molecules in spring range
    logical_in_spring_range1     = (DZ_linind_1 < h1); 
    logical_in_spring_range2     = (DZ_linind_2 < h2); 
    
    k_spring_linind_1_tn = K1_linind_1_tn.*(k1/(a^2)); % /2?
    k_spring_linind_2_tn = K2_linind_2_tn.*(k2/(a^2)); % /2?
    
   
    E_spring1 = 0.5*k_spring_linind_1_tn.*...
        (DZ_linind_1.*logical_in_spring_range1 - ...
                   h1*logical_in_spring_range1).^2;
    
    E_spring2 = 0.5*k_spring_linind_2_tn.*...
        (DZ_linind_2.*logical_in_spring_range2 - ...
                   h2*logical_in_spring_range2).^2;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% add energies 
    E_bind_linind_1_tn  = E_bind1_linind_1_tn;
    
    if strcmp(parameters.Cells(2).cellname,'Coverslip')
        if parameters.global.PLL.use
            E_bind_linind_1_tn  = ...
                min(E_PLL_linind_1_tn,E_bind1_linind_1_tn);
        end
    end
    
    E1_tn = E_bind_linind_1_tn + E_spring1;
    
    E2_tn = E_bind2_linind_2_tn + E_spring2;
    
    E1(logical_type_1_tn) = E1(logical_type_1_tn) + E1_tn;
    E2(logical_type_2_tn) = E2(logical_type_2_tn) + E2_tn;
    
end
Emol1 = E1;
Emol2 = E2;
%%% assign energies to molecules' list
simulation_data.Cells(1).molecules(:,5) = Emol1;
simulation_data.Cells(2).molecules(:,5) = Emol2;

%%% assign energies to energy array
simulation_data.Cells(1).Emol(linind_1_all) = Emol1;
simulation_data.Cells(2).Emol(linind_2_all) = Emol2;

% subplot(2,2,4)
% imagesc(simulation_data.Cells(1).Emol)
% title('simulation_data.Cells(1).Emol')

end


