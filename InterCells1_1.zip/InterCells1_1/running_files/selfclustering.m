function idm1_is_nn_stay = selfclustering(id_linind_type_Z_E_Cell1,typen,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : start_interface_simulation
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

size_x   = parameters.global.array_size_x; 
size_y   = parameters.global.array_size_x; 

idm1     = id_linind_type_Z_E_Cell1(:,1);
linindm1 = id_linind_type_Z_E_Cell1(:,2);
typem1   = id_linind_type_Z_E_Cell1(:,3);


idm1_n           = idm1(typem1 == typen);
linindm1_n       = linindm1(idm1_n);
% linind_locations = linindm1_n;

%%% mask of nearest neighbours
locations_array  = zeros(size_x,size_y);
locations_array(linindm1_n) = 1;
% h = [1,1,1;1,0,1;1,1,1];
% h = ones(5);
h = 1*logical(fspecial('disk',4));
h(5,5) = 0;
nn_mask_array = logical(conv2(locations_array,h,'same'));
linind_nn_mask = find(nn_mask_array);

linind_is_nn = linindm1_n(ismember(linindm1_n,linind_nn_mask));
idm1_is_nn   = idm1(ismember(linindm1,linind_is_nn));

%%% finding id_stay 
P_stay = 0.99;
rand_values = rand(size(idm1_is_nn));
idm1_is_nn_stay = idm1_is_nn(rand_values < P_stay);


end