function Cell1_data = make_initial_Cell1_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns    = (size_x/1000*a)*(size_y/1000*a);
rand_array      = rand(size_x,size_y);

%%% finding X_free Y_free
[X_free,Y_free]   = find(rand_array);

%%% Cell1 molecules1 %%%%%%%%%%%%%%%%%%
for fold_type1 = 1
    %%% Cell1 type1 global_density %%%%%%%%
    global_density1_1 = parameters.Cells(1).molecule_type(1).global_density;
    N1_1              = global_density1_1*area_microns;
    
    %%% Cell1 molecule_type1 clusters %%%%%
    cluster_density1_1  = parameters.Cells(1).molecule_type(1).cluster_density;
    
    x01 = [size_x*0.3 ,size_x*0.45, size_x*0.7]; % clusters center x
    y01 = [size_y*0.2 ,size_y*0.8 , size_y*0.5]; % clusters center y
    
    linindm1   = [];
    linindm1_1 = [];
    
    for C1_ind = 1:3 % cluster index
        
        %%% polygon boundary
        R1_1 = 20; % cluster radius pixels
        t  = 0:pi/10:2*pi;
        polygon_x = x01(C1_ind) + R1_1*cos(t); % cluster boundary points x
        polygon_y = y01(C1_ind) + R1_1*sin(t); % cluster boundary points y
        
        %%% number of molecules in polygon
        cluster_area_pixels  = polyarea(polygon_x,polygon_y); % pixels
        cluster_area_microns = cluster_area_pixels/(1000/a)^2; % sq microns
        N1_1_cluster         = cluster_area_microns*cluster_density1_1;
        
        %%% finding free locations inside the polygon as 0 and 1 vector
        in_polygon = inpolygon(X_free,Y_free,polygon_x,polygon_y);
        
        % excluding location that are already occupied
        if ~isempty(linindm1)
            in_polygon(linindm1) = 0;
        end
        
        % getting rand_array values that are inside the polygon
        rand_inpolygon = rand_array(in_polygon);
        
        X_in           = X_free(in_polygon);
        Y_in           = Y_free(in_polygon);
        
        % scattering N points uniformly in the polygon area
        % arranging the random values inside the polygon
        % in ascending order
        sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);
        % getting the X,Y coordinate of these points
        points_in = sorted_rand_in(1:N1_1_cluster,1:2);
        % getting the linind of these points
        linindm1_1_in = sub2ind([size_x,size_y],...
            points_in(:,1),points_in(:,2));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%% excluding location that are already occupied
        %     linindm1 = [linindm1;linindm1_1_points_in];
        %     rand_array(linindm1) = 0;
        linindm1_1 = [linindm1_1;linindm1_1_in];
        rand_array(linindm1_1) = 0;
        [X_free,Y_free]        = find(rand_array);
        
    end % Cluster_ind
    linindm1 = [linindm1;linindm1_1];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cell1 molecule_type2 %%%%%%%%%%%%%%
for fold_type2 = 1
    global_density1_2 = parameters.Cells(1).molecule_type(2).global_density;
    N1_2              = global_density1_2*area_microns;
    
    %%% molecule_type2 clusters %%%%%%%%%%%
    cluster_density1_2 = parameters.Cells(1).molecule_type(2).cluster_density;
    
    x02 = [size_x*0.25 ,size_x*0.35, size_x*0.8]; % clusters center x
    y02 = [size_y*0.33 ,size_y*0.75, size_y*0.25]; % clusters center y
    
    linindm1_2 = [];
    for C2_ind = 1:3 % cluster index
        
        %%% polygon boundary
        R1_2  = 10; % radius in pixels
        t  = 0:pi/10:2*pi;
        polygon_x = x02(C2_ind) + R1_2*cos(t); % cluster boundary points x
        polygon_y = y02(C2_ind) + R1_2*sin(t); % cluster boundary points y
        
        cluster_area_pixels  = polyarea(polygon_x,polygon_y); % pixels
        cluster_area_microns = cluster_area_pixels/(1000/a)^2; % sq microns
        N1_2_cluster = cluster_area_microns*cluster_density1_2;
        
        in_polygon = inpolygon(X_free,Y_free,polygon_x,polygon_y);
        
        % excluding location that are already occupied
        if ~isempty(linindm1_2)
            in_polygon(linindm1_2) = 0;
        end
        
        % getting rand_array values that are inside the polygon
        rand_inpolygon = rand_array(in_polygon);
        X_in           = X_free(in_polygon);
        Y_in           = Y_free(in_polygon);
        
        % scattering N points uniformly in the polygon area
        % arranging the random values inside the polygon
        % in ascending order
        sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);
        
        % getting the X,Y coordinate of these points
        points_in = sorted_rand_in(1:N1_2_cluster,1:2);
        % getting the linind of these points
        linindm1_2_in = sub2ind([size_x,size_y],...
            points_in(:,1),points_in(:,2));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%% excluding location that are already occupied
        linindm1_2 = [linindm1_2;linindm1_2_in];
        rand_array(linindm1_2) = 0;
        [X_free,Y_free]        = find(rand_array);
        %     linindm1_2 = [linindm1_2;linindm1_2];
        
    end % C_ind
end % fold_type2
locations_array(linindm1) = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Cell1 type3 %%%%%%%%%%%%%%%%%%%%%%%

for fold_type3 = 1
    
    global_density1_3 = parameters.Cells(1).molecule_type(3).global_density;
    N1_3              = global_density1_3*area_microns;
    
    %%% molecule_type2 clusters %%%%%%%%%%%
    cluster_density1_3 = parameters.Cells(1).molecule_type(3).cluster_density;
    
    x03 = [size_x*0.20 ,size_x*0.35, size_x*0.70]; % clusters center x
    y03 = [size_y*0.20 ,size_y*0.60, size_y*0.35]; % clusters center y
    
    
    linindm1_3 = [];
    for C3_ind = 1:3 % cluster index
        
        %%% polygon boundary
        R1_3  = 25; % radius in pixels
        t  = 0:pi/10:2*pi;
        polygon_x = x03(C3_ind) + R1_3*cos(t); % cluster boundary points x
        polygon_y = y03(C3_ind) + R1_3*sin(t); % cluster boundary points y
        
        cluster_area_pixels  = polyarea(polygon_x,polygon_y); % pixels
        cluster_area_microns = cluster_area_pixels/(1000/a)^2; % sq microns
        N1_3_cluster = cluster_area_microns*cluster_density1_3;
        
        in_polygon = inpolygon(X_free,Y_free,polygon_x,polygon_y);
        
        % excluding location that are already occupied
        %by 'existing points'
        if ~isempty(linindm1)
            in_polygon(linindm1) = 0;
        end
        
        % getting rand_array values that are inside the polygon
        rand_inpolygon = rand_array(in_polygon);
        X_in           = X_free(in_polygon);
        Y_in           = Y_free(in_polygon);
        
        % scattering N points uniformly in the polygon area
        % arranging the random values inside the polygon
        % in ascending order
        sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);
        
        % getting the X,Y coordinate of these points
        points_in = sorted_rand_in(1:N1_3_cluster,1:2);
        % getting the linind of these points
        linindm1_3_in = sub2ind([size_x,size_y],...
            points_in(:,1),points_in(:,2));
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%% excluding location that are already occupied
        linindm1_3 = [linindm1_3;linindm1_3_in];
        rand_array(linindm1_3) = 0;
        [X_free,Y_free]        = find(rand_array);
        %     linindm1_2 = [linindm1_2;linindm1_2];
        
    end % C_ind
    % linindm1 = [linindm1;linindm1_3];
end % fold_type3

locations_array = zeros(size(rand_array));
locations_array(linindm1_1) = 1;
locations_array(linindm1_2) = 2;
locations_array(linindm1_3) = 3;

Cell1_data = locations_array2Cell_data(parameters,locations_array,1);

end






