function [XY1_all,XY2_all,N1_all,N2_all,rect_x,rect_y] = getcelldata(all_data488_ROI,all_data647_ROI,all_data_starting_frame,ROI_number)
    
    data_x1_all = all_data488_ROI.signals.X_values;
    data_y1_all = all_data488_ROI.signals.Y_values;
    data_x2_all = all_data647_ROI.signals.X_values;
    data_y2_all = all_data647_ROI.signals.Y_values;

    starting_frame = all_data_starting_frame(ROI_number);
    N_frames = 41;

    %%% getting numbers of proteins in each experiment frame
    data_x1_all_frames = data_x1_all(:,:,starting_frame:starting_frame+N_frames-1);
    data_y1_all_frames = data_y1_all(:,:,starting_frame:starting_frame+N_frames-1);
    data_x2_all_frames = data_x2_all(:,:,starting_frame:starting_frame+N_frames-1);
    data_y2_all_frames = data_y2_all(:,:,starting_frame:starting_frame+N_frames-1);
    
    N1_all = zeros(N_frames,1);
    N2_all = zeros(N_frames,1);
    COORDINATES1_all = cell(N_frames,1);
    COORDINATES2_all = cell(N_frames,1);
    
    for ff = 1:N_frames
        data_x1_all_frame = data_x1_all_frames(:,:,ff);
        data_y1_all_frame = data_y1_all_frames(:,:,ff);
        data_x2_all_frame = data_x2_all_frames(:,:,ff);
        data_y2_all_frame = data_y2_all_frames(:,:,ff);
        
        data_x1_frame     = data_x1_all_frame(data_x1_all_frame > 0 & data_y1_all_frame > 0);
        data_y1_frame     = data_y1_all_frame(data_x1_all_frame > 0 & data_y1_all_frame > 0);
        data_x2_frame     = data_x2_all_frame(data_x2_all_frame > 0 & data_y2_all_frame > 0);
        data_y2_frame     = data_y2_all_frame(data_x2_all_frame > 0 & data_y2_all_frame > 0);
        
        COORDINATES1_all{ff} = [data_x1_frame;data_y1_frame]';
        COORDINATES2_all{ff} = [data_x2_frame;data_y2_frame]';
        
        N1_frame = length(data_x1_frame);
        N2_frame = length(data_x2_frame);
        N1_all(ff) = N1_frame;
        N2_all(ff) = N2_frame;
        %%%
        figure(8)
        hold on
%         plot(ff,length(data_x2_all_frame),'b.')
        plot(ff,length(data_x1_frame),'g.')
        plot(ff,length(data_x2_frame),'r.')
        
    end
    XY1_all = COORDINATES1_all;
    XY2_all = COORDINATES2_all;
    %%% averaging over frames 5:20 %%%%%%%%%%%%
    mean_N1_all = mean(N1_all(5:40)); % 5:end
    mean_N2_all = mean(N2_all(5:40));
%     max_N1_all = max(N1_all);
%     max_N2_all = max(N2_all);
    %%% plot ROI numbers %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    figure(8)
    plot([0 N_frames],mean_N1_all*[1 1],'g-')
%     plot([0 N_frames],max_N1_all*[1 1],'g--')
    plot([0 N_frames],mean_N2_all*[1 1],'r-')
%     plot([0 N_frames],max_N2_all*[1 1],'r--')
    xlabel('Frame #','FontSize',14)
    ylabel('Molecules in frame','FontSize',14)
    hold off

    %%% setting simulation boundaries %%%%%%%%%%%%%%%%%%%%%
    max_all_x1 = max(max(max(data_x1_all)));
    max_all_y1 = max(max(max(data_y1_all)));
    max_all_x2 = max(max(max(data_x2_all)));
    max_all_y2 = max(max(max(data_y2_all)));
    max_all_x  = max(max_all_x1,max_all_x2);
    max_all_y  = max(max_all_y1,max_all_y2);

%     sx_min = 1;
    sx_max = max_all_x;
%     sy_min = 1;
    sy_max = max_all_y;

    rect_x = sx_max; % - sx_min;
    rect_y = sy_max; % - sy_min;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end % function