function Cell2_data = make_initial_Cell2_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns = (size_x/1000*a)*(size_y/1000*a);
rand_array   = rand(size_x,size_y);
[X,Y]        = find(rand_array);

linind_points_in = [];

%%% Cells(2) molecule_type(1) %%%%%%%%%
global_density2_1 = parameters.Cells(2).molecule_type(1).global_density;
N2_1              = global_density2_1*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_1,1:2);
linindm2_1_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_1 = linindm2_1_points_in;

linind_points_in = [linind_points_in,linindm2_1_points_in];
rand_array(linind_points_in) = 0;

%%% Cells(2) molecule_type(2) %%%%%%%%%
global_density2_2 = parameters.Cells(2).molecule_type(2).global_density;
N2_1              = global_density2_2*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_1,1:2);
linindm2_2_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_2 = linindm2_2_points_in;

linind_points_in = [linind_points_in;linindm2_2_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cells(2) molecule_type(3) %%%%%%%%%
N2_3 = 0;
h2_3 = 0;
try 
    global_density2_3 = parameters.Cells(2).molecule_type(3).global_density;
    h2_3              = parameters.Cells(2).molecule_type(3).vertical_size;
    N2_3              = global_density2_3*area_microns;
catch
    
end
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_3,1:2);
linindm2_3_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_3 = linindm2_3_points_in;

linind_points_in = [linind_points_in;linindm2_3_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
locations_array = zeros(size(rand_array));
locations_array(linindm2_1) = 1;
locations_array(linindm2_2) = 2;
locations_array(linindm2_3) = 3;

Cell2_data = locations_array2Cell_data(parameters,locations_array,2);

end








