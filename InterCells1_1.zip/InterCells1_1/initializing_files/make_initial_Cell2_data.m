function Cell2_data = make_initial_Cell2_data(parameters)

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

area_microns = (size_x/1000*a)*(size_y/1000*a);
rand_array   = rand(size_x,size_y);
[X,Y]        = find(rand_array);

linind_points_in = [];

%%% Cells(2) molecule_type(1) %%%%%%%%%
global_density2_1 = parameters.Cells(2).molecule_type(1).global_density;
N2_1              = global_density2_1*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_1,1:2);
linindm2_1_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_1 = linindm2_1_points_in;

linind_points_in = [linind_points_in,linindm2_1_points_in];
rand_array(linind_points_in) = 0;

%%% Cells(2) molecule_type(2) %%%%%%%%%
global_density2_2 = parameters.Cells(2).molecule_type(2).global_density;
N2_1              = global_density2_2*area_microns;

ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_1,1:2);
linindm2_2_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_2 = linindm2_2_points_in;

linind_points_in = [linind_points_in;linindm2_2_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cells(2) molecule_type(3) %%%%%%%%%
N2_3 = 0;
h2_3 = 0;
try 
    global_density2_3 = parameters.Cells(2).molecule_type(3).global_density;
    h2_3              = parameters.Cells(2).molecule_type(3).vertical_size;
    N2_3              = global_density2_3*area_microns;
catch
    
end
ind_free_locations = find(rand_array);

%%% excluding location that are already occupied 
rand_in = rand_array(ind_free_locations);

X_in    = X(ind_free_locations);
Y_in    = Y(ind_free_locations);

sorted_rand_in       = sortrows([X_in,Y_in,rand_in],3);
points_in            = sorted_rand_in(1:N2_3,1:2);
linindm2_3_points_in = sub2ind([size_x,size_y],...
    points_in(:,1),points_in(:,2));

linindm2_3 = linindm2_3_points_in;

linind_points_in = [linind_points_in;linindm2_3_points_in];
rand_array(linind_points_in) = 0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
locations_array = zeros(size(rand_array));
locations_array(linindm2_1) = 1;
locations_array(linindm2_2) = 2;
locations_array(linindm2_3) = 3;

Cell2_data = locations_array2Cell_data(parameters,locations_array,2);
%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
%%% initial Z
%%% giving the height of the membrane at the molacules locations
Z2 = ones(size_x,size_y)*parameters.Cells(2).membrane.Z0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%% set lininds
linindm2 = [linindm2_1;...
            linindm2_2;...
            linindm2_3];
%%% set types
types    = [1*ones(size(linindm2_1));...
            2*ones(size(linindm2_2));...
            3*ones(size(linindm2_3))];
%%% set zs        
% z        = [h2_1*ones(size(linindm2_1));...
%             h2_2*ones(size(linindm2_2));...
%             h2_3*ones(size(linindm2_3))];

z        = zeros(size(linindm2));

%%% initial rigidity
K2 = ones(size_x,size_y)*parameters.Cells(2).membrane.rigidity;
%%% initial diffusivity
D2 = ones(size_x,size_y)*parameters.Cells(2).membrane.diffusivity;
%%% initial energy
E2 = zeros(size_x,size_y);

idm2 = 1:size(linindm2,1);

% [X,Y,type] = find(locations_types_array);
% z          = zeros(size(idm2));
e          = zeros(size(idm2));

Cell2_data.Z    = Z2;
Cell2_data.K    = K2;
Cell2_data.D    = D2;
Cell2_data.Emem = E2;
Cell2_data.Emol = E2;
Cell2_data.LOC = locations_array;

Cell2_data.molecules(idm2,1) = idm2;
Cell2_data.molecules(idm2,2) = linindm2;
Cell2_data.molecules(idm2,3) = types;
Cell2_data.molecules(idm2,4) = z;
Cell2_data.molecules(idm2,5) = e;

% figure(6)
% imagesc(locations_types_array)
%}

end








