function new_locations = polygonpoints(proteins_density,linind_locations,color,parameters)

% polygonpoints(N,linind_locations,color,parameters)

rand_array1 = rand(parameters.global.array_size_x,...
                   parameters.global.array_size_y);
a = parameters.global.pixel_size;
[X,Y] = find(rand_array1);
% color1 =

figure(1)
% clf
axis equal
axis([0 parameters.global.array_size_x 0 parameters.global.array_size_y])

%%% make polygon %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% the initial list of points is empty %%%%%%%%%%%%%%%%%%%
px = [];
py = [];
n = 0;
%%% loop, picking up the points %%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Left mouse button picks points')
disp('Right mouse button picks last point')
button = 1;
hold on
while button == 1
    [xi,yi,button] = ginput(1);
    plot(xi,yi,'ko')
    n = n+1;
    px(n) =  xi;
    py(n) =  yi;
end
polygon_x  = [px, px(1)];
polygon_y  = [py, py(1)];
polygon_points = [polygon_x',polygon_y'];
polygon_area   = polyarea(polygon_x',polygon_y');
%%% plot the polygon %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(polygon_x,polygon_y,'-','Color',color);

%%% scatter points %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% scattering N points uniformly in the polygon area %%%%%
%%% in_polygon is a logical vector 
in_polygon     = inpolygon(X,Y,polygon_x,polygon_y);
%%% excluding location that are already occupied %%%%%%%%%%
% linind_locations;
if ~isempty(linind_locations)
    in_polygon(linind_locations) = 0;
end
rand_inpolygon = rand_array1(in_polygon);

X_inpolygon    = X(in_polygon);
Y_inpolygon    = Y(in_polygon);

sorted_rand_inpolygon = sortrows([X_inpolygon,Y_inpolygon,rand_inpolygon],3);
%%% 20171120
N = proteins_density*polygon_area*(a/1000)^2;
%%%
new_locations = sorted_rand_inpolygon(1:N,1:2);

%%% plot in_locations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(new_locations(:,1),new_locations(:,2),'.','Color',color)

hold off
axis equal
axis([0 parameters.global.array_size_x 0 parameters.global.array_size_y])








