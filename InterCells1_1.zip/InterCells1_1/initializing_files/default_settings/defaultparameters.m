function default_parameters = defaultparameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : default_parameters
called by  : start_interface_simulation
calling    : none
description: generates the default parameters of the simulation
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% global 
default_parameters.global_parameters    = defaultglobalparameters();
%%% T-cell 
default_parameters.Tcell_parameters     = defaultTCELLparameters();
%%% APC 
default_parameters.APC_parameters       = defaultAPCparameters();
%%% Coverslip 
default_parameters.Coverslip_parameters = defaultCOVERSLIPparameters();
%%% Analyses 
default_parameters.analyses_parameters  = defaultANALYSESparameters();
%%% ui
default_parameters.ui                   = defaultUIparameters();

end















