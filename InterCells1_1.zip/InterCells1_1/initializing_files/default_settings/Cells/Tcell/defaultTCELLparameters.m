function default_Tcell_parameters = defaultTCELLparameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : default_Tcell_parameters
called by  : ?
calling    : defaultTCELLmembraneparameters()
             defaultTCRparameters()
             defaultLFA1parameters()
             defaultCD45parameters()
description: makes a structure of the Tcell parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% name 
Tcell.cellname     = 'Tcell';

%%% membrane 
Tcell.membrane     = defaultTCELLmembraneparameters();

%%% molecules 
% tcr
Tcell.molecule_type(1) = defaultTCRparameters();
% lfa 
Tcell.molecule_type(2) = defaultLFA1parameters();
% cd45 
Tcell.molecule_type(3) = defaultCD45parameters();

default_Tcell_parameters = Tcell;
end















