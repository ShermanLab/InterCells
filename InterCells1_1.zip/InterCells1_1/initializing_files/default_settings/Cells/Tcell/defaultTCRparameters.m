function tcr_parameters = defaultTCRparameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : tcr_parameters
called by  : defaultTCELLparameters
calling    : none
description: makes a structure of the TCR parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% setting TCR default parameters
tcr.name                = 'TCR';
tcr.type_number         = 1;
tcr.color               = [0 1 0]; % RGB
% sizes
tcr.vertical_size       = 13; % nm
tcr.lateral_size        = 10; % nm
tcr.area_patches_5      = 4;  % #
tcr.area_patches_10     = 1;  % #
% potentials
tcr.potential_width     = 6;  % nm
tcr.binding_bottom      = tcr.vertical_size - tcr.potential_width/2; % nm
tcr.binding_top         = tcr.vertical_size + tcr.potential_width/2; % nm
tcr.binding_strength    = -10; % KT
tcr.spring_k            = 0.1; % KT/nm
% diffusion
tcr.diffusion_constant  = 0.011; % um^2/sec
% clusters
tcr.global_density      = 300;  % #/um^2
tcr.cluster_density     = 2000; % #/um^2
tcr.density_of_clusters = 1;    % #/um^2
tcr.self_clustering     = 1;    % Yes/No
% force membrane to molecule height
tcr.force_z             = 1; % 0/1

tcr_parameters = tcr;
end 