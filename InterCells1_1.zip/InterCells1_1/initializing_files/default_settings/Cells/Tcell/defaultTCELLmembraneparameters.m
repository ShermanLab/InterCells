function default_Tcell_membrane_parameters = defaultTCELLmembraneparameters()

%rigidity
membrane.rigidity          = 25; % KBT
membrane.min_rigidity      = 25; % KBT
membrane.max_rigidity      = 100; % 100; %250; % KT
membrane.local_rigidity    = 0; 
% diffusivity
membrane.diffusivity       = 1; 
membrane.min_diffusivity   = 0.0; 
membrane.max_diffusivity   = 1; 
membrane.local_diffusivity = 0; 
% Z
membrane.Z0                = 70; % nm
membrane.min_Z             = 10; % nm 
membrane.max_Z             = 100; % nm
membrane.dz                = 1; % nm

default_Tcell_membrane_parameters = membrane;
end