function default_LIPIDBILAYER_membrane_parameters = defaultLIPIDBILAYERmembraneparameters()

%rigidity
membrane.rigidity          = 10^6; % KBT
membrane.min_rigidity      = 10^6; % KBT
membrane.max_rigidity      = 10^6; % 100; %250; % KT
membrane.local_rigidity    = 0; 
% diffusivity
membrane.diffusivity       = 1; 
membrane.min_diffusivity   = 0.0; 
membrane.max_diffusivity   = 1; 
membrane.local_diffusivity = 0; 
% Z
membrane.Z0                = 0; % nm
membrane.min_Z             = 0; % nm 
membrane.max_Z             = 0; % nm
membrane.dz                = 0; % nm

default_LIPIDBILAYER_membrane_parameters = membrane;
end