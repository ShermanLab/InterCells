function default_LIPIDBILAYER_parameters = defaultLIPIDBILAYERparameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : default_Tcell_parameters
called by  : ?
calling    : defaultTCELLmembraneparameters()
             defaultTCRparameters()
             defaultLFA1parameters()
             defaultCD45parameters()
description: makes a structure of the Tcell parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% name 
Lipidbilayer.cellname      = 'Lipidbilayer';

%%% membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
Lipidbilayer.membrane      = defaultLIPIDBILAYERmembraneparameters();

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
% pmhc
Lipidbilayer.molecule_type(1)  = defaultLBPMHCparameters();
% icam 
Lipidbilayer.molecule_type(2)  = defaultLBICAMparameters();

% apcm3 
% Lipidbilayer.molecules(3) = defaultLBAPCM3parameters();
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
default_LIPIDBILAYER_parameters = Lipidbilayer;
end















