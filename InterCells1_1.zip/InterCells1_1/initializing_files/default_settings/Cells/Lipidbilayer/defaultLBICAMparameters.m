function lbicam_parameters = defaultLBICAMparameters()

%%% setting TCR default parameters
icam.name                = 'ICAM';
icam.type_number         = 2;
icam.color               = [0.5 0.5 1]; % RGB
% sizes
icam.vertical_size       = 0; % nm
icam.lateral_size        = 10; % nm
icam.area_patches_5      = 4;  % #
icam.area_patches_10     = 1;  % #
% potentials
icam.potential_width     = 0;  % nm
icam.binding_bottom      = icam.vertical_size - icam.potential_width/2; % nm
icam.binding_top         = icam.vertical_size + icam.potential_width/2; % nm
icam.binding_strength    = -10;  % KT
icam.spring_k            = 0; % ?
% diffusion
icam.diffusion_constant  = 0.005; % um^2/sec
% clusters
icam.global_density      = 300;  % #/um^2
icam.cluster_density     = 1000; % #/um^2
icam.density_of_clusters = 1;    % #/um^2
% force membrane to molecule height
icam.force_z = 0; % 0/1

lbicam_parameters = icam;
end 