function acd11_parameters = defaultACD11parameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : acd11_parameters
called by  : defaultCOVERSLIPparameters
calling    : none
description: makes a structure of the aCD11 parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% setting aCD11 default parameters
acd11.name                = 'aCD11';
acd11.type_number         = 2;
acd11.color               = [0.7 0.7 0.9]; % RGB
% sizes
acd11.vertical_size       = 0;  % nm
acd11.lateral_size        = 10; % nm
acd11.area_patches_5      = 4;  % #
acd11.area_patches_10     = 1;  % #
% potentials
acd11.potential_width     = 0;  % nm
acd11.binding_bottom      = acd11.vertical_size - acd11.potential_width/2; % nm
acd11.binding_top         = acd11.vertical_size + acd11.potential_width/2; % nm
acd11.binding_strength    = -20;  % KT
acd11.spring_k            = 0;    % KT/nm
% diffusion
acd11.diffusion_constant  = 0; % um^2/sec
% clusters
acd11.global_density      = 300;  % #/um^2
acd11.cluster_density     = 2000; % #/um^2
acd11.density_of_clusters = 1;    % #/um^2
% force membrane to molecule height
acd11.force_z             = 0; % 0/1

acd11_parameters = acd11;
end 