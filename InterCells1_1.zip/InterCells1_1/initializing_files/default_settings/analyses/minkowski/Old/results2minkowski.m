function MINKOWSKI = results2minkowski(folder_name,times_vector,run,parameters)

all_results = load(folder_name);
% t = 0;
clockname = folder_name(14:end);
%%% parameters
max_R        = parameters.analyses.max_R;
size_t = length(times_vector);
size_r = max_R + 1;

MINKOWSKI = [];
AREA_type2  = zeros(size_t,size_r);
PERIM_type2 = zeros(size_t,size_r);
EULER_type2 = zeros(size_t,size_r);
AREA_type3  = zeros(size_t,size_r);
PERIM_type3 = zeros(size_t,size_r);
EULER_type3 = zeros(size_t,size_r);
AREA_type4  = zeros(size_t,size_r);
PERIM_type4 = zeros(size_t,size_r);
EULER_type4 = zeros(size_t,size_r);

for lt = 1:length(times_vector)
    t = times_vector(lt);
    disp(t)
    %%% TOP
    TOP_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.TOP;
    id_linind_type_Z_E_TOP  = TOP_data.id_linind_type_Z_E_TOP;
    id       = id_linind_type_Z_E_TOP(:,1);
    id_dype2 = id(id_linind_type_Z_E_TOP(:,3) == 2);
    id_dype3 = id(id_linind_type_Z_E_TOP(:,3) == 3);
    id_dype4 = id(id_linind_type_Z_E_TOP(:,3) == 4);
%     id_dype5 = id(id_linind_type_Z_E_TOP(:,3) == 5);
%     id_dype6 = id(id_linind_type_Z_E_TOP(:,3) == 6);
    
    linind_type2  = id_linind_type_Z_E_TOP(id_dype2,2);
    linind_type3  = id_linind_type_Z_E_TOP(id_dype3,2);
    linind_type4  = id_linind_type_Z_E_TOP(id_dype4,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [area2,perim2,euler2] = minkowski(linind_type2,parameters);
    [area3,perim3,euler3] = minkowski(linind_type3,parameters);
    [area4,perim4,euler4] = minkowski(linind_type4,parameters);

    AREA_type2(lt,:)  = area2;
    PERIM_type2(lt,:) = perim2;
    EULER_type2(lt,:) = euler2;
    AREA_type3(lt,:)  = area3;
    PERIM_type3(lt,:) = perim3;
    EULER_type3(lt,:) = euler3;
    AREA_type4(lt,:)  = area4;
    PERIM_type4(lt,:) = perim4;
    EULER_type4(lt,:) = euler4;

end

MINKOWSKI.type2.area  = AREA_type2;
MINKOWSKI.type2.perim = PERIM_type2;
MINKOWSKI.type2.euler = EULER_type2;

MINKOWSKI.type3.area  = AREA_type3;
MINKOWSKI.type3.perim = PERIM_type3;
MINKOWSKI.type3.euler = EULER_type3;

MINKOWSKI.type4.area  = AREA_type4;
MINKOWSKI.type4.perim = PERIM_type4;
MINKOWSKI.type4.euler = EULER_type4;



















