function [Area,Perim,Euler] = minkowski(linind_data,parameters)

linind_rings = parameters.analyses.linind_rings;
max_R        = length(linind_rings);
size_x       = parameters.global.array_size_x;
size_y       = parameters.global.array_size_y;

% N  = size(linind_data,1);

%%% setting array %%%%%%%%%%%
A1 = zeros(size_x,size_y);
A1(linind_data) = 1; % number of points1 in every pixel

%%% initializing results vectors
Area  = zeros(1,max_R);
Perim = zeros(1,max_R);
Euler = zeros(1,max_R);

for disk_radius = 0:max_R-1 % 0:max_R-1 % 
    if disk_radius == 0
       Area(disk_radius+1)  = 1;
       Perim(disk_radius+1) = 1;
       Euler(disk_radius+1) = 1;
    else
        
    h = fspecial('disk', disk_radius);

    A1_convh = conv2(A1,h,'same');
    
    Area(disk_radius+1)  = bwarea(A1_convh);
    Perim(disk_radius+1) = sum(sum(bwperim(A1_convh)));
    Euler(disk_radius+1) = bweuler(A1_convh);
    
    end
end

end














