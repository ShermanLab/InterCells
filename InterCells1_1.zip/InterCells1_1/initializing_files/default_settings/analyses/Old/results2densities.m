function DENSITIES = results2densities(results_folder_name,data_times,run,DILATIONS,EROSIONS2)
                                      
all_results = load(results_folder_name);

DILATION2 = DILATIONS{1};
EROSION2  = EROSIONS2;
% DILATION3 = DILATIONS{2};
% DILATION4 = DILATIONS{3};

DENSITIES  = cell(3,1);
DENSITY22   = cell(size(data_times,2),1);
DENSITY23   = cell(size(data_times,2),1);
DENSITY24   = cell(size(data_times,2),1);
% DENSITY32   = cell(size(data_times,2),1);
% DENSITY42   = cell(size(data_times,2),1);
% DENSITY43   = cell(size(data_times,2),1);
% disp(run)
%%% reading data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
size_x      = 200; %global_data.array_size_x;
size_y      = 200; %global_data.array_size_y;
% max_R       = 50;

for t = 1:length(data_times)
%     t = data_times(t0);
    disp(t)
    %%% TOP
    TOP_data                = all_results.RUNS_RESULTS{1,1}{t,1}.TOP;
    id_linind_type_Z_E_TOP  = TOP_data.id_linind_type_Z_E_TOP;
    
    id       = id_linind_type_Z_E_TOP(:,1);
    id_dype2 = id(id_linind_type_Z_E_TOP(:,3) == 2);
    id_dype3 = id(id_linind_type_Z_E_TOP(:,3) == 3);
    id_dype4 = id(id_linind_type_Z_E_TOP(:,3) == 4);
    
    linind_type2  = id_linind_type_Z_E_TOP(id_dype2,2);
    linind_type3  = id_linind_type_Z_E_TOP(id_dype3,2);
    linind_type4  = id_linind_type_Z_E_TOP(id_dype4,2);
       
    dilations2 = DILATION2{t,1};
    erosions2  = EROSION2{t,1};
%     dilations3 = DILATION3{t,1};
%     dilations4 = DILATION4{t,1};
    
    density22 = cell(length(dilations2),1);
    density23 = cell(length(dilations2),1);
    density24 = cell(length(dilations2),1);
    
    for r_index = 1:length(dilations2)
        dilation2_r = dilations2{r_index};
        erosion2_r  = erosions2{r_index};
%         dilation3_r = dilations3{r_index};
%         dilation4_r = dilations4{r_index};
        if r_index == 1
            dilation2_r = erosion2_r;
        else
            dilation2_r = union(dilation2_r,erosion2_r);
        end
        
        area_dilation2_r  = length(dilation2_r);
%         area_dilation3_r  = length(dilation3_r);
%         area_dilation4_r  = length(dilation4_r);
        %%%%%%%%%%%%%%%%%%%%%
        plot1 = 0;
        if plot1
            A = zeros(size_x,size_y);
            A(dilation2_r)  = 1;
            A(linind_type2) = 2;
            figure(10)
            imagesc(A)
            pause%(0.1)
        end
        
        %%%%%%%%%%%%%%%%%%%%%
        n_2r2 = length(intersect(dilation2_r,linind_type2));
        n_2r3 = length(intersect(dilation2_r,linind_type3));
        n_2r4 = length(intersect(dilation2_r,linind_type4));
        
        density22{r_index} = n_2r2/area_dilation2_r;
        density23{r_index} = n_2r3/area_dilation2_r;
        density24{r_index} = n_2r4/area_dilation2_r;
    end
    DENSITY22{t} = density22;
    DENSITY23{t} = density23;
    DENSITY24{t} = density24;
    
end

DENSITIES{1} = DENSITY22;
DENSITIES{2} = DENSITY23;
DENSITIES{3} = DENSITY24;












