function linind_locations = ui_set_experimental_data(...
        experimental_data,parameters,cluster_boundary,...
        locations_array_in,color,cn,tn,data0)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

linind_locations = [];
    
x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;
a        = parameters.global.pixel_size;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 5;
gapy = 5;

px   = x0+100;
py   = y0+100;
pw   = 1000;
ph   = 800; 

pbx  = 3;
pby  = 3;
pbw  = 95;
pbh  = 30;

%%% figures locations %%%%%%%%%%%%%%%%%
ox1 = 0.08; % 0.50;
ox2 = 0.56; % 0.50;
oy1 = 0.08; % 0.50;
oy2 = 0.54;
rw  = 0.4;
rh  = 0.45;

pos1 = [ox1 oy1 rw rh];
pos2 = [ox2 oy1 rw rh];

%%% get molecules names %%%%%%%%%%%%%%%
molecules_names = cell(1);
max_gr = 10;

nn = 0;
for cn0 = 1:1 % cell number
    types_n = 1; %size(parameters.Cells(cn0).molecule_type(:),1);
    for tn0 = 1:types_n % type number
        nn = nn + 1;
%         molecule_name = parameters.Cells(cn0).molecule_type(tn0).name;
        molecule_name = '';
        molecules_names{nn,1} = molecule_name;
    end
end

%%% get times names %%%%%%%%%%%%%%%%%%%
times_names = cell(1);
n_times = 1; %size(results_data,1);

for tt = 1:n_times % time
    times_names{tt,1} = num2str(tt-1);
end

data0.t = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(25);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Experimental locations','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Experimental locations',...
    'FontSize',20,...
    'Position',[pw*0.35 ph-50 300 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',[ox1 550/ph rw 200/ph]);

%%% text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String',['Choose molecule type and time to be located as ',...
    parameters.Cells(cn).molecule_type(tn).name],...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx 200-1*(pbh+gapy) rw*pw-2*gapx pbh]);

%%% plot_data %%%%%%%%%%%%%%%%%%%%%%%%%
function plot_data(~,~)
   
    X0 = experimental_data(:,1);
    Y0 = experimental_data(:,2);
    
    %%% subplot2 %%%%%%%%%%%%%%%%%%%%%%
    sp2 = subplot(2,2,4); 
    set(sp2,'position',pos2)
%     cla

    %%% get experimental array size
    data0.size_x  = max(experimental_data(:,1));
    data0.size_y  = max(experimental_data(:,2));
    
    plot(X0,Y0,'.','MarkerSize',1)
    axis equal
    axis([0  data0.size_x 0 data0.size_y])
    
    title('Experimental locations','FontSize',fs4)
    set(gca,'XTick',0:200:data0.size_x)
    set(gca,'YTick',0:200:data0.size_y)
    set(gca,'XTickLabel',a*[0:200:data0.size_x])
    set(gca,'YTickLabel',a*[0:200:data0.size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% plot
    size_x  = parameters.global.array_size_x;
    size_y  = parameters.global.array_size_y;
    
    %%% arrays sizes
    % find difference in simulation array sizes and loaded array sizes
    delta_size_x = size_x - data0.size_x;
    delta_size_y = size_y - data0.size_y;
    
    %%% set shift size %%%%%%%%%%%%%%%%
    shift_x = floor(delta_size_x/2);
    shift_y = floor(delta_size_y/2);
    
    shifted_X0 = X0 + shift_x;
    shifted_Y0 = Y0 + shift_y;
    
    %%% crop loaded data to size of simulation array
    polygon_x = cluster_boundary(:,1);
    polygon_y = cluster_boundary(:,2);
    
    shifted_in = inpolygon(shifted_X0,shifted_Y0,polygon_x,polygon_y);
    X = shifted_X0(shifted_in);
    Y = shifted_Y0(shifted_in);
    
    %%% plot XY %%%%%%%%%%%%%%%%%%%%%%%
    sp1 = subplot(2,2,3); 
    set(sp1,'position',pos1)
    cla
    plot(X,Y,'.','Color',color) % data0.color
    
    axis equal
    axis([0 size_x 0 size_y])
        
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
        
end

%%% crop data %%%%%%%%%%%%%%%%%%%%%%%%%
Crop_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Crop data',...
    'FontSize',fs1,...
    'Position',[gapx 65 1.3*pbw pbh],...
    'Callback',@crop_callback); 

%%% @crop_callback %%%%%%%%%%%%%%%%%%%%
function crop_callback(varargin)

    size_x  = parameters.global.array_size_x;
    size_y  = parameters.global.array_size_y;
    
    XE = experimental_data(:,1);
    YE = experimental_data(:,2);
    
    %%% ginput 
    [p0x,p0y] = ginput(1);
    
    crop_frame_x = floor([p0x p0x+size_x-2 p0x+size_x-2 p0x p0x]);
    crop_frame_y = floor([p0y p0y p0y+size_y-2 p0y+size_y-2 p0y]);
    
    hold on
    plot(sp2,crop_frame_x,crop_frame_y,'k-')
    hold off
    
    %%% crop data by crop_frame
    polygon_x = crop_frame_x(1:4);
    polygon_y = crop_frame_y(1:4);
    
    points_in = inpolygon(XE,YE,polygon_x,polygon_y);
    X = XE(points_in) - p0x + 2;
    Y = YE(points_in) - p0y + 2;
    
    %%% get out
    data0.X = X;
    data0.Y = Y;
    
    sp1  = subplot(2,2,3); 
    set(sp1,'position',pos1)
    
    plot(sp1,X,Y,'.','Color',color)
    
    axis equal
    axis([0 size_x 0 size_y])
        
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
    

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[gapx 100 1.3*pbw pbh],...
    'Callback',@plot_data); 

%%% Save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[gapx gapy 0.6*pbw pbh],...
    'Callback',@Ok_callback); 

%%% @Ok_callback %%%%%%%%%%%%%%%%%%%%%%
function Ok_callback(~,~)
    
    size_x  = parameters.global.array_size_x;
    size_y  = parameters.global.array_size_y;
    a1 = floor(data0.X);
    a2 = floor(data0.Y);
    %%% linind cropped shifted loaded data
    linind_cropped_experimental_data = sub2ind([size_x,size_y],...
        floor(data0.X),floor(data0.Y));
    
    %%% linind locations in
    linind_locations_in = find(locations_array_in);
    
    %%% linind locations 
    linind_locations = setdiff(...
        linind_cropped_experimental_data,linind_locations_in);

    uiresume
    [X,Y] = ind2sub(size(locations_array_in),linind_locations);
    figure(8)
    hold on
    plot(X,Y,'.','Color',color)
    hold off
    
    close(25)
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position',[1*(gapx+pbw)+gapx gapy 0.6*pbw pbh],...
    'Callback',@Cancel_callback); 

%%% @Cancel_callback %%%%%%%%%%%%%%%%%%
function Cancel_callback(varargin)
    close(24)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% initialize subplots %%%%%%%%%%%%%%%
%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(sp1,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp2  = subplot(2,2,4); 
set(sp2,'position',pos2)

title('Experimental locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(Ok_pb,'Fixed',3,'Fixed',3);
align([Ok_pb Cancel_pb],'Fixed',3,'Bottom');

waitfor(Ok_pb)

end