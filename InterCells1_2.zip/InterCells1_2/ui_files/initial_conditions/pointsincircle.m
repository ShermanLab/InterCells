function linind_points_in_circle = pointsincircle(x0,y0,r,N,size_x,size_y,rand_array)


% the initial list of points is empty 
% drawing circle 
n  = 20; % point on circle
theta = 0:2*pi/n:2*pi;
% circle boundary 
circle_x = x0 + r*cos(theta);
circle_y = y0 + r*sin(theta);

% keeping circle inside boundary
if circle_x < 0
    circle_x = 0;
end
if circle_x > size_x
    circle_x = size_x;
end
if circle_y < 0
    circle_y = 0;
end
if circle_y > size_y
    circle_y = size_y;
end

circle_boundary = [circle_x',circle_y'];

% figure(8)
% plot(circle_x',circle_y','.')
% setting N points inside circle_boundary 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[X,Y]     = find(rand_array);
in_circle = inpolygon(X,Y,circle_boundary(:,1),circle_boundary(:,2));
rand_inpolygon = rand_array(in_circle);

X_inpolygon    = X(in_circle);
Y_inpolygon    = Y(in_circle);

sorted_rand_inpolygon   = sortrows([X_inpolygon,Y_inpolygon,rand_inpolygon],3);
points_in_circle        = sorted_rand_inpolygon(1:N,1:2);
linind_points_in_circle = sub2ind([size_x,size_y],...
    points_in_circle(:,1),points_in_circle(:,2));

end