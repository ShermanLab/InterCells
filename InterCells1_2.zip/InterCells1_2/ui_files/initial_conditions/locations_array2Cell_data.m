function Cell_data = locations_array2Cell_data(...
    locations_array,cn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data
output     : simulation_data
called by  : run_simulation
calling    : Emembrane
description: calculates the new locations of the molecules
and the new membranes values
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

size_x = size(locations_array,1);
size_y = size(locations_array,2);
n_types = max(max(locations_array));

%%% set initial membrane Z
Z = ones(size_x,size_y)*parameters.Cells(cn).membrane.Z0;

linindm_all = [];
typesm_all  = [];
zm_all      = [];
idm_all     = [];
e           = [];
on          = [];

for tn = 1:n_types
    
    %%% set lininds vector
    linindm     = find(locations_array == tn);
    linindm_all = [linindm_all;linindm];
    
    %%% set types vector
    typesm      = tn*ones(size(linindm));
    typesm_all  = [typesm_all;typesm];
        
    %%% set z vector
    h           = parameters.Cells(cn).molecule_type(tn).vertical_size;
    z           = h*ones(size(linindm));
    zm_all      = [zm_all;z];   

end

%%% set id vector
idm_all = 1:size(linindm_all,1);

%%% set e vector
e = zeros(size(idm_all));

%%% set on vector
on = ones(size(idm_all));

%%% set membrane height at molecules locations
Z(linindm_all) = zm_all;

%%% set initial rigidity
K = ones(size_x,size_y)*parameters.Cells(cn).membrane.rigidity;

%%% set initial diffusivity
D = ones(size_x,size_y)*parameters.Cells(cn).membrane.diffusivity;

%%% set initial energy
E = zeros(size_x,size_y);

%%% set simulation_data.Cells(cn)

Cell_data.Z    = Z;
Cell_data.K    = K;
Cell_data.D    = D;
Cell_data.Emem = E;
Cell_data.Emol = E;
Cell_data.LOC  = locations_array;


if n_types > 0
    Cell_data.molecules(idm_all,1) = idm_all;
    Cell_data.molecules(idm_all,2) = linindm_all;
    Cell_data.molecules(idm_all,3) = typesm_all;
    Cell_data.molecules(idm_all,4) = zm_all;
    Cell_data.molecules(idm_all,5) = e;
    Cell_data.molecules(idm_all,6) = on;
else
    Cell_data.molecules(idm_all,1) = 1;
    Cell_data.molecules(idm_all,2) = 1;
    Cell_data.molecules(idm_all,3) = 1;
    Cell_data.molecules(idm_all,4) = 0;
    Cell_data.molecules(idm_all,5) = 0;
    Cell_data.molecules(idm_all,6) = 1;
end

%%% mhc - pmhc %%%%%%%%%%%%%%%%%%%%%%%%
if 1
%     if strcmp(parameters.Cells(2).cellname,'APC')
    if strcmp(parameters.Cells(1).cellname,'Tcell')
        %%% finding ids of pmhc
        idm1_1 = idm_all(typesm_all == 1);
        %%% number of pmhc
        N1_1 = (length(idm1_1));
        %%% fraction of will be pmhc
        non_cognate_fraction = 0.99;
        %%% number of will be pmhc
        N_non_cognate = ceil(N1_1*non_cognate_fraction);
        %%% rand id of will be pmhc
        % rand_id = randperm(n,k)
        id_non_cognate = sort(randperm(N1_1,N_non_cognate));
        %%% setting typen of mhc to be 1.1
        typesm_all(idm1_1)  = 1.1;
        %%% setting typen of pmhc to be 1
        typesm_all(id_non_cognate) = 1;

        Cell_data.molecules(idm_all,3) = typesm_all;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end










