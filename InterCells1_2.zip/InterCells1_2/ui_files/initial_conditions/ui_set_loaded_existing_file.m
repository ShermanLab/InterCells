function linind_locations = ui_set_loaded_existing_file(...
        loaded_data,cluster_boundary,...
        locations_array_in,color,cn,tn,data0)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

% t = 0;
linind_locations = [];
results_data = loaded_data; % {:,1}
    
x0   = parameters.ui.mainfig.x0;
y0   = parameters.ui.mainfig.y0;
a    = parameters.global.pixel_size;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 5;
gapy = 5;

px   = x0+100;
py   = y0+100;
pw   = 500; %650;
ph   = 800; 

pbx  = 3;
pby  = 3;
pbw  = 95;
pbh  = 30;

%%% figures locations %%%%%%%%%%%%%%%%%
ox1 = 0.13; % 0.50;
ox2 = 0.56; % 0.50;
oy1 = 0.08; % 0.50;
oy2 = 0.54;
rw  = 0.8;
rh  = 0.5;

pos1 = [ox1 oy1 rw rh];

%%% get molecules names %%%%%%%%%%%%%%%
molecules_names = cell(1);
max_gr = 10;

nn = 0;
for cn0 = 1:2 % cell number
    types_n = size(parameters.Cells(cn0).molecule_type(:),1);
    for tn0 = 1:types_n % type number
        nn = nn + 1;
        molecule_name = parameters.Cells(cn0).molecule_type(tn0).name;
        molecules_names{nn,1} = molecule_name;
    end
end

%%% get times names %%%%%%%%%%%%%%%%%%%
times_names = cell(1);
n_times = size(results_data,1);

for tt = 1:n_times % time
    times_names{tt,1} = num2str(tt-1);
end

data0.t = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(24);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Loaded locations','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Loaded locations',...
    'FontSize',20,...
    'Position',[pw*0.2 ph-50 300 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',[ox1 550/ph rw 200/ph]);

%%% text %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String',['Choose molecule type and time to be located as ',...
    parameters.Cells(cn).molecule_type(tn).name],...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx 200-1*(pbh+gapy) rw*pw-2*gapx pbh]);

%%% popup1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Molecule type',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx 200-2*(pbh+gapy) 1.3*pbw pbh]);

popup1 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'FontSize',fs2,...
    'Position', [gapx 200-3*(pbh+gapy) 1.3*pbw pbh],...
    'Callback', @get_molecule);    

%%% @molecule2 %%%%%%%%%%%%%%%%%%%%%%%%
function get_molecule(varargin)
    val = get(popup1,'Value');
    switch val
        case 1
            cn0 = 1; tn0 = 1;
        case 2
            cn0 = 1; tn0 = 2;
        case 3
            cn0 = 1; tn0 = 3;
        case 4
            cn0 = 2; tn0 = 1;
        case 5
            cn0 = 2; tn0 = 2;
        case 6
            cn0 = 2; tn0 = 3;
    end
    
    data0.cn0 = cn0;
    data0.tn0 = tn0;

    uiresume
    
end % @molecule2

%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% popup3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Time',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[(1.3*pbw+gapx)+gapx 200-2*(pbh+gapy) 0.6*pbw pbh]);

popup3 = uicontrol(panel1,'Style', 'popup',...
    'String', times_names,...
    'FontSize',fs2,...
    'Position', [(1.3*pbw+gapx)+gapx 200-3*(pbh+gapy) 0.6*pbw pbh],...
    'Callback', @get_time); % @get_time

%%% get_times %%%%%%%%%%%%%%%%%%%%%%%%%
function get_time(varargin)
    data0.t = get(popup3,'Value');
end

%%% plot_data %%%%%%%%%%%%%%%%%%%%%%%%%
function plot_data(varargin)
   
    sp1 = subplot(2,2,3); 
    set(gca,'position',pos1)
    cla
    %%% get time
    data0.t = get(popup3,'Value');
	results_data{data0.t}.Cells(data0.cn0).LOC;
    %%% array1
    data0.array = results_data{data0.t}.Cells(data0.cn0).LOC == data0.tn0;
%     data0.color = parameters.Cells(data0.cn0).molecule_type(data0.tn0).color;
    data0.name  = parameters.Cells(data0.cn0).molecule_type(data0.tn0).name;
    [X0,Y0] = find(data0.array);

    
    %%% plot
    %%% get array size
    data0_size_x  = size(data0.array,1);
    data0_size_y  = size(data0.array,2);
    
    size_x  = parameters.global.array_size_x;
    size_y  = parameters.global.array_size_y;
    
    
    
    %%% arrays sizes
    % find difference in simulation array sizes and loaded array sizes
    delta_size_x = size_x - data0_size_x;
    delta_size_y = size_y - data0_size_y;
    
    %%% set shift size %%%%%%%%%%%%%%%%
    shift_x = floor(delta_size_x/2);
    shift_y = floor(delta_size_y/2);
    
    shifted_X0 = X0 + shift_x;
    shifted_Y0 = Y0 + shift_y;
    
    %%% crop loaded data to size of simulation array
    polygon_x = cluster_boundary(:,1);
    polygon_y = cluster_boundary(:,2);
    
    shifted_in = inpolygon(shifted_X0,shifted_Y0,polygon_x,polygon_y);
    X = shifted_X0(shifted_in);
    Y = shifted_Y0(shifted_in);
    
    %%% get out
    data0.X = X;
    data0.Y = Y;
    %%% plot XY %%%%%%%%%%%%%%%%%%%%%%%
    plot(X,Y,'.','Color',color) % data0.color
    
    axis equal
    axis([0 size_x 0 size_y])
        
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
    
  
end

%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[gapx 65 1.3*pbw pbh],...
    'Callback',@plot_data); 

%%% Save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[gapx gapy 0.6*pbw pbh],...
    'Callback',@Ok_callback); 

%%% @Ok_callback %%%%%%%%%%%%%%%%%%%%%%
function Ok_callback(~,~)
    
    %%% linind cropped shifted loaded data
    linind_loaded_data = sub2ind(size(locations_array_in),...
        data0.X,data0.Y);
    
    %%% linind locations in
    linind_locations_in = find(locations_array_in);
    
    %%% linind locations 
    linind_locations = setdiff(linind_loaded_data,linind_locations_in);
%     locations_array_in(linind_loaded_data) = tn;
    uiresume
    [X,Y] = ind2sub(size(locations_array_in),linind_locations);
    figure(8)
    hold on
    plot(X,Y,'.','Color',color)
    hold off
    
    close(24)
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position',[1*(gapx+pbw)+gapx gapy 0.6*pbw pbh],...
    'Callback',@Cancel_callback); 

%%% @Cancel_callback %%%%%%%%%%%%%%%%%%
function Cancel_callback(varargin)
    close(24)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% initialize subplots %%%%%%%%%%%%%%%
%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(gca,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(Ok_pb,'Fixed',3,'Fixed',3);
align([Ok_pb Cancel_pb],'Fixed',3,'Bottom');

waitfor(Ok_pb)

end