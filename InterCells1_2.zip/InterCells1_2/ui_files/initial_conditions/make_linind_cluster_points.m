function linind_cluster_points = make_linind_cluster_points(...
    cluster_boundary,cluster_density,locations_array,color)   
   
%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

%%% getting full simulation array size
size_x     = parameters.global.array_size_x;
size_y     = parameters.global.array_size_y;
pixel_size = parameters.global.pixel_size;

micron2pixel = 1000/pixel_size;
%%% creating random array of the full simulation array size
rand_array = rand(size_x,size_y);
[x,y,~]    = find(rand_array);

%%% getting boundary points
polygon_x  = cluster_boundary(:,1);
polygon_y  = cluster_boundary(:,2);

%%% calculating the polygon area in pixel units
polygon_area = polyarea(polygon_x',polygon_y');
N            = floor(cluster_density*polygon_area/(micron2pixel^2)); % target number of points 

%%% finding points inside cluster boundary.
% 'in_polygon' is a logical vector. linind indices inside the 
% polygon = 1, outside = 0. 
in_polygon = inpolygon(x,y,polygon_x,polygon_y);

%%% linind_existing_points
% excluding location that are already occupied by 'existing points'
linind_existing_points = find(locations_array);
if ~isempty(linind_existing_points)
    in_polygon(linind_existing_points) = 0;
end

%%% getting rand_array values that are inside the polygon
rand_inpolygon = rand_array(in_polygon);
x_inpolygon    = x(in_polygon);
y_inpolygon    = y(in_polygon);

%%% scattering N points uniformly in the polygon area
sorted_rand_inpolygon = sortrows([x_inpolygon,y_inpolygon,rand_inpolygon],3);
cluster_points = sorted_rand_inpolygon(1:N,1:2);

%%% plot new added points
figure(8)
hold on
plot(cluster_points(:,1),cluster_points(:,2),'.','Color',color)
hold off
drawnow
linind_cluster_points = sub2ind(size(locations_array),cluster_points(:,1),cluster_points(:,2));

end