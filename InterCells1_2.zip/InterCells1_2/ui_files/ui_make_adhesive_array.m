function adhesive_array = ui_make_adhesive_array(cn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data
output     : simulation_data
called by  : run_simulation
calling    : Emembrane
description: calculates the new locations of the molecules
and the new membranes values
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

adhesive_array = [];
   
size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;
color0 = parameters.global.adhesive_surface.color;
circ_r = parameters.global.adhesive_surface.circles_radius;

% locations_array = simulation_data.Cells(cn).LOC == tn;

x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

fs1 = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 2;
gapy = 2;

px   = x0+110;
py   = y0+300;
pw   = 150;
ph   = 217; 

pbx  = 3;
pby  = 3;
pbw  = pw-4;
pbh  = 30;

bgh   = ph;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(39);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');
    
uicontrol('Parent',p,...
  'Style','text',...
  'String','Distribution method','FontSize',fs3,...
  'Position',[2 ph-30 pbw 30]);

%%% button group %%%%%%%%%%%%%%%%%%%%%%
bg = uibuttongroup('Parent',p,...
  'visible','on',...
  'Position',[0 0 1 1]);

%%% generate file from experiment %%%%%
pb1 = uicontrol(bg,'Style','PushButton',...
  'String','Load experimental data',...
  'FontSize',fs2,...
  'Position',[gapx bgh-2*(gapy+pbh) pbw pbh],...
  'Callback',@get_experimental_data,...
  'Enable','off');

%%% @get_experimental_data %%%%%%%%%%%%
function get_experimental_data(varargin)
    
    experimental_data = uigetfile([cd,'\Experimental_data']);
    DD0 = load(experimental_data);
    try
        XY_data = DD0.cropped_XY1_1; 
    catch
        
    end
    
    try
        XY_data = DD0.cropped_XY1_2; 
    catch
        
    end
    
    try
        XY_data = DD0.cropped_XY1_3; 
    catch
        
    end

    size_x             = parameters.global.array_size_x;
    size_y             = parameters.global.array_size_y;    
    cluster_boundary_x = [1 size_x size_x 1];
    cluster_boundary_y = [1 1 size_y size_y];
    cluster_boundary   = [cluster_boundary_x',cluster_boundary_y'];

    
    
    linind_locations = ui_set_experimental_data(...
        XY_data,cluster_boundary,...
        locations_array_in,color,cn,tn,[]);

    locations_array_out(linind_locations) = tn; 
    uiresume
    close(19)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% get_existing_data %%%%%%%%%%%%%%%%%
pb2 = uicontrol(bg,'Style','PushButton',...
  'String','Load existing file',...
  'FontSize',fs2,...
  'Position',[gapx bgh-3*(gapy+pbh) pbw pbh],...
  'Callback',@get_existing_data,...
  'Enable','off');

%%% @get_existing_data %%%%%%%%%%%%%%%%
function get_existing_data(varargin)
    existing_data_file = uigetfile([cd,'\Results\results_20180523205429']);
    
    % load(RESULTS_OF_RUNS);
    DD0 = load(existing_data_file);
    DD1 = DD0.RESULTS_OF_RUNS;
    loaded_data = DD1;
    
    size_x             = parameters.global.array_size_x;
    size_y             = parameters.global.array_size_y;    
    cluster_boundary_x = [1 size_x size_x 1];
    cluster_boundary_y = [1 1 size_y size_y];
    cluster_boundary   = [cluster_boundary_x',cluster_boundary_y'];
    
    linind_locations = ui_set_loaded_existing_file(...
        loaded_data,cluster_boundary,...
        locations_array_in,color,cn,tn,[]);

    adhesive_array = ones(); 
    uiresume
    close(19)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%% uniform distribution %%%%%%%%%%%%%%
pb3 = uicontrol(bg,'Style','PushButton',...
  'String','Uniform distribution',...
  'FontSize',fs2,...
  'Position',[gapx bgh-4*(gapy+pbh) pbw pbh],...
  'Callback',@full_array);   

%%% @uniform distribution %%%%%%%%%%%%%
function full_array(varargin) 
    
    adhesive_area = ones(size_x,size_y); 
    parameters.global.adhesive_surface(cn).array = adhesive_area;
    parameters.global.adhesive_surface(cn).linind = ...
        find(parameters.global.adhesive_surface.array);
    
    %%% plot locations
    [x_in,y_in] = find(parameters.global.adhesive_surface.array);
    figure(8)
    hold on
    plot(x_in,y_in,'.','Color',color0)
    hold off
    %%%
    
    uiresume
    close(39)
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% get_circular_clusters %%%%%%%%%%%%%
pb4 = uicontrol(bg,'Style','PushButton',...
  'String','Random circles',...
  'FontSize',fs2,...
  'Position',[gapx bgh-5*(gapy+pbh) pbw pbh],...
  'Callback',@random_circles); 

%%% @get_circular_clusters %%%%%%%%%%%%
function random_circles(varargin)
    
%     circles_radius  = 20; %(nm)
    circles_density = 5; % #/um^2
    area_microns    = (size_x*a/1000)*(size_y*a/1000);
    N_circles       = round(circles_density*area_microns);
    
    centers_array = zeros(size_x,size_y);

    centers_locations_x = randi(size_x,N_circles,1);
    centers_locations_y = randi(size_y,N_circles,1);
    
    linind_centers_locations = sub2ind([size_x,size_y],...
        centers_locations_x,centers_locations_y);

    %%% 
    centers_array(linind_centers_locations) = 1;
    h = fspecial('disk',circ_r/a);

    adhesive_area = real(logical(conv2(centers_array,h,'same')));
    parameters.global.adhesive_surface(cn).array = adhesive_area;
    parameters.global.adhesive_surface(cn).linind = ...
        find(parameters.global.adhesive_surface.array);
    
    %%% plot locations
    [x_in,y_in] = find(parameters.global.adhesive_surface.array);
    figure(8)
    hold on
    plot(x_in,y_in,'.','Color',color0)
    hold off
    
    %%%
    uiresume
    close(39)
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% get_user_defined_clusters %%%%%%%%%
pb5 = uicontrol(bg,'Style','PushButton',...
  'String','User defined',...
  'FontSize',fs2,...
  'Position',[gapx bgh-6*(gapy+pbh) pbw pbh],...
  'Callback',@user_defined);   

%%% @get_user_defined_clusters %%%%%%%%
function user_defined(varargin)
    
    polygon_boundary = draw_polygon(); % (parameters)
    
    [x,y,~]    = find(ones(size_x,size_y));

    polygon_x  = polygon_boundary(:,1);
    polygon_y  = polygon_boundary(:,2);

    %%% finding points inside cluster boundary.
    % 'in_polygon' is a logical vector. linind indices inside the 
    % polygon = 1, outside = 0. 
    in_polygon = inpolygon(x,y,polygon_x,polygon_y);

    x_inpolygon    = x(in_polygon);
    y_inpolygon    = y(in_polygon);

    linind_locations = sub2ind([size_x,size_y],x_inpolygon,y_inpolygon);  
     
    adhesive_area = zeros(size_x,size_y);
    adhesive_area(linind_locations) = 1;
    
    parameters.global.adhesive_surface(cn).array = adhesive_area;
    parameters.global.adhesive_surface(cn).linind = ...
        find(parameters.global.adhesive_surface.array);
    
    %%% plot locations
    hold on
    figure(8)
    plot(x_inpolygon,y_inpolygon,'.','Color',color0)
    hold off
    %%%
    
    uiresume
    close(39)
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

uiwait % waitfor(Ok_pb)

end