function ui_Cell_membrane_table(cn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,Cell_number
output     : parameters
called by  : ui_main
calling    : Cell_membrane_parameters2table
description: opens the table of membranes parameters,
enables the user to edit parameters in the table and
update it.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

%%% Cell_parameters to Cell_membrane_parameters
Cell_membrane_parameters = parameters.Cells(cn).membrane;
Cell_name                = parameters.Cells(cn).cellname;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
table_Cell_membrane = Cell_membrane_parameters2table(cn);

dat            = table_Cell_membrane;
nrows          = size(dat,1);
%%% 

columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {180,60,60};
columneditable = [false false true]; 

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

rowh = 18;
pw   = 335;
ph   = nrows*rowh+90; % nrows*rowh+80
px   = x0+150;
py   = y0+408;

% gapx = 2;
% gapy = 2;

fs1 = 8;
fs2 = 10;
fs3 = 12;
fs4 = 14;

p = figure(17);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Cell membrane table','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
text1 = uicontrol('Parent',p,...
        'Style', 'Text',...
        'String',[Cell_name, ' membrane parameters table'],...
        'Position', [0 ph-30 350 30],...
        'FontSize',fs4); 

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
gapx = 3;
gapy = 3;
tw   = 350;
th   = nrows*rowh+57;

t = uitable(p,'Data',dat,...
    'ColumnName'    ,columnname,...
    'ColumnFormat'  ,columnformat,...
    'ColumnWidth'   ,columnwidth,...
    'ColumnEditable',columneditable,...
    'Position'      ,[0 0 tw th]);

%%% Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cancel_pbx = 231;
pbw = 50;
pbh = 20;

Cancel_pb = uicontrol(p,...
    'Style'   , 'pushbutton',...
    'String'  ,'Cancel',...
    'Position', [Cancel_pbx gapy pbw pbh],...
    'FontSize',fs1,...
    'Callback','close(17)'); 


%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pbx = Cancel_pbx + pbw + gapx;
Ok_pby = 3;

Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String'  ,'Ok',...
    'Position', [Ok_pbx gapy pbw pbh],...
    'FontSize',fs1,...
    'Callback',@Ok); 

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align([text1,t],'Left','Fixed',0)
    
function Ok(varargin)
    table = get(t,'Data');
    table2membraneparameters(table,cn);
    uiresume
    close(17)
end

waitfor(Ok_pb)

end






