function table2membraneparameters(table,cn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : table
output     : membrane_parameters
called by  : ui_Cell_membrane_table
calling    : none
description: assigns the the table values to the membrane 
parameters and the parameters that do not appear in the table.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

%%% rigidity 
parameters.Cells(cn).membrane.rigidity          = table{1,3};
parameters.Cells(cn).membrane.min_rigidity      = table{2,3};
parameters.Cells(cn).membrane.max_rigidity      = table{3,3};
parameters.Cells(cn).membrane.local_rigidity    = table{4,3};
%%% diffusivity 
parameters.Cells(cn).membrane.diffusivity       = table{6,3};
parameters.Cells(cn).membrane.min_diffusivity   = table{7,3};
parameters.Cells(cn).membrane.max_diffusivity   = table{8,3};
parameters.Cells(cn).membrane.local_diffusivity = table{9,3};
%%% Z
parameters.Cells(cn).membrane.Z0                = table{11,3};
parameters.Cells(cn).membrane.min_Z             = table{12,3};
parameters.Cells(cn).membrane.max_Z             = table{13,3};
parameters.Cells(cn).membrane.dz                = table{14,3};
%%%

end








