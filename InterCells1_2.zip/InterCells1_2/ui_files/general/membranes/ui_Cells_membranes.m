function ui_Cells_membranes()
  
%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : ui_Cell_membrane_table
description: opens the ui_Cell_membrane_table of 
the selected cell.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

x0   = parameters.ui.mainfig.x0;
y0   = parameters.ui.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs8  = 8;
fs10 = 10;
fs12 = 12;

gapx = 2;
gapy = 2;

px   = x0+170;
py   = y0+610;
pw   = 135;
ph   = 130; 

pbx  = 3;
pby  = 3;
pbw  = pw-gapx;
pbh  = 30;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(17);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','ui cells surfaces','NumberTitle','off');

%%% text Cell1 molecules %%%%%%%%%%%%%%
text1 = uicontrol('Parent',p,...
  'Style','text',...
  'String','Cells surfaces',...
  'FontSize',fs12,...
  'Position',[2 ph-pbh pw pbh]);

%%% Cell1 molecule1 %%%%%%%%%%%%%%%%%%%
pb1 = uicontrol(p,'Style','PushButton',...
  'String','Cell1 surface',...
  'FontSize',fs10,...
  'BackgroundColor',[1 1 1],...
  'Position',[gapx ph-2*pbh pbw pbh],...
  'Callback',['ui_Cell_membrane_table(1)']);

%%% Cell1 molecule2 %%%%%%%%%%%%%%%%%%%
pb2 = uicontrol(p,'Style','PushButton',...
  'String','Cell2 surface',...
  'FontSize',fs10,...
  'ForegroundColor',[1 1 1],...
  'BackgroundColor',0.2*[1 1 1],...
  'Position',[gapx ph-3*pbh pbw pbh],...
  'Callback',['ui_Cell_membrane_table(2)']);


%%% Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(p,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs8,...
    'Position',[pbx pby 0.5*pbw 20],...
    'Callback','close(17)'); 

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(text1,'Left'   ,'Top');
align(pb1  ,'Fixed',2,'none');
align([pb1 pb2 Close_pb],'Left','Fixed',gapy);

end











