function Cell_molecule_type_parameters = table2moleculeparameters(...
    table,cn,tn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : table
output     : membrane_parameters
called by  : ui_Cell_membrane_table
calling    : none
description: assigns the the table values to the molecule_type
parameters and the parameters that do not appear in the table.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

%%% 
parameters.Cells(cn).molecule_type(tn).name                = table{1,3};
parameters.Cells(cn).molecule_type(tn).lateral_size        = table{2,3};
parameters.Cells(cn).molecule_type(tn).vertical_size       = table{3,3};
%%% interactions
parameters.Cells(cn).molecule_type(tn).binding_top         = table{5,3};
parameters.Cells(cn).molecule_type(tn).binding_bottom      = table{6,3};
parameters.Cells(cn).molecule_type(tn).binding_strength    = table{7,3};
parameters.Cells(cn).molecule_type(tn).spring_k            = table{8,3};
parameters.Cells(cn).molecule_type(tn).force_z             = table{9,3};
%%% clusters prperties
parameters.Cells(cn).molecule_type(tn).diffusion_constant  = table{11,3};
parameters.Cells(cn).molecule_type(tn).global_density      = table{12,3};
parameters.Cells(cn).molecule_type(tn).cluster_density     = table{13,3};
parameters.Cells(cn).molecule_type(tn).density_of_clusters = table{14,3};
%%% self clustering
parameters.Cells(cn).molecule_type(tn).self_clustering       = table{16,3};
parameters.Cells(cn).molecule_type(tn).self_clustering_binding_range = table{17,3};
parameters.Cells(cn).molecule_type(tn).self_clustering_p_on  = table{18,3};
parameters.Cells(cn).molecule_type(tn).self_clustering_p_off = table{19,3};
%%% transport 
parameters.Cells(cn).molecule_type(tn).transport.use         = table{21,2};
parameters.Cells(cn).molecule_type(tn).transport.speed       = table{22,2};

Cell_molecule_type_parameters = parameters.Cells(cn).molecule_type(tn);

end


