function ui_Surfaces_types()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters simulation_data

x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

fs1 = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gapx = 3;
gapy = 3;

px   = x0+150;
py   = y0+475;
pw   = 110;
ph   = 250; %230; %150; % nrows*rowh+80

pbx  = 3;
pby  = 3;
pbw  = 50;
pbh  = 30;

rbh  = 25;

p = figure(4);
    set(p,'Position',[px py pw ph])
    set(p,'MenuBar', 'none');

bg1 = uibuttongroup(p,...
    'visible','on',...
    'Position',[0 35/ph+(4*rbh+6*gapy)/ph 1 (2*rbh+4*gapy)/ph]);

%%% title1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
text1 = uicontrol(bg1,...
    'Style','text',...
    'String','Surface1 type',...
    'FontSize',fs3,...
    'BackgroundColor',[1 1 1],...
    'Position',[0 (2*rbh+4*gapy) pw pbh]);

%%% radio button Cells(1),1 %%%%%%%%%%%
rb1_1 = uicontrol(bg1,'Style','Radio',...
    'String','T-cell',...
    'FontSize',fs2,...
    'Position',[gapx (1*rbh+2*gapy) pw rbh]);

%%% radio button Cells(1),2 %%%%%%%%%%%
rb1_2 = uicontrol(bg1,'Style','Radio',...
    'String','None',...
    'FontSize',fs2,...
    'Position',[gapx gapy pw rbh]);

%%% set radiobutton values %%%%%%%%%%%
%%% bg1
cname1 = parameters.Cells(1).cellname;
switch cname1
    case 'Tcell'
        set(bg1,'SelectedObject',rb1_1);
    case 'None'
        set(bg1,'SelectedObject',rb1_2);    
        
    %%% No cell1 %%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(parameters.Cells(1).cellname,'None')
        locations_array1 = zeros(size_x,size_y);
        Cell1_data = locations_array2Cell_data(locations_array1,1);
        simulation_data.Cells(1) = Cell1_data;
        
        parameters.Cells(1).molecule_type(1).force_z = 0;
        parameters.Cells(1).molecule_type(2).force_z = 0;
        parameters.Cells(1).molecule_type(3).force_z = 0;

        parameters.Cells(2).molecule_type(1).force_z = 0;
        parameters.Cells(2).molecule_type(2).force_z = 0;
        parameters.Cells(2).molecule_type(3).force_z = 0;
    end
        
end

%%% buttongroup2 %%%%%%%%%%%%%%%%%%%%%%
bg2 = uibuttongroup(p,...
    'visible','on',...
    'Position',[0 pbh/ph 1 (3*rbh+5*gapy)/ph]);

%%% title2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
text2 = uicontrol(bg2,...
    'Style','text',...
    'String','Surface2 type',...
    'FontSize',fs3,...
    'ForegroundColor',[1 1 1],...
    'BackgroundColor',0.2*[1 1 1],...
    'Position',[1 (3*rbh+5*gapy) pw pbh]);

%%% radio button Cells(2),1 %%%%%%%%%%%
rb2_1 = uicontrol(bg2,'Style','Radio',...
    'String','Coverslip',...
    'FontSize',fs2,...
    'Position',[gapx (2*rbh+3*gapy) pw rbh]);

%%% radio button Cells(2),2 %%%%%%%%%%%
rb2_2 = uicontrol(bg2,'Style','Radio',...
    'String','APC',...
    'FontSize',fs2,...
    'Position',[gapx (1*rbh+2*gapy) pw rbh]);

%%% radio button Cells(2),2 %%%%%%%%%%%
rb2_3 = uicontrol(bg2,'Style','Radio',...
    'String','None',...
    'FontSize',fs2,...
    'Position',[gapx gapy pw rbh]);

%%% set radiobutton values %%%%%%%%%%%
%%% bg2
cname2 = parameters.Cells(2).cellname;
switch cname2
    case 'Coverslip'
        set(bg2,'SelectedObject',rb2_1);
    case 'APC'
        set(bg2,'SelectedObject',rb2_2);
    case 'None'
        set(bg2,'SelectedObject',rb2_3); 
end


%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[pbx pby pbw 25],...
    'Callback',@Ok_callback); 


%%% apply changes to Cells %%%%%%%%%%%%
function Ok_callback(varargin) 
    
    parameters.Cells(1).cellname = get(get(bg1,'SelectedObject'),'String');
    parameters.Cells(2).cellname = get(get(bg2,'SelectedObject'),'String');

    %%% compare current and default sizes 
    default_size_x = parameters.default_global.array_size_x;
    default_size_y = parameters.default_global.array_size_y;
    
    size_x         = parameters.global.array_size_x;
    size_y         = parameters.global.array_size_y;
    
    if size_x == default_size_x && size_y == default_size_y
    %%% use default locations arrays %%
        if strcmp(parameters.Cells(1).cellname,'Tcell')
            parameters.Cells(1)          = parameters.Tcell;
            %%% use default Cell1
            simulation_data.Cells(1)     = make_initial_Cell1_data();
        end

        %%% Cells(2) = Coverslip %%%%%%%%%%
        if strcmp(parameters.Cells(2).cellname,'Coverslip')

            parameters.Cells(2)          = parameters.Coverslip;
            simulation_data.Cells(2)     = make_initial_Cell2_data();
        end

        %%% Cells(2) = APC %%%%%%%%%%%%%%%%
        if strcmp(parameters.Cells(2).cellname,'APC')

            parameters.Cells(2)          = parameters.APC;
            simulation_data.Cells(2)     = make_initial_Cell2_data();
        end
        
    else 
        
        %%% use empty locations arrays %%%%   
        %%% Cells(1)
        locations_array1 = zeros(size_x,size_y);
        Cell1_data = locations_array2Cell_data(locations_array1,1);
        simulation_data.Cells(1) = Cell1_data;
        
        %%% Cells(2)
        locations_array2 = zeros(size_x,size_y);
        Cell2_data = locations_array2Cell_data(locations_array2,2);
        simulation_data.Cells(2) = Cell2_data;           

    end % default / new
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    

    %%% Cells(2) = Coverslip %%%%%%%%%%
    if strcmp(parameters.Cells(2).cellname,'Coverslip')

        parameters.Cells(2)          = parameters.Coverslip;
        simulation_data.Cells(2)     = make_initial_Cell2_data();

    end
    
    %%% Cells(2) = APC %%%%%%%%%%%%%%%%
    if strcmp(parameters.Cells(2).cellname,'APC')

        parameters.Cells(2)          = parameters.APC;
        simulation_data.Cells(2)     = make_initial_Cell2_data();

    end
    
%     %%% No cell1 %%%%%%%%%%%%%%%%%%%%%%%
%     if strcmp(parameters.Cells(1).cellname,'No cell')
%         locations_array1 = zeros(size_x,size_y);
%         Cell1_data = locations_array2Cell_data(locations_array1,1);
%         simulation_data.Cells(1) = Cell1_data;
%         
%         parameters.Cells(1).molecule_type(1).force_z = 0;
%         parameters.Cells(1).molecule_type(2).force_z = 0;
%         parameters.Cells(1).molecule_type(3).force_z = 0;
% 
%         parameters.Cells(2).molecule_type(1).force_z = 0;
%         parameters.Cells(2).molecule_type(2).force_z = 0;
%         parameters.Cells(2).molecule_type(3).force_z = 0;
%     end
    
    %%% No cell2 %%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(parameters.Cells(2).cellname,'None')
        locations_array2 = zeros(size_x,size_y);
        Cell2_data = locations_array2Cell_data(locations_array2,2);
        simulation_data.Cells(2) = Cell2_data;
        
        parameters.Cells(1).molecule_type(1).force_z = 0;
        parameters.Cells(1).molecule_type(2).force_z = 0;
        parameters.Cells(1).molecule_type(3).force_z = 0;
        
        parameters.Cells(2).molecule_type(1).force_z = 0;
        parameters.Cells(2).molecule_type(2).force_z = 0;
        parameters.Cells(2).molecule_type(3).force_z = 0;
    end
    
    uiresume
    ui_main()
    close(4)

end

waitfor(Ok_pb)

end






