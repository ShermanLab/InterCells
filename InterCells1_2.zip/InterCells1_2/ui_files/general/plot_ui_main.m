function plot_ui_main()

% plot_ui_main(parameters,simulation_data)
%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters simulation_data

%%% subplots sizes and locations
rx = 0.27; % ratio of x origin location
ry = 0.10; % ratio of y origin location
rw = 0.35; % ratio of subplot width
rh = 0.35; % ratio of subplot height
dx = 0.35; % ratio of delta x
dy = 0.45; % ratio of delta y

%%% font sizes
fs1 = 8;
fs2 = 10;
fs3 = 12;
fs4 = 14;

%%% molecules properties %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for plot_proteins_properties = 1
    pos1 = [rx*0.9 ry+dy-0.05 rw rh*1.1];
    sp1 = subplot('Position',pos1);
    %%% locations %%%%%%%%%%%%%%%%%%%%%%%%%
    mz1    = 70;
    mz2    = 0;
    mx_min = 0;
    mx_max = 120;
    dx_p   = 15;
    
    
    %%% Cells names
    Cell1_name = parameters.Cells(1).cellname;
    Cell2_name = parameters.Cells(2).cellname;   
    
    
    %%% plot membranes %%%%%%%%%%%%%%%%
    %%% PLL
%     PLL_parameters = parameters.global.PLL;
    PLL_use                = parameters.global.PLL.use;
    PLL_color              = parameters.global.PLL.color;
    PLL_U                  = parameters.global.PLL.binding_strength;
    PLL_bmax               = parameters.global.PLL.binding_top;

    %%% adhesive surface
    adhesive_surface_use   = parameters.global.adhesive_surface.use;
    adhesive_surface_color = parameters.global.adhesive_surface.color;
    adhesive_surface_U     = parameters.global.adhesive_surface.binding_strength;
        
    %%% plot membranes
%     plot([mx_min mx_max],[mz1 mz1]    ,'-','Color',[1 1 1],'LineWidth',6)
%     hold on
%     plot([mx_min mx_max],[mz2 mz2]    ,'-','Color',[0 0 0],'LineWidth',6)
%     
    %%% plot (PLL)
    if strcmp(Cell2_name,'Coverslip')
        if PLL_use
            plot([mx_min mx_max],[mz2+1 mz2+1],'-','Color',PLL_color,...
                'LineWidth',2)
            text(mx_max*0.6,mz2+5,'Poly-L-lysine','Color',PLL_color,...
                'FontWeight','Bold')
        end
    end
    
    %%% membranes %%%%%%%%%%%%%%%%%%%%%
    

    text((mx_min + mx_max)/2,mz1+12,['Surface1 = ',Cell1_name],...
        'FontSize',fs4,'HorizontalAlignment','Center')
    text((mx_min + mx_max)/2,mz2-12,['Surface2 = ',Cell2_name],...
        'FontSize',fs4,'HorizontalAlignment','Center')
    
    K01 = parameters.Cells(1).membrane.rigidity;
    K02 = parameters.Cells(2).membrane.rigidity;
    a   = parameters.global.pixel_size;
    %%% Diffusions %%%%%%%%%%%%%%%%%%%%%%%%
    Dscale = 2000;
    d0     = 75;
    y0_D   = mz1 - 13;
    dy_D   = 7;
    
    text(d0-10,mz1-6,'Diffiusion coefficients (\mum^2/sec)',...
        'FontSize',fs2,'FontWeight','bold')
        
    
    n_types1 = numel(parameters.Cells(1).molecule_type);
    n_types2 = numel(parameters.Cells(2).molecule_type);
    
    if ~strcmp(parameters.Cells(2).cellname,'No cell')
        %%% surface2
        plot([mx_min mx_max],[mz2 mz2]    ,'-','Color',0.1*[1 1 1],'LineWidth',6)
        hold on
    %%% loops %%%%%%%%%%%%%%%%%%%%%%%%%
        for t2 = 1:n_types2
            %%% color
            color2 = parameters.Cells(2).molecule_type(t2).color;
            %%% names 
            name2  = parameters.Cells(2).molecule_type(t2).name;
            %%% heights 
            h2     = parameters.Cells(2).molecule_type(t2).vertical_size;
            %%% diffusions 
            D2     = parameters.Cells(2).molecule_type(t2).diffusion_constant;
            %%% potentials 
            U2     = parameters.Cells(2).molecule_type(t2).binding_strength;
            %%% plot molecule_type(t2)
            plot([t2*dx_p t2*dx_p],[0 h2+0],...
                '-','Color',color2,'LineWidth',10)
            %%% text molecule name
            text(t2*dx_p,mz2-5,name2,'FontSize',fs1,...
                'HorizontalAlignment','Center',...
                'VerticalAlignment','Middle',...
                'Color',color2,...
                'FontWeight','Bold')
            %%% text molecule size
            text(t2*dx_p,mz2+h2,[num2str(h2),'nm'],...
                'FontSize',fs1,...
                'HorizontalAlignment','Center',...
                'VerticalAlignment','Bottom',...
                'Rotation',0)
            %%% plot molecule diffusion
            plot([d0 d0+Dscale*D2+0.5],[y0_D - (2+t2)*dy_D y0_D - (2+t2)*dy_D],...
                '-','Color',color2,'LineWidth',6)
            %%% text molecule diffusion
            text(mx_max - 20,y0_D - (2+t2)*dy_D,[num2str(D2)],'FontSize',fs1)

        end
    end %~strcmp(parameters.Cells(2).cellname,'No cell')
    
    %%% Cells(1)
    if ~strcmp(parameters.Cells(1).cellname,'No cell')
        %%% surface1
        plot([mx_min mx_max],[mz1 mz1]    ,'-','Color',[1 1 1],'LineWidth',6)
        hold on
    
        for t1 = 1:n_types1
            %%% colors 
            color1 = parameters.Cells(1).molecule_type(t1).color;
            %%% names 
            name1 = parameters.Cells(1).molecule_type(t1).name;
            %%% heights 
            h1    = parameters.Cells(1).molecule_type(t1).vertical_size;
            %%% diffusions 
            D1    = parameters.Cells(1).molecule_type(t1).diffusion_constant;
            %%% plot molecule_type(t1)
            plot([t1*dx_p t1*dx_p],[mz1 mz1-h1],...
                '-','Color',color1,'LineWidth',10)
            %%% text molecule name
            text(t1*dx_p,mz1+5,name1,'FontSize',fs1,...
                'HorizontalAlignment','Center',...
                'Color',color1,...
                'FontWeight','Bold')
            %%% Mtext molecule size
            text(t1*dx_p,mz1-h1,[num2str(h1),'nm'],...
                'FontSize',fs1,...
                'HorizontalAlignment','Center',...
                'VerticalAlignment','Top',...
                'Rotation',0)
            %%% plot molecule diffusion
            plot([d0 d0+Dscale*D1],[y0_D - (t1-1)*dy_D y0_D - (t1-1)*dy_D],...
                '-','Color',color1,'LineWidth',6)
            %%% text molecule diffusion
            text(mx_max-20,y0_D - (t1-1)*dy_D,[num2str(D1)],'FontSize',fs1)

        end
    end % ~strcmp(parameters.Cells(2).cellname,'No cell')
    hold off
%     axis equal
    axis([-10 130 -20 90])
    
    set(gca,'color',0.85*[1 1 1]);
    
    title('Molecules','FontSize',fs4)
    % xlabel('X (nm)','FontSize',12)
    ylabel('Z (nm)','FontSize',fs3)
    set(gca,'xtick',[]);
    set(gca,'xticklabel',[]);
    axis off
    % xtick('none')
    % XTickLabel([''])
    
end % plot_proteins_properties
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% interactions properties %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for plot_interaction_properties = 1:1
    pos2 = [(rx+dx)*1.04 ry+dy-0.05 rw*0.7 rh*1.1]; %0.73
    sp2 = subplot('Position',pos2);
    cla(sp2)
    
    ux = [   0    1   1   0];
%     uy = [-0.5 -0.5 0.5 0.5];
    
    % plot arrows
    plot([-30 60],[0 0],'-','Color',[0 0 0],'LineWidth',3)
    hold on
    plot([0 0],[0 75],'-','Color',[0 0 0],'LineWidth',3)
    text(-15,80,'Z(nm)','FontSize',fs3,'FontWeight','bold')
    text(55 ,-5,'KT'   ,'FontSize',fs3,'FontWeight','bold')
    
    
    %%% plot %%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Cells(2)
    for t2 = 1:n_types2
        %%% molecule height
%         h2    = parameters.Cells(2).molecule_type(t2).vertical_size;
        %%% attracting potentials 
%         U2    = parameters.Cells(2).molecule_type(t2).binding_strength;
        %%% molecule color
%         color2 = parameters.Cells(2).molecule_type(t2).color;
%         mol2_ux  = ux*U2;
%         mol2_uy  = uy*w1  + h1;  
%         %%% plot 
%         plot(mol2_ux,mol2_uy,'-','Color',color2,'LineWidth',3)
    end
    
    %%% Cells(1)
    for t1 = 1:n_types1
        
        %%% molecule height
        h1     = parameters.Cells(1).molecule_type(t1).vertical_size;
        
        %%% molecule spring constant
        k1     = parameters.Cells(1).molecule_type(t1).spring_k;
        
        %%% attracting potentials 
        U1     = parameters.Cells(1).molecule_type(t1).binding_strength;
        
        %%% potential well width
        w1     = parameters.Cells(1).molecule_type(t1).potential_width;
        bot1   = parameters.Cells(1).molecule_type(t1).binding_bottom;
        top1   = parameters.Cells(1).molecule_type(t1).binding_top;
        
        uy = [bot1 bot1 top1 top1]; 
        
        %%% molecule color
        color1 = parameters.Cells(1).molecule_type(t1).color;
        
        %%% spring line
        mol1_sy = linspace(h1,0,10);
        mol1_sx = K01/a^2*k1*(mol1_sy - max(mol1_sy)).^2; % !!!!!(mol1_sx0/max(mol1_sx0))
        
        %%% potential well line
        mol1_ux  = ux*U1;
%         mol1_uy  = uy*w1  + h1;  
        mol1_uy  = uy;
        
        %%% plot spring line
        plot(mol1_sx,mol1_sy,'-','Color',color1,'LineWidth',3)
        
        %%% plot potential well line
        plot(mol1_ux,mol1_uy,'-','Color',color1,'LineWidth',3)
        
    end
    
    %%% PLL
    %%% well PLL
    PLL_ux   = ux*PLL_U;
    PLL_uy   = uy*PLL_bmax + PLL_bmax/2; %!!!!
%     PLL_bmax = PLL_bmax;

    %%% plot PLL
    if strcmp(Cell2_name,'Coverslip')
        if PLL_use
            plot(PLL_ux  ,PLL_uy+1 ,'-','Color',PLL_color,'LineWidth',2)
        end
    end
     
    %%% ticks and ticklables
    for z_ind = 10:10:70
        text(-7,z_ind,[num2str(z_ind),' -'],'FontSize',fs2)
    end
    for x_ind = [-20:10:50]
        text(x_ind,-5,[num2str(x_ind),' '],'FontSize',fs2,...
            'HorizontalAlignment','Center')
    end
    hold off

    axis([-30 60 mz2-20 mz1+20])
    set(gca,'color',0.8*[1 1 1]); % [0.85 0.85 0.85]
    
    title('Interactions','FontSize',fs4)
    xlabel('E (KT)','FontSize',fs4)
    ylabel('Z (nm)','FontSize',fs4)
    axis off
    
end % plot_interaction_properties = 1:1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% membrane height %%%%%%%%%%%%%%%%%%%
for plot_membrane_properties = 1:1
    pos3 = [rx*0.9 ry rw*0.95 rh];
    sp3 = subplot('Position',pos3);
    cla(sp3)
    size_x = parameters.global.array_size_x;
    size_y = parameters.global.array_size_y;
    
    Z0 = parameters.Cells(1).membrane.Z0;
        
    Z1 = simulation_data.Cells(1).Z;
    Z2 = simulation_data.Cells(2).Z;

    DZ = Z1 - Z2;

    h3 = pcolor(DZ');
    colormap(gray);
    set(h3,'EdgeColor','none')
    cb4 = colorbar;
    title(cb4,'Z (nm)','FontSize',fs3);
    caxis([0 Z0])

    axis equal
    axis([0 size_x 0 size_y])
    title('Inter membranes distance','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% initial conditions %%%%%%%%%%%%%%%%
for plot_initial_conditions = 1:1
    pos4 = [rx+dx ry rw*0.95 rh];
    sp4 = subplot('Position',pos4);
    cla(sp4)
    colorbar
    caxis([0 Z0])
    
    %%% plot DZ
    h3 = pcolor(DZ');
    colormap(gray);
    set(h3,'EdgeColor','none')
    cb3 = colorbar;
    title(cb3,'Z (nm)','FontSize',fs3);
    caxis([0 Z0])
    hold on
    ms = 5;
    
    %%% PLL %%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(parameters.Cells(2).cellname,'Coverslip'); 
        if PLL_use
            set(gca,'Color',PLL_color)
            alpha (0.5)
        end
    end
    
    %%% adhesivesurface %%%%%%%%%%%%%%%
    if parameters.global.adhesive_surface.use
        try
            %%% molecules locations
            [X0,Y0] = find(parameters.global.adhesive_surface.array);
            %%% plot locations
            plot(X0,Y0,'.','MarkerSize',ms,'Color',[1 1 0])
    
        catch

        end
    end
    %%% Cells(2)
    for t2 = 1:n_types2
        %%% molecules locations
        [X2,Y2] = find(simulation_data.Cells(2).LOC == t2);
        %%% color
        color2  = parameters.Cells(2).molecule_type(t2).color;
        %%% plot locations
        plot(X2,Y2,'.','MarkerSize',ms,'Color',color2)
    end
    %%% Cells(1)
    for t1 = 1:n_types1
        %%% molecules locations
        [X1,Y1] = find(simulation_data.Cells(1).LOC == t1);
        %%% color
        color1    = parameters.Cells(1).molecule_type(t1).color;
        %%% plot locations
        plot(X1,Y1,'.','MarkerSize',ms,'Color',color1)
    end
    
    hold off
    axis equal
    axis([0 size_x 0 size_y])
    
    title('Initial locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
end

end