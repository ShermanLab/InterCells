function [data1,data2,gr] = ui_pair_correlation_function(results_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load('C:\Users\Owner\Documents\MATLAB\Weikl_Lipowsky\small_patches\Interface_simulation5\Results\results_20180730200944\RESULTS_OF_RUNS.mat')
% results_data = RESULTS_OF_RUNS;


gr = [];

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;
a        = parameters.global.pixel_size;
max_R    = parameters.analyses.max_R;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 5;
gapy = 5;

px   = x0+100;
py   = y0+100;
pw   = 800; %650;
ph   = 800; 

pbx  = 3;
pby  = 3;
pbw  = 95;
pbh  = 30;

%%% figures locations %%%%%%%%%%%%%%%%%
ox1 = 0.08; % 0.50;
ox2 = 0.56; % 0.50;
oy1 = 0.08; % 0.50;
oy2 = 0.44;
rw  = 0.36;
rh  = 0.36;

pos1 = [ox1 oy1 rw rh];
pos2 = [ox2 oy1 rw rh];

%%% get molecules names %%%%%%%%%%%%%%%
molecules_names = cell(1);
max_gr = 10;

nn = 0;
for cn = 1:2 % cell number
    types_n = size(parameters.Cells(cn).molecule_type(:),1);
    for tn = 1:types_n % type number
        nn = nn + 1;
        molecule_name = parameters.Cells(cn).molecule_type(tn).name;
        molecules_names{nn,1} = molecule_name;
    end
end

%%% get times names %%%%%%%%%%%%%%%%%%%
times_names = cell(1);
n_times = size(results_data,1);

for tt = 1:n_times % time
    times_names{tt,1} = num2str(tt-1);
end

data1.t = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(21);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Pair correlation function','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Pair correlation function',...
    'FontSize',20,...
    'Position',[pw*0.33 ph-50 300 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',[ox1 645/ph 270/pw 75/ph]);

%%% popup1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Data1',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx pbh+gapy pbw pbh]);

popup1 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'FontSize',fs2,...
    'Value',1,...
    'Position',[gapx gapy pbw pbh],...
    'Callback',@get_molecule1);    

%%% @get_molecule1 %%%%%%%%%%%%%%%%%%%%
function get_molecule1(varargin)
    val1 = get(popup1,'Value');
    switch val1
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data1.cn = cn;
    data1.tn = tn;
    
    uiresume
    
end % @get_molecule1

%%% initialize popup1 %%%%%%%%%%%%%%%%%
function initial_molecule1(varargin)
    val1 = 1; %get(popup1,'Value');
    switch val1
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data1.cn = cn;
    data1.tn = tn;
    
    uiresume
    
end % @inintial_molecule1
initial_molecule1;

%%% popup2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Data2',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[pbw+2*gapx pbh+gapy pbw pbh]);

popup2 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'Value',3,...
    'FontSize',fs2,...
    'Position', [pbw+2*gapx gapy pbw pbh],...
    'Callback', @get_molecule2);    

%%% @get_molecule2 %%%%%%%%%%%%%%%%%%%%
function get_molecule2(varargin)
    val2 = get(popup2,'Value');
    switch val2
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data2.cn = cn;
    data2.tn = tn;

    uiresume
    
end % @molecule2

%%% @initial_molecule2 %%%%%%%%%%%%%%%%
function initial_molecule2(varargin)
    val2 = 3; %get(popup2,'Value');
    switch val2
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data2.cn = cn;
    data2.tn = tn;

    uiresume
    
end % @molecule2
initial_molecule2;

%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% popup3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Time',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[2*(pbw+gapx)+gapx pbh+gapy 0.6*pbw pbh]);

popup3 = uicontrol(panel1,'Style', 'popup',...
    'String', times_names,...
    'FontSize',fs2,...
    'Position', [2*(pbw+gapx)+gapx gapy 0.6*pbw pbh],...
    'Callback', '[]'); % @get_time

%%% get_times %%%%%%%%%%%%%%%%%%%%%%%%%
function get_time(varargin)
    data1.t = get(popup3,'Value');
end

%%% plot_data %%%%%%%%%%%%%%%%%%%%%%%%%
function plot_data(varargin)
   
    sp1 = subplot(2,2,3); 
    set(gca,'position',pos1)
    cla
    %%% get time
    data1.t = get(popup3,'Value');
	
    %%% array1
    data1.array = results_data{data1.t}.Cells(data1.cn).LOC == data1.tn;
    data1.color = parameters.Cells(data1.cn).molecule_type(data1.tn).color;
    data1.name  = parameters.Cells(data1.cn).molecule_type(data1.tn).name;
    [X1,Y1] = find(data1.array);

    %%% array2
    data2.array = results_data{data1.t}.Cells(data2.cn).LOC == data2.tn;
    data2.color = parameters.Cells(data2.cn).molecule_type(data2.tn).color;
    data2.name  = parameters.Cells(data2.cn).molecule_type(data2.tn).name;
    [X2,Y2] = find(data2.array);
    
    %%% plot
    %%% get array size
    size_x  = size(data1.array,1);
    size_y  = size(data1.array,2);
    
    plot(X1,Y1,'.','Color',data1.color)
    hold on
    plot(X2,Y2,'.','Color',data2.color)
    hold off
    axis equal
    axis([0 size_x 0 size_y])
    
    text(size_x*0.02,size_y*0.95,['t = ' ,num2str(data1.t-1),' sec'],...
        'FontWeight','Bold','BackGround','w')
    text(size_x*0.02,size_y*0.88,data1.name,'Color',data1.color,...
        'FontWeight','Bold','BackGround','w')
    text(size_x*0.02,size_y*0.81,data2.name,'Color',data2.color,...
        'FontWeight','Bold','BackGround','w')
    
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
    
  
end

%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(p,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[ox1*pw 610 pbw pbh],...
    'Callback',@plot_data); 

%%% PCF_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
PCF_pb = uicontrol(p,'Style','pushbutton',...
    'String','Calculate g(r)',...
    'FontSize',fs2,...
    'Position',[ox1*pw+pbw+gapx 610 pbw pbh],...
    'Callback',@calculate_pcf); 

%%% @calculate_pcf %%%%%%%%%%%%%%%%%%%%
function calculate_pcf(varargin)
    
    array1 = data1.array;
    array2 = data2.array;
    
    gr = gr_arrays(array1,array2,parameters);
    
    subplot(2,2,4)
    set(gca,'position',pos2)
    
    h1 = plot(0:max_R,gr,'.-');
    axis([0 max_R 0 max_gr])
    axis square
    
    title('Pair correlation function','FontSize',fs4)
    set(gca,'XTick',0:10:max_R)
    set(gca,'YTick',0:1:max_gr)
    set(gca,'XTickLabel',a*[0:10:max_R])
    set(gca,'YTickLabel',0:1:max_gr)

    xlabel('r (nm)','FontSize',fs3)
    ylabel('g(r)','FontSize',fs3)
    
    legend([h1],{[data1.name,'-',data2.name]})
    
    uiresume
end % @calculate_pcf

%%% Save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Save_pb = uicontrol(p,'Style','pushbutton',...
    'String','Save',...
    'FontSize',fs1,...
    'Position',[ox1*pw oy2*ph+50 0.6*pbw pbh],...
    'Callback',@Save_callback); 

%%% @Save_callback %%%%%%%%%%%%%%%%%%%%
function Save_callback(varargin)
    
    results.data1 = data1;
    results.data2 = data2;
    results.gr    = gr;
    results.t     = data1.t-1;
    
    save('results_gr.mat','results') 
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(p,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[ox1*pw+60 oy2*ph+50 0.6*pbw pbh],...
    'Callback',@Close_callback); 

%%% initialize subplots %%%%%%%%%%%%%%%
%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(gca,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% subplot2 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp2  = subplot(2,2,4); 
set(gca,'position',pos2)

title('g(r)','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('r (nm)','FontSize',fs3)
ylabel('g(r)','FontSize',fs3)
box on
axis square

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
% align(Save_pb,'Fixed',3,'Fixed',3);
% align([Save_pb Close_pb],'Fixed',3,'Bottom');
% uiwait

end




