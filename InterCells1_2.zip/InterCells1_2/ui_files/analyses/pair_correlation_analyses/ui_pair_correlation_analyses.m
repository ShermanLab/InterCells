function [data1,data2,gr] = ui_pair_correlation_analyses(results_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;
a        = parameters.global.pixel_size;
max_R    = parameters.analyses.max_R;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% gr    = [];
% % data1 = [];
% data2 = [];

% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 5;
gapy = 5;

px   = x0+100;
py   = y0+100;
pw   = 800; %650;
ph   = 800; 

pbx  = 3;
pby  = 3;
pbw  = 95;
pbh  = 30;

%%% figures locations %%%%%%%%%%%%%%%%%
ox1 = 0.08; % 0.50;
ox2 = 0.56; % 0.50;
oy1 = 0.08; % 0.50;
oy2 = 0.54;
rw  = 0.36;
rh  = 0.36;

pos1 = [ox1 oy1 rw rh];
pos2 = [ox2 oy2 rw rh];
pos3 = [ox2 oy1 rw rh];

max_gr = 10;
N_samples = 19;
%%% get molecules names %%%%%%%%%%%%%%%
molecules_names = cell(1);

nn = 0;
for cn = 1:2 % cell number
    types_n = size(parameters.Cells(cn).molecule_type(:),1);
    for tn = 1:types_n % type number
        nn = nn + 1;
        molecule_name = parameters.Cells(cn).molecule_type(tn).name;
        molecules_names{nn,1} = molecule_name;
    end
end

%%% get times names %%%%%%%%%%%%%%%%%%%
times_names = cell(1);
n_times = size(results_data,1);

for tt = 1:n_times % time
    times_names{tt,1} = num2str(tt-1);
end

data1.t = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(22);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Pair correlation analyses','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Pair correlation analyses',...
    'FontSize',20,...
    'Position',[pw*0.32 ph-50 300 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',[ox1 645/ph 270/pw 75/ph]);

%%% popup1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Data1',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx pbh+gapy pbw pbh]);

popup1 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'FontSize',fs2,...
    'Position',[gapx gapy pbw pbh],...
    'Callback',@get_molecule1);    

%%% @molecule1 %%%%%%%%%%%%%%%%%%%%%%%%
function get_molecule1(varargin)
    val1 = get(popup1,'Value');
    switch val1
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data1.cn = cn;
    data1.tn = tn;
    
    uiresume
    
end % @molecule1

%%% popup2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Data2',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[pbw+2*gapx pbh+gapy pbw pbh]);

popup2 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'FontSize',fs2,...
    'Position', [pbw+2*gapx gapy pbw pbh],...
    'Callback', @get_molecule2);    

%%% @molecule2 %%%%%%%%%%%%%%%%%%%%%%%%
function get_molecule2(varargin)
    val2 = get(popup2,'Value');
    switch val2
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data2.cn = cn;
    data2.tn = tn;

    uiresume
    
end % @molecule2

%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% popup3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Time',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[2*(pbw+gapx)+gapx pbh+gapy 0.6*pbw pbh]);

popup3 = uicontrol(panel1,'Style', 'popup',...
    'String', times_names,...
    'FontSize',fs2,...
    'Position', [2*(pbw+gapx)+gapx gapy 0.6*pbw pbh],...
    'Callback', '[]'); % @get_time

%%% get_times %%%%%%%%%%%%%%%%%%%%%%%%%
function get_time(varargin)
    data1.t = get(popup3,'Value');
end

%%% plot_data %%%%%%%%%%%%%%%%%%%%%%%%%
function plot_data(varargin)
   
    sp1 = subplot(2,2,3); 
    set(gca,'position',pos1)
    cla
    %%% get time
    data1.t = get(popup3,'Value');
	
    %%% array1
    data1.array = results_data{data1.t}.Cells(data1.cn).LOC == data1.tn;
    data1.color = parameters.Cells(data1.cn).molecule_type(data1.tn).color;
    data1.name  = parameters.Cells(data1.cn).molecule_type(data1.tn).name;
    [X1,Y1] = find(data1.array);

    %%% array2
    data2.array = results_data{data1.t}.Cells(cn).LOC == tn;
    data2.color = parameters.Cells(cn).molecule_type(tn).color;
    data2.name  = parameters.Cells(cn).molecule_type(tn).name;
    [X2,Y2] = find(data2.array);
        
    %%% plot
    %%% get array size
    size_x  = size(data1.array,1);
    size_y  = size(data1.array,2);
    
    plot(X1,Y1,'.','Color',data1.color)
    hold on
    plot(X2,Y2,'.','Color',data2.color)
    hold off
    axis equal
    axis([0 size_x 0 size_y])
    
    text(size_x*0.02,size_y*0.95,['t = ' ,num2str(data1.t-1),' sec'],...
        'FontWeight','Bold','BackGround','w')
    text(size_x*0.02,size_y*0.88,data1.name,'Color',data1.color,...
        'FontWeight','Bold','BackGround','w')
    text(size_x*0.02,size_y*0.81,data2.name,'Color',data2.color,...
        'FontWeight','Bold','BackGround','w')
    
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
    
end

%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(p,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[ox1*pw 610 pbw*1.5 pbh],...
    'Callback',@plot_data); 

%%% Clustering_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
UVPCF_pb = uicontrol(p,'Style','pushbutton',...
    'String','Calculate Univar PCF',...
    'FontSize',fs2,...
    'Position',[ox1*pw 610-1*(pbh+gapy) pbw*1.5 pbh],...
    'Callback',@calculate_UVPCF); 

%%% @calculate_UVPCF %%%%%%%%%%%%%
function calculate_UVPCF(varargin)
    
    N_samples = 19;
    
    array1 = data1.array;
    array2 = data2.array;
    
    gr01 = gr_arrays(array1,array1,parameters);
    gr02 = gr_arrays(array2,array2,parameters);
    
    [gr1_min,gr1_max] = complete_spatial_randomnes(array1,parameters,N_samples);
    [gr2_min,gr2_max] = complete_spatial_randomnes(array2,parameters,N_samples);

    subplot(2,2,2)
    cla
    set(gca,'position',pos2)
    
    
    h1 = plot(1:max_R,gr01(2:end)   ,'-','Color',data1.color,'LineWidth',2);
    hold on
    h2 = plot(1:max_R,gr02(2:end)   ,'-','Color',data2.color,'LineWidth',2);
    h3 = plot(1:max_R,gr1_min(2:end),':','Color',data1.color,'LineWidth',1.5)
    h4 = plot(1:max_R,gr1_max(2:end),':','Color',data1.color,'LineWidth',1.5)
    h5 = plot(1:max_R,gr2_min(2:end),':','Color',data2.color,'LineWidth',1.5)
    h6 = plot(1:max_R,gr2_max(2:end),':','Color',data2.color,'LineWidth',1.5)
    hold off
    
    axis([0 max_R 0 max_gr])
    axis square
    
    title('Univariate PCF','FontSize',fs4)
    set(gca,'XTick',0:10:max_R)
    set(gca,'YTick',0:1:max_gr)
    set(gca,'XTickLabel',a*[0:10:max_R])
    set(gca,'YTickLabel',0:1:max_gr)

    xlabel('r (nm)','FontSize',fs3)
    ylabel('g(r)','FontSize',fs3)
        
    legend([h1,h2,h3,h5],...
        {[data1.name,' PCF'],[data2.name,' PCF'],...
         [data1.name,' CSR'],[data2.name,' CSR']})
     
     
    %%% data out %%%%%%%%%%%%%%%%%%%%%% 
    data1.gr = gr01;
    data2.gr = gr02;
    
    data1.confidence_min = gr1_min;
    data1.confidence_max = gr1_max;
    
    data2.confidence_min = gr2_min;
    data2.confidence_max = gr2_max;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    uiresume
end % @calculate_clustering


%%% BVPCF_pb %%%%%%%%%%%%%%%%%%%%%%%%%%
BVPCF_pb = uicontrol(p,'Style','pushbutton',...
    'String','Calculate bivar PCF',...
    'FontSize',fs2,...
    'Position',[ox1*pw 610-2*(pbh+gapy) pbw*1.5 pbh],...
    'Callback',@calculate_BVPCF); 

%%% @calculate_BVPCF %%%%%%%%%%%%%%%%%%
function calculate_BVPCF(varargin)
    
    N_samples = 19;
    
    array1 = data1.array;
    array2 = data2.array;
    
    gr0 = gr_arrays(array1,array2,parameters);
    
    [gr_min,gr_max] = randomlabeling(array1,array2,parameters,N_samples);

    subplot(2,2,4)
    cla
    set(gca,'position',pos3)
    h1 = plot(1:max_R,gr0(2:end)   ,'-','Color','b','LineWidth',2);
    hold on
    h2 = plot(1:max_R,gr_min(2:end),':','Color','b','LineWidth',1.5);
    h3 = plot(1:max_R,gr_max(2:end),':','Color','b','LineWidth',1.5);
    hold off
    
    axis([0 max_R 0 max_gr])
    axis square
    
    title('Bivariate PCF','FontSize',fs4)
    set(gca,'XTick',0:10:max_R)
    set(gca,'YTick',0:1:max_gr)
    set(gca,'XTickLabel',a*[0:10:max_R])
    set(gca,'YTickLabel',0:1:max_gr)

    xlabel('r (nm)','FontSize',fs3)
    ylabel('g(r)','FontSize',fs3)
    
    legend([h1,h2],...
        {[data1.name,'-',data2.name,' PCF'],'Random labeling'})
    
    %%% data out %%%%%%%%%%%%%%%%%%%%%%
    data1.gr12 = gr0;
    data2.gr21 = gr0;
    
    data1.RL_min = gr_min;
    data1.RL_max = gr_max;
    
    data2.RL_min = gr_min;
    data2.RL_max = gr_max;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    uiresume
end % @calculate_BVPCF

%%% Save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Save_pb = uicontrol(p,'Style','pushbutton',...
    'String','Save',...
    'FontSize',fs1,...
    'Position',[ox1*pw oy2*ph 0.6*pbw pbh],...
    'Callback',@Save_callback); 

%%% @Save_callback %%%%%%%%%%%%%%%%%%%%
function Save_callback(varargin)
    
    results.data1 = data1;
    results.data2 = data2;
    results.t     = data1.t-1;
    
    save('results_pfa.mat','results') 
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(p,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[ox1*pw+gapx oy2*ph 0.6*pbw pbh],...
    'Callback',@Close); 

%%% @Close %%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Close(varargin)
    close(21)
end


%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(gca,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% subplot2 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp2  = subplot(2,2,2); 
set(gca,'position',pos2)

title('Univariate PCF','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('r (nm)','FontSize',fs3)
ylabel('g(r)','FontSize',fs3)
box on
axis square

%%% subplot3 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp3  = subplot(2,2,4); 
set(gca,'position',pos3)

title('Bivariate PCF','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('r (nm)','FontSize',fs3)
ylabel('g(r)','FontSize',fs3)
box on
axis square

%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
% align(Save_pb,'Fixed',3,'Fixed',3);
align([Save_pb Close_pb],'Fixed',3,'Bottom');
% uiwait

end




