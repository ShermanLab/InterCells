function [data1,data2] = ui_bivariate_pair_correlation_analyses(results_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gr = [];

a        = parameters.global.pixel_size;
max_R    = parameters.analyses.max_R;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 3;
gapy = 3;

px   = parameters.ui.results_panels.x0;
py   = parameters.ui.results_panels.y0;
pw   = parameters.ui.results_panels.w0;
ph   = parameters.ui.results_panels.h0;

spx0 = parameters.ui.results_subplots.x0;
spy0 = parameters.ui.results_subplots.y0;
spw0 = parameters.ui.results_subplots.w0;
sph0 = parameters.ui.results_subplots.h0;

pbw  = 95;
pbh  = 30;

%%% figures locations %%%%%%%%%%%%%%%%%
ox1 = spx0/pw;
ox2 = spx0/pw + 0.45; 
oy1 = spy0/ph; 
oy2 = spy0/ph + 0.46;
rw  = spw0/pw;
rh  = sph0/ph;

pos1 = [ox1 oy1 rw rh];
pos2 = [ox2 oy1 rw rh];
pos3 = [ox2 oy2 rw rh];

%%% get molecules names %%%%%%%%%%%%%%%
molecules_names = cell(1);
max_gr = 10;

nn = 0;
for cn = 1:2 % cell number
    types_n = size(parameters.Cells(cn).molecule_type(:),1);
    for tn = 1:types_n % type number
        nn = nn + 1;
        molecule_name = parameters.Cells(cn).molecule_type(tn).name;
        molecules_names{nn,1} = molecule_name;
    end
end

%%% get times names %%%%%%%%%%%%%%%%%%%
times_names = cell(1);
n_times = size(results_data,1);

for tt = 1:n_times % time
    times_names{tt,1} = num2str(tt-1);
end

data1.t = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(21);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Bivariate pair correlation analyses','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Bivariate pair correlation analyses',...
    'FontSize',20,...
    'Position',[pw*0.2 ph-50 500 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',[ox1 oy2 rw rh]);

%%% popup1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Data1',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx sph0-(pbh+gapy) pbw pbh]);

popup1 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'FontSize',fs2,...
    'Value',1,...
    'Position',[gapx sph0-(2*pbh+gapy) pbw pbh],...
    'Callback',@get_molecule1);    

%%% @get_molecule1 %%%%%%%%%%%%%%%%%%%%
function get_molecule1(varargin)
    val1 = get(popup1,'Value');
    switch val1
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data1.cn = cn;
    data1.tn = tn;
    
    uiresume
    
end % @get_molecule1

%%% initialize popup1 %%%%%%%%%%%%%%%%%
function initial_molecule1(varargin)
    val1 = 1; %get(popup1,'Value');
    switch val1
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data1.cn = cn;
    data1.tn = tn;
    
    uiresume
    
end % @inintial_molecule1
initial_molecule1;

%%% popup2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Data2',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[pbw+2*gapx sph0-(pbh+gapy) pbw pbh]);

popup2 = uicontrol(panel1,'Style', 'popup',...
    'String', molecules_names,...
    'Value',1,...
    'FontSize',fs2,...
    'Position', [pbw+2*gapx sph0-(2*pbh+gapy) pbw pbh],...
    'Callback', @get_molecule2);    

%%% @get_molecule2 %%%%%%%%%%%%%%%%%%%%
function get_molecule2(varargin)
    val2 = get(popup2,'Value');
    switch val2
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data2.cn = cn;
    data2.tn = tn;

    uiresume
    
end % @molecule2

%%% @initial_molecule2 %%%%%%%%%%%%%%%%
function initial_molecule2(varargin)
    val2 = 1; %get(popup2,'Value');
    switch val2
        case 1
            cn = 1; tn = 1;
        case 2
            cn = 1; tn = 2;
        case 3
            cn = 1; tn = 3;
        case 4
            cn = 2; tn = 1;
        case 5
            cn = 2; tn = 2;
        case 6
            cn = 2; tn = 3;
    end
    
    data2.cn = cn;
    data2.tn = tn;

    uiresume
    
end % @molecule2
initial_molecule2;

%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Time',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[2*pbw+3*gapx sph0-(pbh+gapy) 0.6*pbw pbh]);

%%% Slider %%%%%%%%%%%%%%%%%%%%%%%%%%%%
time_slider = uicontrol(panel1,'Style','slider',...
    'Position',[spw0-25 gapy 20 sph0-2*gapy],...
    'min',0,...
    'max',100,...
    'sliderstep',[0.01,0.02],...
    'Callback',@slider_callback); 

%%% @slider_callback %%%%%%%%%%%%%%%%%%
function slider_callback(varargin)
    t_slider = get(time_slider,'Value');
    plot_data;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% time2slider %%%%%%%%%%%%%%%%%%%%%%%
time2slider = uicontrol(panel1,'Style','edit',...
    'String',num2str(get(time_slider,'Value')),...
    'FontSize',fs3,...
    'Position',[2*pbw+3*gapx sph0-(2*pbh) 0.6*pbw 25],...
    'Callback',@t2slider_callback); 

%%% @t2slider_callback %%%%%%%%%%%%%%%%
function t2slider_callback(varargin)
    slider_t = get(time2slider,'String');
    set(time_slider,'Value',str2num(slider_t));
    plot_data
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plot_data(varargin)

    t = round(get(time_slider,'Value')) + 1;   
    
    sp1 = subplot(2,2,3); 
    set(gca,'position',pos1)
    cla

    %%% array1
    data1.array = results_data{t}.Cells(data1.cn).LOC == data1.tn;
    data1.color = parameters.Cells(data1.cn).molecule_type(data1.tn).color;
    data1.name  = parameters.Cells(data1.cn).molecule_type(data1.tn).name;
    [X1,Y1] = find(data1.array);

    %%% array2
    data2.array = results_data{t}.Cells(data2.cn).LOC == data2.tn;
    data2.color = parameters.Cells(data2.cn).molecule_type(data2.tn).color;
    data2.name  = parameters.Cells(data2.cn).molecule_type(data2.tn).name;
    [X2,Y2] = find(data2.array);
    
    %%% plot
    %%% get array size
    size_x  = size(data1.array,1);
    size_y  = size(data1.array,2);
    
    plot(X1,Y1,'.','Color',data1.color)
    hold on
    plot(X2,Y2,'.','Color',data2.color)
    hold off
    axis equal
    axis([0 size_x 0 size_y])
    
    text(size_x*0.02,size_y*0.95,['t = ' ,num2str(t-1),' sec'],...
        'FontWeight','Bold','BackGround','w')
    text(size_x*0.02,size_y*0.88,data1.name,'Color',data1.color,...
        'FontWeight','Bold','BackGround','w')
    text(size_x*0.02,size_y*0.81,data2.name,'Color',data2.color,...
        'FontWeight','Bold','BackGround','w')
    
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
    
    
    %%% plot membrane %%%%%%%%%%%%%%%%%
%     if get(cb_membrane,'Value') == 1
%         
%         Z0 = parameters.Cells(1).membrane.Z0;
%         
%         Z1 = results_data{t}.Cells(1).Z;
%         Z2 = results_data{t}.Cells(2).Z;
% 
%         DZ = Z1 - Z2;
%         hold on
%         h3 = pcolor(DZ');
%         hold off
%         
%         axis equal
%         axis tight
%         box on
%         
%         colormap(gray);
%         set(h3,'EdgeColor','none')
%         h_colorbar = colorbar;
%         title(h_colorbar,'Z (nm)','FontSize',fs3);
%         caxis([0 Z0])
%         
%         title(['t = ',num2str(t-1)],'FontSize',fs4)
%         set(gca,'XTick',0:50:size(Z1,1))
%         set(gca,'YTick',0:50:size(Z1,2))
%         set(gca,'XTickLabel',a*[0:50:size(Z1,1)])
%         set(gca,'YTickLabel',a*[0:50:size(Z1,2)])
% 
%         xlabel('X (nm)','FontSize',fs3)
%         ylabel('Y (nm)','FontSize',fs3)         
%         
%         drawnow
%         
%     else
%         colormap(gray);
%         h_colorbar = colorbar;
% %         caxis([0 Z0])
%         title(h_colorbar,'Z (nm)','FontSize',fs3);
%         drawnow
%     end   
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[gapx sph0-3*(pbh+gapy) 2*pbw pbh],...
    'Callback',@plot_data); 



%%% BVPCF_pb %%%%%%%%%%%%%%%%%%%%%%%%%%
BVPCF_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Calculate Bivariate PCF',...
    'FontSize',fs2,...
    'Position',[gapx sph0-4*(pbh+gapy) pbw*2 pbh],...
    'Callback',@calculate_BVPCF); 

%%% @calculate_BVPCF %%%%%%%%%%%%%%%%%%
function calculate_BVPCF(varargin)
    
    N_samples = 19;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    array1 = data1.array;
    array2 = data2.array;
    
    %%% g11, g22 %%%%%%%%%%%%%%%%%%%%%%
    %%% complete_spatial_randomnes (univariate)
    [gr1_csr_min,gr1_csr_max] = complete_spatial_randomnes(array1,parameters,N_samples);
    [gr2_csr_min,gr2_csr_max] = complete_spatial_randomnes(array2,parameters,N_samples);

    %%% bivariate PCF %%%%%%%%%%%%%%%%%
    gr12 = gr_arrays(array1,array2,parameters);
    
    %%% random labeling (bivariate) %%%
    [gr_RL_min,gr_RL_max] = randomlabeling(array1,array2,parameters,N_samples);

    %%% plot bivariate PCF %%%%%%%%%%%%
    subplot(2,2,4)
    cla
    set(gca,'position',pos2)
    h1 = plot(1:max_R,gr12(2:end)   ,'-','Color','k','LineWidth',2);
    hold on
    h2 = plot(1:max_R,gr1_csr_min(2:end),':','Color',data1.color,'LineWidth',1.5)
    h3 = plot(1:max_R,gr1_csr_max(2:end),':','Color',data1.color,'LineWidth',1.5)
    h4 = plot(1:max_R,gr2_csr_min(2:end),':','Color',data2.color,'LineWidth',1.5)
    h5 = plot(1:max_R,gr2_csr_max(2:end),':','Color',data2.color,'LineWidth',1.5)
    h6 = plot(1:max_R,gr_RL_min(2:end)  ,':','Color','k','LineWidth',1.5);
    h7 = plot(1:max_R,gr_RL_max(2:end)  ,':','Color','k','LineWidth',1.5);
    h8 = plot([0,max_R],[1 1]           ,'-','Color','k','LineWidth',0.5);

    
    hold off
    
    axis([0 max_R 0 max_gr])
    axis square
    
    title('Bivariate PCF','FontSize',fs4)
    set(gca,'XTick',0:10:max_R)
    set(gca,'YTick',0:1:max_gr)
    set(gca,'XTickLabel',a*[0:10:max_R])
    set(gca,'YTickLabel',0:1:max_gr)

    xlabel('r (nm)','FontSize',fs3)
    ylabel('g(r)','FontSize',fs3)
        
%     legend([h1,h2,h3,h5],...
%         {[data1.name,' PCF'],[data2.name,' PCF'],...
%          [data1.name,' CSR'],[data2.name,' CSR']})
     
     
%     pause
    %%% plot Extent Of Mixing %%%%%%%%%
    
    [eom_gr12,eom_min,eom_max,eom_ones] = bivar2eom(gr12,gr_RL_min,gr_RL_max);

    subplot(2,2,2)
    cla
    set(gca,'position',pos3)
    h1 = plot(1:max_R,eom_gr12(2:end),'.-','Color','k','LineWidth',2);
    hold on
%     h2 = plot(1:max_R,eom_min(2:end) ,':','Color','k','LineWidth',1.5);
%     h3 = plot(1:max_R,eom_max(2:end) ,':','Color','k','LineWidth',1.5);
%     h4 = plot(1:max_R,eom_ones(2:end),'-','Color','k','LineWidth',0.5);

    hold off
    xlim([0 max_R])
    ylim([0 1])
%     axis([0 max_R 0 max_gr])
    axis square
    
    title('Extent Of Mixing','FontSize',fs4)
    set(gca,'XTick',0:10:max_R)
%     set(gca,'YTick',0:1:max_gr)
    set(gca,'XTickLabel',a*[0:10:max_R])
%     set(gca,'YTickLabel',0:1:max_gr)

    xlabel('r (nm)','FontSize',fs3)
    ylabel('EOM','FontSize',fs3)
    
%     legend([h1,h2],...
%         {[data1.name,'-',data2.name,' PCF'],'Random labeling'})
    
    
    
    %%% data out %%%%%%%%%%%%%%%%%%%%%%
    data1.gr12 = gr12;
    data2.gr21 = gr12;
    
    data1.RL_min = gr_RL_min;
    data1.RL_max = gr_RL_max;
    
    data2.RL_min = gr_RL_min;
    data2.RL_max = gr_RL_max;
    
%     data1.gr = gr01;
%     data2.gr = gr02;
    
    data1.confidence_min = gr1_csr_min;
    data1.confidence_max = gr1_csr_max;
    
    data2.confidence_min = gr2_csr_min;
    data2.confidence_max = gr2_csr_max;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    uiresume
end

%%% Save %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Save_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Save',...
    'FontSize',fs1,...
    'Position',[gapx gapy 0.6*pbw pbh],...
    'Callback',@Save_callback); 

%%% @Save_callback %%%%%%%%%%%%%%%%%%%%
function Save_callback(~,~)
    
%     results.data1 = data1;
%     results.data2 = data2;
%     results.gr    = gr;
%     results.t     = data1.t-1;
%     
%     save('results_gr.mat','results') 
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%
% Close_pb = uicontrol(p,'Style','pushbutton',...
%     'String','Close',...
%     'FontSize',fs1,...
%     'Position',[ox1*pw+gapx oy2*ph 0.6*pbw pbh],...
%     'Callback',@Close_callback); 

%%% initialize subplots %%%%%%%%%%%%%%%
%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
% sp1  = subplot(2,2,3); 
% set(gca,'position',pos1)
% 
% title('Molecules locations','FontSize',fs4)
% set(gca,'XTick',[])
% set(gca,'YTick',[])
% set(gca,'XTickLabel',[])
% set(gca,'YTickLabel',[])
% xlabel('X (nm)','FontSize',fs3)
% ylabel('Y (nm)','FontSize',fs3)
% box on
% axis square
% 
% %%% subplot2 %%%%%%%%%%%%%%%%%%%%%%%%%%
% sp2  = subplot(2,2,4); 
% set(gca,'position',pos2)
% 
% title('Mutual information','FontSize',fs4)
% set(gca,'XTick',[])
% set(gca,'YTick',[])
% set(gca,'XTickLabel',[])
% set(gca,'YTickLabel',[])
% 
% xlabel('Entropy','FontSize',fs3)
% ylabel('t (sec)','FontSize',fs3)
% box on
% axis square


%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(gca,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

%%% subplot2 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp2  = subplot(2,2,2); 
set(gca,'position',pos3)

title('Extent Of Mixing','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('r (nm)','FontSize',fs3)
ylabel('g(r)','FontSize',fs3)
box on
axis square

%%% subplot3 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp3  = subplot(2,2,4); 
set(gca,'position',pos2)

title('Bivariate PCF','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])

xlabel('r (nm)','FontSize',fs3)
ylabel('g(r)','FontSize',fs3)
box on
axis square




%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
% align(Save_pb,'Fixed',3,'Fixed',3);
% align([Save_pb Close_pb],'Fixed',3,'Bottom');
% uiwait

end




