function ui_make_images(results_data,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;
a  = parameters.global.pixel_size;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 5;
gapy = 5;

px   = x0+100;
py   = y0+100;
pw   = 500; %650;
ph   = 800; 

pbx  = 3;
pby  = 3;
pbw  = 95;
pbh  = 30;
cbh  = 25;

%%% figures locations %%%%%%%%%%%%%%%%% 
ox1 = 0.12; % 0.50;
oy1 = 0.05; % 0.50;
oy2 = 0.63;
rw1 = 0.75;
rw2 = 0.85;
rh1 = 0.55; %0.36
rh2 = 0.30;

pos0 = [ox1 oy2 rw1 rh2];
pos1 = [ox1 oy1 rw2 rh1];

%%% get molecules names %%%%%%%%%%%%%%%
% types_n1 = size(parameters.Cells(1).molecule_type(:),1);
% types_n2 = size(parameters.Cells(2).molecule_type(:),1);

molecules_names  = cell(2,3);
molecules_colors = cell(2,3);


for cn = 1:2 % cell number
    types_n = size(parameters.Cells(cn).molecule_type(:),1);
    for tn = 1:types_n % type number
        
        %%% names
        molecules_name = parameters.Cells(cn).molecule_type(tn).name;
        molecules_names{cn,tn} = molecules_name;
        
        %%% colors
        molecule_color = parameters.Cells(cn).molecule_type(tn).color;
        molecules_colors{cn,tn} = molecule_color;
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(28);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Make movie','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Make movie',...
    'FontSize',20,...
    'Position',[pw*0.25 ph-50 300 50],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% panel for button groups %%%%%%%%%%%
panel1 = uipanel(p,...
    'FontSize',12,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',pos0); 

%%% Cell1 text %%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Cell1',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[gapx rh2*ph-(1*pbh+gapy) pbw pbh]);

%%% Cells(1) molecule_type(1) %%%%%%%%%
cb1_1 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{1,1},...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[gapx rh2*ph-(2*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{1,1},...
     'Callback',{@checkBoxCallback,1});

%%% Cells(1) molecule_type(2) %%%%%%%%% 
cb1_2 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{1,2},...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[gapx rh2*ph-(3*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{1,2},...
     'Callback',{@checkBoxCallback,2});

%%% Cells(1) molecule_type(3) %%%%%%%%%
cb1_3 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{1,3},...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[gapx rh2*ph-(4*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{1,3},...
     'Callback',{@checkBoxCallback,3});

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Cell2 text %%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Cell2',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[pbw+2*gapx rh2*ph-(1*pbh+gapy) pbw pbh]);

%%% Cells(2) molecule_type(1) %%%%%%%%%
cb2_1 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{2,1},...
     'FontSize',fs3,...
     'Value',0,...
     'Position',[pbw+2*gapx rh2*ph-(2*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{2,1},...
     'Callback',{@checkBoxCallback,4});

%%% Cells(2) molecule_type(2) %%%%%%%%% 
cb2_2 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{2,2},...
     'FontSize',fs3,...
     'Value',0,...
     'Position',[pbw+2*gapx rh2*ph-(3*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{2,2},...
     'Callback',{@checkBoxCallback,5});

%%% Cells(1) molecule_type(3) %%%%%%%%%
cb2_3 = uicontrol(panel1,'Style','checkbox',...
     'String',molecules_names{2,3},...
     'FontSize',fs3,...
     'Value',0,...
     'Position',[pbw+2*gapx rh2*ph-(4*pbh+gapy) pbw pbh],...
     'BackgroundColor',molecules_colors{2,3},...
     'Callback',{@checkBoxCallback,6});

%%% Membrane text %%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Membrane',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[2*(pbw+gapx)+gapx rh2*ph-(1*pbh+gapy) pbw pbh]);
 
%%% Membrane %%%%%%%%%%%%%%%%%%%%%%%%%%
cb_membrane_height = uicontrol(panel1,'Style','checkbox',...
     'String','Membrane',...
     'FontSize',fs3,...
     'Value',1,...
     'Position',[2*(pbw+gapx)+gapx rh2*ph-(2*pbh+gapy) pbw pbh],...
     'BackgroundColor',0.4*[1 1 1],...
     'Callback',{@MembraneCheckBox,7});
 
%%% assigning choises %%%%%%%%%%%%%%%%%
function checkBoxCallback(varargin)
    
    molecules_data.checkbox(1,1) = get(cb1_1,'Value');
    molecules_data.checkbox(1,2) = get(cb1_2,'Value');
    molecules_data.checkbox(1,3) = get(cb1_3,'Value');

    molecules_data.checkbox(2,1) = get(cb2_1,'Value');
    molecules_data.checkbox(2,2) = get(cb2_2,'Value');
    molecules_data.checkbox(2,3) = get(cb2_3,'Value');
    
end

%%% times %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% times text %%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(panel1,...
    'Style','text',...
    'String','Times',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[3*(pbw+gapx)+gapx 240-(pbh+gapy) 0.6*pbw pbh]);

%%% edit_times %%%%%%%%%%%%%%%%%%%%%%%%
edit_times = uicontrol(panel1,...
    'Style','edit',...
    'String','', ...
    'FontSize',fs3,...
    'Position',[3*(pbw+gapx)+gapx-1 175 60 30],...
    'Callback',@editCallback);

%%% @editCallback %%%%%%%%%%%%%%%%%%%%%
function editCallback(varargin)
    times_string = get(edit_times,'String');
    s1 = strrep(times_string,',',' ');
    molecules_data.times_vector = str2num(s1);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function MembraneCheckBox(varargin)
    Membrane_CheckBox = get(cb_membrane_height,'Value');
end
get(cb_membrane_height,'Value')
% Membrane_CheckBox
%%% plot_data %%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plot_data_pb %%%%%%%%%%%%%%%%%%%%%%
Plot_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Plot data',...
    'FontSize',fs2,...
    'Position',[gapx rh2*ph-(5*pbh+2*gapy) pbw pbh],...
    'Callback',@plot_data); 


images = cell(length(results_data),1);


function plot_data(varargin)
    
times = molecules_data.times_vector;
%%%
for m = 1:length(times)
    t = times(m)+1;
%%% start subplot %%%%
sp1 = subplot(2,2,3); 
set(gca,'position',pos1)
cla
%%%%%%%%%%%%%%%%%%%%%%   
    
	for cn = 2:-1:1
        for tn = 1:3
            if molecules_data.checkbox(cn,tn); 
                molecules_data.array = results_data{t}.Cells(cn).LOC == tn;
                molecules_data.color = parameters.Cells(cn).molecule_type(tn).color;
                molecules_data.name  = parameters.Cells(cn).molecule_type(tn).name;
                [X,Y] = find(molecules_data.array);
                
                size_x = size(molecules_data.array,1);
                size_y = size(molecules_data.array,2);
                
                %%% plot locations
                %%% get array size
                molecules_data.array = results_data{t}.Cells(cn).LOC == tn;
                                
                hold on
                plot(X,Y,'.','Color',molecules_data.color)
                hold off
                axis equal
                axis([0 size_x 0 size_y])
                box on
                
                title(['t = ',num2str(t)],'FontSize',fs4)
                set(gca,'XTick',0:50:size_x)
                set(gca,'YTick',0:50:size_y)
                set(gca,'XTickLabel',a*[0:50:size_x])
                set(gca,'YTickLabel',a*[0:50:size_y])

                xlabel('X (nm)','FontSize',fs3)
                ylabel('Y (nm)','FontSize',fs3)                
                
            end 
        end % tn
    end % cn
    
    %%% plot membrane %%%%%%%%%%%%%%%%%
    if get(cb_membrane_height,'Value') == 1
        Z0 = parameters.Cells(1).membrane.Z0;
        
        Z1 = results_data{t}.Cells(1).Z;
        Z2 = results_data{t}.Cells(2).Z;

        DZ = Z1 - Z2;
        hold on
        h3 = pcolor(DZ');
        hold off
        
        axis equal
        axis tight
        box on
        
        colormap(gray);
        set(h3,'EdgeColor','none')
        h_colorbar = colorbar;
        title(h_colorbar,'Z (nm)','FontSize',fs3);
        caxis([0 Z0])
        
        title(['t = ',num2str(t-1)],'FontSize',fs4)
        set(gca,'XTick',0:50:size(Z1,1))
        set(gca,'YTick',0:50:size(Z1,2))
        set(gca,'XTickLabel',a*[0:50:size(Z1,1)])
        set(gca,'YTickLabel',a*[0:50:size(Z1,2)])

        xlabel('X (nm)','FontSize',fs3)
        ylabel('Y (nm)','FontSize',fs3)         
        
        drawnow
        
    else
        colormap(gray);
        h_colorbar = colorbar;
%         caxis([0 Z0])
        title(h_colorbar,'Z (nm)','FontSize',fs3);
        drawnow
    end
    
    %%% get frames for video %%%%%%%%%%
    A = getframe(gca);
    images{t} = A.cdata;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end % for t

end

%%% Crop_data_pb %%%%%%%%%%%%%%%%%%%%%%
Crop_data_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Crop data',...
    'FontSize',fs2,...
    'Position',[gapx rh2*ph-(6*pbh+2*gapy) pbw pbh],...
    'Callback',@crop_data_callback); 

%%% @crop_data_callback %%%%%%%%%%%%%%%
function crop_data_callback(varargin)
   %%% make polygon %%%%%%%%%%%%%%%%%%
    %%% the initial list of points is empty 
    pol_x = [];
    pol_y = [];
    n = 0;
    
    %%% loop, picking up the points %%%
    disp('Left mouse button picks points')
    disp('Right mouse button picks last point')
    
    button = 1;
    hold on
    while button == 1
        [xi,yi,button] = ginput(1);
        plot(xi,yi,'ko')
        n = n+1;
        pol_x(n) =  xi;
        pol_y(n) =  yi;
        disp(n)
    end
    %%% if right click at n == 2 make rectangle.  
    if n == 2
       pol_x = [min(pol_x) max(pol_x) max(pol_x) min(pol_x)];
       pol_y = [min(pol_y) min(pol_y) max(pol_y) max(pol_y)];    
    end
    %%% make polygon
    polygon_x  = [pol_x, pol_x(1)];
    polygon_y  = [pol_y, pol_y(1)];
    
    %%% plot the polygon %%%%%%%%%%%%%%
    hold on
    plot(polygon_x,polygon_y,'-','Color','b');
    hold off
%     %%% make axis at polygon edges
%     axis([min(px) max(px) min(py) max(py)])

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Save movie %%%%%%%%%%%%%%%%%%%%%%%%
Save_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Save',...
    'FontSize',fs1,...
    'Position',[gapx gapy 0.6*pbw pbh],...
    'Callback',@Save_callback); 

%%% @Save_callback %%%%%%%%%%%%%%%%%%%%
function Save_callback(varargin)
    for t = molecules_data.times_vector
        %%% image save name
        image_savename = ['image_t',num2str(t)];
        
        %%% imwrite image(t) as *.png
        imwrite(images{t+1},[image_savename,'.png'])
    end
end

%%% @Close_pb %%%%%%%%%%%%%%%%%%%%%%%%%
Close_pb = uicontrol(panel1,'Style','pushbutton',...
    'String','Close',...
    'FontSize',fs1,...
    'Position',[pbw+gapx gapy 0.6*pbw pbh],...
    'Callback',@Close_callback); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
molecules_data.checkbox(1,1) = get(cb1_1,'Value');
molecules_data.checkbox(1,2) = get(cb1_2,'Value');
molecules_data.checkbox(1,3) = get(cb1_3,'Value');

molecules_data.checkbox(2,1) = get(cb2_1,'Value');
molecules_data.checkbox(2,2) = get(cb2_2,'Value');
molecules_data.checkbox(2,3) = get(cb2_3,'Value');

%%% initialize subplots %%%%%%%%%%%%%%%
%%% subplot1 %%%%%%%%%%%%%%%%%%%%%%%%%%
sp1  = subplot(2,2,3); 
set(gca,'position',pos1)

title('Molecules locations','FontSize',fs4)
set(gca,'XTick',[])
set(gca,'YTick',[])
set(gca,'XTickLabel',[])
set(gca,'YTickLabel',[])
xlabel('X (nm)','FontSize',fs3)
ylabel('Y (nm)','FontSize',fs3)
box on
axis square

colormap(gray);
h_colorbar = colorbar;
title(h_colorbar,'Z (nm)','FontSize',fs3);
set(h_colorbar,'YTickLabel',{''});
%%% alignment %%%%%%%%%%%%%%%%%%%%%%%%%
align(Save_pb,'Fixed',3,'Fixed',3);
align([Save_pb Close_pb],'Fixed',3,'Bottom');
% uiwait

end




