function gr = gr_arrays(array1,array2,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : array1,array2,parameters
output     : gr
called by  : ui_pair_correlation_function
calling    : none
description: Calculates the Pair Correlation Function 
of two arrays of points.
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

array1     = real(array1);
array2     = real(array2);
sum_array2 = sum(sum(array2));
array_area = size(array1,1)*size(array1,2);
norm2      = sum_array2/array_area;

linind_rings = parameters.analyses.linind_rings;
max_R        = length(parameters.analyses.rings);


gr = zeros(1,max_R);

for ring_radius = 1:max_R 
    
    %%% create a zeros array to fit the linind of the ring
    h = zeros(2*ring_radius - 1);
    
    %%% makes the lininds of the ring = 1
    h(linind_rings{ring_radius}) = 1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 2D convolution of the points array the ring array
    conv_array1_h = conv2(array1,h,'same');
    
    %%% count the number of array2 points that are on the rings
    number_of_points2_in_rings1 = sum(sum(conv_array1_h.*logical(array2)));
    
    %%% sum of areas of al the rings
    rings_areas_np = sum(sum(conv_array1_h));
    
    %%% normalisation factor to get g(r = inf) = 1
    normalization = rings_areas_np*norm2;
    
    %%% g(r)
    gr(ring_radius) = number_of_points2_in_rings1./normalization;
end
end









