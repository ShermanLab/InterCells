function DENSITIES = results2densities(results_folder_name,...
    selected_times,run,DILATIONS,EROSIONS2)
                                     
all_results = load(results_folder_name);

DILATION2 = DILATIONS{1};
% EROSION2  = EROSIONS2{2};
% DILATION3 = DILATIONS{2};
% DILATION4 = DILATIONS{3};

DENSITIES  = cell(3,1);
DENSITY22   = cell(size(selected_times,2),1);
DENSITY23   = cell(size(selected_times,2),1);
DENSITY24   = cell(size(selected_times,2),1);
% DENSITY32   = cell(size(data_times,2),1);
% DENSITY42   = cell(size(data_times,2),1);
% DENSITY43   = cell(size(data_times,2),1);
% disp(run)

%%% reading data %%%%%%%%%%%%%%%%%%%%%%
% global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
% size_x      = global_data.array_size_x;
% size_y      = global_data.array_size_y;
% max_R       = 50;

for t = 1:length(selected_times)
%     t = data_times(t0);
    disp(t)
    %%% Cell1
    Cell1_data                = all_results.RUNS_RESULTS{1,1}{t,1}.Cell1;
    id_linind_type_Z_E_Cell1  = Cell1_data.id_linind_type_Z_E_Cell1;
    
    idm    = id_linind_type_Z_E_Cell1(:,1);
    idm1_2 = idm(id_linind_type_Z_E_Cell1(:,3) == 2);
    idm1_3 = idm(id_linind_type_Z_E_Cell1(:,3) == 3);
    idm1_4 = idm(id_linind_type_Z_E_Cell1(:,3) == 4);
    
    linindm1_2  = id_linind_type_Z_E_Cell1(idm1_2,2);
    linindm1_3  = id_linind_type_Z_E_Cell1(idm1_3,2);
    linindm1_4  = id_linind_type_Z_E_Cell1(idm1_4,2);
       
    dilations2 = DILATION2{t,2}; % DILATION2{t,1};
%     erosions2  = EROSION2{t,2}; % DILATION2{t,1};
%     dilations3 = DILATION3{t,1};
%     dilations4 = DILATION4{t,1};
    
    density22 = cell(length(dilations2),1);
    density23 = cell(length(dilations2),1);
    density24 = cell(length(dilations2),1);
    
    for r_index = 1:length(dilations2)
        dilation2_r = dilations2{r_index};
%         erosion2_r  = erosions2{r_index};
%         dilation3_r = dilations3{r_index};
%         dilation4_r = dilations4{r_index};
%         if r_index == 1
%             dilation2_r = erosion2_r;
%         else
%             dilation2_r = union(dilation2_r,erosion2_r);
%         end
        
        area_dilation2_r  = length(dilation2_r);
%         area_dilation3_r  = length(dilation3_r);
%         area_dilation4_r  = length(dilation4_r);
        %%%%%%%%%%%%%%%%%%%%%
        plot1 = 1;
        if plot1
            figure(17)
            A = zeros(size_x,size_y);
            A(dilation2_r)  = 1;
            A(linindm1_2) = 2;
            figure(10)
            imagesc(A)
            pause(0.1)
        end
        
        %%%%%%%%%%%%%%%%%%%%%
        n_2r2 = length(intersect(dilation2_r,linindm1_2));
        n_2r3 = length(intersect(dilation2_r,linindm1_3));
        n_2r4 = length(intersect(dilation2_r,linindm1_4));
        
        density22{r_index} = n_2r2/area_dilation2_r;
        density23{r_index} = n_2r3/area_dilation2_r;
        density24{r_index} = n_2r4/area_dilation2_r;
    end
    DENSITY22{t} = density22;
    DENSITY23{t} = density23;
    DENSITY24{t} = density24;
    
end

DENSITIES{1} = DENSITY22;
DENSITIES{2} = DENSITY23;
DENSITIES{3} = DENSITY24;












