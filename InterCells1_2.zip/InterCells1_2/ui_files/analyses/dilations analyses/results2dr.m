function results2dr(folder_name,selected_times,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(folder_name);
% t = 0;
clockname = folder_name(9:end);
%%% parameters
% a      = parameters.global.pixel_size;
linind_rings = parameters.analyses.linind_rings;
max_R        = parameters.analyses.max_R;
c2 = 1;
c3 = 1;
c4 = 1;

GR  = cell(3,3);
G22 = zeros(size(selected_times,2),max_R+1);
G23 = zeros(size(selected_times,2),max_R+1);
G32 = zeros(size(selected_times,2),max_R+1);
G33 = zeros(size(selected_times,2),max_R+1);

G24 = zeros(size(selected_times,2),max_R+1);
G42 = zeros(size(selected_times,2),max_R+1);
G44 = zeros(size(selected_times,2),max_R+1);

G34 = zeros(size(selected_times,2),max_R+1);
G43 = zeros(size(selected_times,2),max_R+1);

%%% reading data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
size_x      = global_data.array_size_x;
size_y      = global_data.array_size_y;
L           = global_data.L;

for t = selected_times(1:end)
    %%% TOP
    Cell1_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.Cell1;
    id_linind_type_Z_E_Cell1  = Cell1_data.id_linind_type_Z_E_Cell1;
    idm       = id_linind_type_Z_E_Cell1(:,1);
    idm1_2 = idm(id_linind_type_Z_E_Cell1(:,3) == 2);
    idm1_3 = idm(id_linind_type_Z_E_Cell1(:,3) == 3);
    idm1_4 = idm(id_linind_type_Z_E_Cell1(:,3) == 4);
    idm1_5 = idm(id_linind_type_Z_E_Cell1(:,3) == 5);
    idm1_6 = idm(id_linind_type_Z_E_Cell1(:,3) == 6);
    
    linindm1_2  = id_linind_type_Z_E_Cell1(idm1_2,2);
    linindm1_3  = id_linind_type_Z_E_Cell1(idm1_3,2);
    linindm1_4  = id_linind_type_Z_E_Cell1(idm1_4,2);
%     linindm1_5  = id_linind_type_Z_E_TOP(idm1_5,2);
%     linindm1_6  = id_linind_type_Z_E_TOP(idm1_6,2);
       
    gr22 = gc_prog_conv(linindm1_2,linindm1_2,c2,c2,size_x,size_y,linind_rings);
    gr23 = gc_prog_conv(linindm1_2,linindm1_3,c2,c3,size_x,size_y,linind_rings);
    gr32 = gc_prog_conv(linindm1_3,linindm1_2,c3,c2,size_x,size_y,linind_rings);
    gr33 = gc_prog_conv(linindm1_3,linindm1_3,c3,c3,size_x,size_y,linind_rings);
    
    gr24 = gc_prog_conv(linindm1_2,linindm1_4,c2,c4,size_x,size_y,linind_rings);
    gr42 = gc_prog_conv(linindm1_4,linindm1_2,c4,c2,size_x,size_y,linind_rings);
    gr44 = gc_prog_conv(linindm1_4,linindm1_4,c4,c4,size_x,size_y,linind_rings);

    gr34 = gc_prog_conv(linindm1_3,linindm1_4,c3,c4,size_x,size_y,linind_rings);
    gr43 = gc_prog_conv(linindm1_4,linindm1_3,c4,c3,size_x,size_y,linind_rings);
    
    G22(t+1,:) = gr22;
    G23(t+1,:) = gr23;
    G24(t+1,:) = gr24;
        
    G32(t+1,:) = gr32;
    G33(t+1,:) = gr33;
    G34(t+1,:) = gr34;
    
    G42(t+1,:) = gr42;
    G43(t+1,:) = gr43;
    G44(t+1,:) = gr44;
    
end

GR{1,1} = G22;
GR{1,2} = G23;
GR{1,3} = G24;

GR{2,1} = G32;
GR{2,2} = G33;
GR{2,3} = G34;

GR{3,1} = G42;
GR{3,2} = G43;
GR{3,3} = G44;

%%% plot test %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for p = 1:1
    % G22 = GR{1,1};
    % G23 = GR{1,2};
    % G24 = GR{1,3};
    % 
    % G32 = GR{2,1};
    % G33 = GR{2,2};
    % G34 = GR{2,3};
    % 
    % G42 = GR{3,1};
    % G43 = GR{3,2};
    % G44 = GR{3,3};

    figure(3)
    clf
    subplot(3,3,1)
    surf(G22','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,2)
    surf(G23','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,3)
    surf(G24','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,4)
    surf(G32','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,5)
    surf(G33','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,6)
    surf(G34','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,7)
    surf(G42','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,8)
    surf(G43','EdgeColor','none')
    view(2)
    axis tight

    subplot(3,3,9)
    surf(G44','EdgeColor','none')
    view(2)
    axis tight
end

