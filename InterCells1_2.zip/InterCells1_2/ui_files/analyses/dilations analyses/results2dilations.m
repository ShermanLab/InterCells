function DILATIONS = results2dilations(results_folder_name,...
    selected_times,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(results_folder_name);
% t = 0;
clockname = results_folder_name(9:end);
%%% parameters
max_R = parameters.analyses.max_R;

DILATIONS  = cell(3,1);
DILATIONS2 = cell(size(selected_times,1),1);
DILATIONS3 = cell(size(selected_times,1),1);
DILATIONS4 = cell(size(selected_times,1),1);
disp(run)
%%% reading data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
% size_x      = global_data.array_size_x;
% size_y      = global_data.array_size_y;

for t = selected_times(1:end)
    disp(t)
    %%% Cell1
    Cell1_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.Cell1;
    id_linind_type_Z_E_Cell1  = Cell1_data.id_linind_type_Z_E_Cell1;
    
    idm           = id_linind_type_Z_E_Cell1(:,1);
    idm1_2        = idm(id_linind_type_Z_E_Cell1(:,3) == 2);
    idm1_3        = idm(id_linind_type_Z_E_Cell1(:,3) == 3);
    idm1_4        = idm(id_linind_type_Z_E_Cell1(:,3) == 4);
    
    linindm1_2    = id_linind_type_Z_E_Cell1(idm1_2,2);
    linindm1_3    = id_linind_type_Z_E_Cell1(idm1_3,2);
    linindm1_4    = id_linind_type_Z_E_Cell1(idm1_4,2);
       
%     dilations2    = dilations(linindm1_2,parameters);
    dilations2    = dilations(linindm1_2,parameters);
    dilations3    = dilations(linindm1_3,parameters);
    dilations4    = dilations(linindm1_4,parameters);
        
    DILATIONS2{t+1,1} = dilations2;
    DILATIONS3{t+1,1} = dilations3;
    DILATIONS4{t+1,1} = dilations4;
    
end

DILATIONS{1} = DILATIONS2;
DILATIONS{2} = DILATIONS3;
DILATIONS{3} = DILATIONS4;

















