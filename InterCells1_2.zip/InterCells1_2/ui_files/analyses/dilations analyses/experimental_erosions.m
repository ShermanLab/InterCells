function linind_erosions = experimental_erosions(linind_tcr,size_x,size_y,max_R)


%%% crating the disk with radius = erosion_max 
%%% and the union of disks around linind_data points

erosion_max = 20;
A0               = zeros(size_x,size_y);
A0(linind_tcr)  = 1;
h                = fspecial('disk',erosion_max);
A1               = logical(filter2(h,A0,'same'));
mid_point        = bwmorph(A1,'shrink',inf);

figure(12)
spy(mid_point)

linind_mid_point = find(mid_point);
filled_dilations = A1;

linind_erosions = cell(max_R+1,1);

for r = 0:max_R
    linind_erosions{r+1} = linind_mid_point;
    
    if r >= erosion_max && r < 2*erosion_max
        perim_filled_dilations = bwmorph(filled_dilations,'remove');
        linind_perim     = find(perim_filled_dilations);
        erosion_index    = 2*erosion_max - r;
        filled_dilations = bwmorph(filled_dilations,'erode');
        linind_erosions{erosion_index} = linind_perim;
%             disp(r_index)
%             disp(erosion_index)
        if 0
            figure(11)
            clf
            imagesc(filled_dilations)
            pause%(0.1)
        end
    end
end
