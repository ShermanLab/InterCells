function EROSIONS = results2erosions(results_folder_name,...
    selected_times,run,parameters)

%%% get data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_results = load(results_folder_name);
% t = 0;
% clockname = results_folder_name(14:end);
%%% parameters
% max_R = parameters.analyses.max_R;

% EROSIONS  = cell(3,1);
EROSIONS2 = cell(size(selected_times,2),1);
% EROSIONS3 = cell(size(data_times,2),1);
% EROSIONS4 = cell(size(data_times,2),1);
disp(run)
%%% reading data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% global_data = all_results.RUNS_RESULTS{1,run}{1,1}.global;
% size_x      = global_data.array_size_x;
% size_y      = global_data.array_size_y;

for t = selected_times(1:end)
    disp(t)
    %%% TOP
    Cell1_data                = all_results.RUNS_RESULTS{1,1}{t+1,1}.Cell1;
    id_linind_type_Z_E_Cell1  = Cell1_data.id_linind_type_Z_E_Cell1;
    
    idm           = id_linind_type_Z_E_Cell1(:,1);
    idm1_2        = idm(id_linind_type_Z_E_Cell1(:,3) == 2);
%     idm1_3        = idm(id_linind_type_Z_E_Cell1(:,3) == 3);
%     idm1_4        = idm(id_linind_type_Z_E_Cell1(:,3) == 4);
    
    linindm1_2    = id_linind_type_Z_E_Cell1(idm1_2,2);
%     linindm1_3    = id_linind_type_Z_E_Cell1(idm1_3,2);
%     linindm1_4    = id_linind_type_Z_E_Cell1(idm1_4,2);
       
    erosions2      = erosions(linindm1_2,parameters);
%     erosions3      = erosions(linindm1_3,parameters);
%     erosions4      = erosions(linindm1_4,parameters);
        
    EROSIONS2{t+1} = erosions2;
%     EROSIONS3{t+1} = erosions3;
%     EROSIONS4{t+1} = erosions4;
%     
end

EROSIONS{1} = EROSIONS2;
% EROSIONS{2} = EROSIONS3;
% EROSIONS{3} = EROSIONS4;















