function plot_DENSITIES(DENSITIES)

DENSITIES22 = DENSITIES{1};
DENSITIES23 = DENSITIES{2};
DENSITIES24 = DENSITIES{3};

R = 0:50;
max_x = max(R);
max_y = 0.1;
maxdensities22 = zeros(101,1);
maxdensities23 = zeros(101,1);
maxdensities24 = zeros(101,1);

stddensities22 = zeros(101,1);
stddensities23 = zeros(101,1);
stddensities24 = zeros(101,1);

for t = 1:101
    densities22 = DENSITIES22{t};
    densities23 = DENSITIES23{t};
    densities24 = DENSITIES24{t};
    
    smdensities22 = smooth([densities22{:}],5);
    smdensities23 = smooth([densities23{:}],5);
    smdensities24 = smooth([densities24{:}],5);
    
    maxdensities22(t) = find(smdensities22 == max(smdensities22));
    maxdensities23(t) = find(smdensities23 == max(smdensities23));
    maxdensities24(t) = find(smdensities24 == max(smdensities24));
    %%%%%%%%%%%%%%%%%%%%%%%%%
%     [xi,yi] = polyxpoly(x1,y1,x2,y2)
    hm22 = max(smdensities23)/2;
    hm23 = max(smdensities23)/2;
    hm24 = max(smdensities24)/2;
    
    [x22i,~] = polyxpoly([0 max_x],[hm22 hm22],R,smdensities23);
    [x23i,~] = polyxpoly([0 max_x],[hm23 hm23],R,smdensities23);
    [x24i,~] = polyxpoly([0 max_x],[hm24 hm24],R,smdensities24);
    
    fwhm22 = max(x22i) - min(x22i);
    fwhm23 = max(x23i) - min(x23i);
    fwhm24 = max(x24i) - min(x24i);
    %%%%%%%%%%%%%%%%%%%%%%%%%
    
    stddensities22(t) = std(find(smdensities22 > mean(smdensities22)));
    stddensities23(t) = std(find(smdensities23 > mean(smdensities23)));
    stddensities24(t) = std(find(smdensities24 > mean(smdensities24)));
    
%     stddensities22(t) = std(find(smdensities22 > 0));
%     stddensities23(t) = std(find(smdensities23 > 0));
%     stddensities24(t) = std(find(smdensities24 > 0));
    
    figure(8)
    clf
    %%% 
    plot(R,[densities22{:}],'g-')
    hold on
%     plot(R,[densities23{:}],'b-')
%     plot(R,[densities24{:}],'r-')
    
    bar(R,[densities23{:}],'b')
    bar(R,[densities24{:}],'r')
    alpha(0.5)
    
    plot(R,smdensities22,'g-','LineWidth',2)
    plot(R,smdensities23,'b-','LineWidth',2)
    plot(R,smdensities24,'r-','LineWidth',2)
    hold off
    axis([0 max_x 0 max_y])
%     legend('a(r)')
    xlabel('Disk radius (pixels)')
    ylabel('Density')
    title(['t = ',int2str(t-1)])
    
    drawnow
    pause(0.02)
end
figure(9)
clf
% errorbar(0:100,maxdensities22,stddensities22,'g')
% std23max = maxdensities23 + stddensities23/2;
% std23min = maxdensities23 - stddensities23/2;
% std24max = maxdensities24 + stddensities24/2;
% std24min = maxdensities24 - stddensities24/2;
std22max = maxdensities22 + fwhm22/2;
std22min = maxdensities22 - fwhm22/2;
std23max = maxdensities23 + fwhm23/2;
std23min = maxdensities23 - fwhm23/2;
std24max = maxdensities24 + fwhm24/2;
std24min = maxdensities24 - fwhm24/2;
T = 0:100;
std_polygon_x  = [T,max(T) - T];
std22polygon_y = [std22min',(flipud(std22max))'];
std23polygon_y = [std23min',(flipud(std23max))'];
std24polygon_y = [std24min',(flipud(std24max))'];

% errorbar(0:100,maxdensities23,stddensities23,'b')
% errorbar(0:100,maxdensities24,stddensities24,'r')

patch(std_polygon_x,std22polygon_y,'g','EdgeColor','g')
hold on
patch(std_polygon_x,std23polygon_y,'b','EdgeColor','b')
patch(std_polygon_x,std24polygon_y,'r','EdgeColor','r')
alpha(0.2)
plot(T,maxdensities22,'g','LineWidth',2)
plot(T,maxdensities23,'b','LineWidth',2)
plot(T,maxdensities24,'r','LineWidth',2)
hold off
axis([0 max(T) 0 70])




