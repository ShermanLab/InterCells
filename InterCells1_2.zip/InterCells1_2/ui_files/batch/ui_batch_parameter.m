function ui_batch_parameter()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 3;
gapy = 0;

px   = x0+150;
py   = y0+425;
pw   = 150; %650;
ph   = 122; 

pbx  = 3;
pby  = 3;
pbw  = pw;
pbh  = 30;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
p = figure(31);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Batch parameter','NumberTitle','off');

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Batch parameter',...
    'FontSize',fs4,...
    'Position',[0 ph-40 pbw 40],...
    'Backgroundcolor',0.8*[1 1 1]);

%%% global %%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','pushbutton',...
    'String','Global',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[0 ph-2*pbh pbw pbh],...
    'Callback','ui_global_batch_parameter');

%%% membranes %%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','pushbutton',...
    'String','Membranes',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[0 ph-(3*pbh+gapy) pbw pbh],...
    'Callback','ui_membranes_batch');

%%% molecules %%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','pushbutton',...
    'String','Molecules',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[0 ph-(4*pbh+2*gapy) pbw pbh],...
    'Callback','ui_molecules_batch');

end