function ui_membrane_batch_parameter(cn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 3;
gapy = 3;

px   = x0+495;
py   = y0+240;
pw   = 250;
ph   = 145; 

% pbx  = 3;
% pby  = 3;
% pbw  = 200;
pbh  = 30;


p = figure(34);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Membrane batch parameter','NumberTitle','off');


%%% get batch parameters names %%%%%%%%
%%% possible batch parameters

batch_names{1} = 'Membrane rigidity (KT)'; %
batch_names{2} = 'Membrane min rigidity (KT)'; %
batch_names{3} = 'Membrane max rigidity (KT)'; %
batch_names{4} = 'Membrane local rigidity (0/1)'; %
batch_names{5} = 'Initial menbrane Z (nm)'; %
batch_names{6} = 'Sigma dz (nm)'; %

save_string{1} = 'membrane_rigidity'; %
save_string{2} = 'membrane_min_rigidity'; %
save_string{3} = 'membrane_max_rigidity'; %
save_string{4} = 'membrane local rigidity (0/1)'; %
save_string{5} = 'initial_menbrane_Z'; %
save_string{6} = 'sigma_dz'; %

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Membrane batch parameter',...
    'FontSize',fs4,...
    'Position',[0 ph-40 pw 40],...
    'Backgroundcolor',0.8*[1 1 1]);

popup1 = uicontrol(p,'Style','popup',...
    'String', batch_names,...
    'FontSize',fs2,...
    'Value',1,...
    'Position',[0 ph-60 pw pbh],...
    'Callback',@get_membrane_batch_parameter);    

%%% @get_batch_parameter %%%%%%%%%%%%%%
function get_membrane_batch_parameter(varargin)
    val1 = get(popup1,'Value');
    switch val1
        case 1
            parameters.batch.name          = batch_names{1};
            parameters.batch.save_string   = save_string{1};
            parameters.batch.current_value = parameters.Cells(cn).membrane.rigidity;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').membrane.rigidity'];
            
        case 2
            parameters.batch.name          = batch_names{2};
            parameters.batch.save_string   = save_string{2};
            parameters.batch.current_value = parameters.Cells(cn).membrane.min_rigidity;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').membrane.min_rigidity'];
            
        case 3
            parameters.batch.name          = batch_names{3};
            parameters.batch.save_string   = save_string{3};
            parameters.batch.current_value = parameters.Cells(cn).membrane.max_rigidity;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').membrane.max_rigidity'];
                        
        case 4
            parameters.batch.name          = batch_names{4};
            parameters.batch.save_string   = save_string{4};
            parameters.batch.current_value = parameters.Cells(cn).membrane.local_rigidity;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').membrane.local_rigidity'];

        case 5
            parameters.batch.name          = batch_names{5};
            parameters.batch.save_string   = save_string{5};
            parameters.batch.current_value = parameters.Cells(cn).membrane.Z0;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').membrane.Z0'];

        case 6
            parameters.batch.name          = batch_names{6};
            parameters.batch.save_string   = save_string{6};
            parameters.batch.current_value = parameters.Cells(cn).membrane.dz;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').membrane.dz'];

    end
    
    enter_membrane_batch_values
    
end 

%%%
b = [];
%%%

function enter_membrane_batch_values(varargin)
    
    uicontrol(p,'Style','text',...
    'String','Enter batch values',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[0 ph-90 pw pbh]);
    
    b.v = uicontrol(p,'Style','edit',...
    'String',parameters.batch.current_value,...
    'FontSize',fs3,...
    'Position',[0 ph-115 pw pbh],...
    'Backgroundcolor',0.94*[1 1 1]);

end

%%% Ok_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[gapx gapy 50 20],...
    'Callback',@get_batch_values);

    function get_batch_values(varargin)
        
        batch_values = get(b.v,'String');
        parameters.batch.values = str2num(batch_values);
        
        close(34)
        close(33)
        close(31)
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

waitfor(Ok_pb)

end



