function ui_global_batch_parameter()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

x0   = parameters.ui.mainfig.x0;
y0   = parameters.ui.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 3;
gapy = 3;

px   = x0+320;
py   = y0+338;
pw   = 210;
ph   = 145; 

% pbx  = 3;
% pby  = 3;
% pbw  = 200;
pbh  = 30;

p = figure(32);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Global batch parameter','NumberTitle','off');


batch_names{1} = 'Stick time (sec)';
batch_names{2} = 'Use PLL (0/1)';
batch_names{3} = 'PLL binding strength (KT)';

save_string{1} = 'stick_time';
save_string{2} = 'use_PLL';
save_string{3} = 'PLL_binding_strength';

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Global batch parameter',...
    'FontSize',fs4,...
    'Position',[0 ph-40 pw 40],...
    'Backgroundcolor',0.8*[1 1 1]);

popup1 = uicontrol(p,'Style','popup',...
    'String', batch_names,...
    'FontSize',fs2,...
    'Value',1,...
    'Position',[0 ph-60 pw pbh],...
    'Callback',@get_global_batch_parameter);    

%%% @get_batch_parameter %%%%%%%%%%%%%%
function get_global_batch_parameter(varargin)
    val1 = get(popup1,'Value');
    switch val1
        case 1
            parameters.batch.name          = batch_names{1};
            parameters.batch.save_string   = save_string{1};
            parameters.batch.current_value = parameters.global.stick_time;
            parameters.batch.identity      = 'parameters.global.stick_time';            
            
        case 2
            parameters.batch.name          = batch_names{2};
            parameters.batch.save_string   = save_string{2};
            parameters.batch.current_value = parameters.global.PLL.use;
            parameters.batch.identity      = 'parameters.global.PLL.use';

        case 3
            parameters.batch.name          = batch_names{3};
            parameters.batch.save_string   = save_string{3};
            parameters.batch.current_value = parameters.global.PLL.binding_strength;
            parameters.batch.identity      = 'parameters.global.binding_strength';

    end
    
    enter_global_batch_values
    
end 

%%%
b = [];
%%%
function enter_global_batch_values(varargin)
    
    uicontrol(p,'Style','text',...
    'String','Enter batch values',...
    'FontSize',fs3,...
    'BackgroundColor',0.8*[1 1 1],...
    'Position',[0 ph-90 pw pbh]);

    b.v = uicontrol(p,'Style','edit',...
    'String',parameters.batch.current_value,...
    'FontSize',fs3,...
    'Position',[0 ph-115 pw pbh],...
    'Backgroundcolor',0.94*[1 1 1]);
    
end

%%% Ok_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[gapx gapy 50 20],...
    'Callback',@get_batch_values);

    function get_batch_values(varargin)
        
        batch_values = get(b.v,'String');
        parameters.batch.values = str2num(batch_values);
        
        close(32)
        close(31)
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

waitfor(Ok_pb)

end