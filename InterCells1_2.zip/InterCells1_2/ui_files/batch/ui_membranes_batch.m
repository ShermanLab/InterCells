function ui_membranes_batch()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters.
called by  : 
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

x0       = parameters.ui.mainfig.x0;
y0       = parameters.ui.mainfig.y0;

n_types1 = size(parameters.Cells(1).molecule_type,2); 
n_types2 = size(parameters.Cells(2).molecule_type,2); 

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 0;
gapy = 3;

px   = x0+320;
py   = y0+355;
pw   = 155;

pbx  = 3;
pby  = 0;
pbw  = pw;
pbh  = 30;

ph   = (pbh + gapy)*(3); 

p = figure(33);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Molecules types','NumberTitle','off');
 
%%% text Cell1 molecules %%%%%%%%%%%%%%
text1 = uicontrol('Parent',p,...
'Style','text',...
'String',['Membranes'],...
'FontSize',fs4,...
'Position',[2 ph-(pbh) pbw pbh]);

%%% Cells(1) membrane %%%%%%%%%%%%%%%%%
pb1 = uicontrol(p,'Style','PushButton',...
  'String','Membrane1',...
  'FontSize',fs3,...
  'Position',[gapx ph-2*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',1*[1 1 1],...
  'Callback','ui_membrane_batch_parameter(1)');

%%% Cells(2) membrane %%%%%%%%%%%%%%%%%
pb2 = uicontrol(p,'Style','PushButton',...
  'String','Membrane2',...
  'Foregroundcolor',1*[1 1 1],...
  'FontSize',fs3,...
  'Position',[gapx ph-3*(gapy+pbh) pbw pbh],...
  'Backgroundcolor',0.2*[1 1 1],...
  'Callback','ui_membrane_batch_parameter(2)');

end


