function ui_molecule_batch_parameter(cn,tn)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : parameters
called by  : ui_main
calling    : none
description: returns the user selections of Cell_type
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters


x0   = parameters.ui.mainfig.x0;
y0   = parameters.ui.mainfig.y0;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% font sizes
fs1  = 8;
fs2  = 10;
fs3  = 12;
fs4  = 14;

gapx = 3;
gapy = 3;

px   = x0+500;
py   = y0+250;
pw   = 250; 
ph   = 145; 

% pbx  = 3;
% pby  = 3;
% pbw  = 200;
pbh  = 30;


p = figure(36);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Molecule batch parameter','NumberTitle','off');


%%% get batch parameters names %%%%%%%%
%%% possible batch parameters

% molecules
batch_names{1}  = 'Vertical size (nm)';
batch_names{2}  = 'Binding top (nm)';
batch_names{3}  = 'Binding bottom (nm)';
batch_names{4}  = 'Binding strength (KT)';
batch_names{5}  = 'Spring strength (KT/nm^2)';
batch_names{6}  = 'Force membrane to molecule height (0/1)';
batch_names{7}  = 'Diffusion coefficient (um^2/sec)';
batch_names{8}  = 'Global density (#/um^2)';
batch_names{9}  = 'Cluster density (#/um^2)';
batch_names{10} = 'Density of clusters (#/um^2)';

save_string{1}  = 'vertical_size'; 
save_string{2}  = 'binding_top';
save_string{3}  = 'binding_bottom';
save_string{4}  = 'binding_strength';
save_string{5}  = 'spring_strength';
save_string{6}  = 'force_z';
save_string{7}  = 'diffusion';
save_string{8}  = 'global_density';
save_string{9}  = 'cluster_density';
save_string{10} = 'density_of_clusters';

%%% Title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Molecule batch parameter',...
    'FontSize',fs4,...
    'Position',[0 ph-40 pw 40],...
    'Backgroundcolor',0.8*[1 1 1]);

popup1 = uicontrol(p,'Style','popup',...
    'String', batch_names,...
    'FontSize',fs2,...
    'Value',1,...
    'Position',[0 ph-60 pw pbh],...
    'Callback',@get_membrane_batch_parameter);    

%%% @get_batch_parameter %%%%%%%%%%%%%%
function get_membrane_batch_parameter(varargin)
    val1 = get(popup1,'Value');
    switch val1
        case 1
            parameters.batch.name          = batch_names{1};
            parameters.batch.save_string   = save_string{1};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).vertical_size;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').vertical_size'];
            
        case 2
            parameters.batch.name          = batch_names{2};
            parameters.batch.save_string   = save_string{2};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).binding_top;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').binding_top'];
            
        case 3
            parameters.batch.name          = batch_names{3};
            parameters.batch.save_string   = save_string{3};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).binding_bottom;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').binding_bottom'];
            
        case 4
            parameters.batch.name          = batch_names{4};
            parameters.batch.save_string   = save_string{4};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).binding_strength;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').binding_strength'];
            
        case 5
            parameters.batch.name          = batch_names{5};
            parameters.batch.save_string   = save_string{5};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).spring_k;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').spring_k'];
            
        case 6
            parameters.batch.name          = batch_names{6};
            parameters.batch.save_string   = save_string{6};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).force_z;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').force_z'];
            
        case 7
            parameters.batch.name          = batch_names{7};
            parameters.batch.save_string   = save_string{7};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).diffusion_constant;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').diffusion_constant'];
            
        case 8
            parameters.batch.name          = batch_names{8};
            parameters.batch.save_string   = save_string{8};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).global_density;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').global_density'];
           
        case 9
            parameters.batch.name          = batch_names{9};
            parameters.batch.save_string   = save_string{9};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).cluster_density;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').cluster_density'];

        case 10
            parameters.batch.name          = batch_names{10};
            parameters.batch.save_string   = save_string{10};
            parameters.batch.current_value = parameters.Cells(cn).molecule_type(tn).density_of_clusters;
            parameters.batch.identity      = ...
                ['parameters.Cells(',num2str(cn),').molecule_type(',num2str(tn),').density_of_clusters'];
            
    end
    
    enter_molecule_batch_values
    
end 

%%%
b = [];
%%%

function enter_molecule_batch_values(varargin)
    
    uicontrol(p,'Style','text',...
    'String','Enter batch values',...
    'FontSize',fs3,...
    'BackgroundColor',0.94*[1 1 1],...
    'Position',[0 ph-90 pw pbh]);
    
    b.v = uicontrol(p,'Style','edit',...
    'String',parameters.batch.current_value,...
    'FontSize',fs3,...
    'Position',[0 ph-115 pw pbh],...
    'Backgroundcolor',0.94*[1 1 1]);

end

%%% Ok_pb %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[gapx gapy 50 20],...
    'Callback',@get_batch_values);

    function get_batch_values(varargin)
        
        batch_values = get(b.v,'String');
        parameters.batch.values = str2num(batch_values);
        
%         parameters.Cells(cn).molecule_type(tn).vertical_size = parameters.batch.values;
        
        close(36)
        close(35)
        close(31)
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

waitfor(Ok_pb)

end