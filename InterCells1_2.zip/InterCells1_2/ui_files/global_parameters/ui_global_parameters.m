function ui_global_parameters() 

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters
output     : global_parameters_table
called by  : ui_main
calling    : globalparameters2table
description: make tabel from parameters.global 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters simulation_data

%%% global parameters panel setup %%%%%

%%% craete global parameters table
global_parameters_table = globalparameters2table(parameters); % 
dat   = global_parameters_table;
nrows = size(dat,1);
%%% getting ui_parameters %%%%%%%%%
x0 = parameters.ui.mainfig.x0;
y0 = parameters.ui.mainfig.y0;

fs1  = 8;
fs2 = 10;
fs3 = 12;

%%% Panel %%%%%%%%%%%%%%%%%%%%%%%%%
rowh = 18;
pw   = 305;
ph   = nrows*rowh+100; 
px   = x0+150;
py   = y0+300;

gapx = 2;

p = figure(3);
set(p,'Position',[px py pw ph])
set(p,'MenuBar', 'none');
set(p,'Name','Global parameters','NumberTitle','off');

%%% title %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
uicontrol(p,'Style','text',...
    'String','Global parameters','FontSize',fs3,...
    'Position',[0 ph-30 pw 30]);

%%% Table %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
columnname     = {'Name', 'Default', 'New',};
columnformat   = {'char','numeric', 'numeric'};
columnwidth    = {150,60,60};
columneditable = [false false true]; 

tx   = 0;
ty   = 25;
tw   = pw;
th   = ph-65;   

t = uitable(p,'Data',dat,...
    'ColumnName',columnname,...
    'ColumnFormat',columnformat,...
    'ColumnWidth',columnwidth,...
    'ColumnEditable',columneditable,...
    'Position',[tx ty tw th]); 

%%% Cencel %%%%%%%%%%%%%%%%%%%%%%%%%%%%    
pbw = 50;
pbh = 20;
Cancel_pbx = pw - 2*pbw - 5;
Cancel_pby = 3;

Cancel_pb = uicontrol(p,'Style','pushbutton',...
    'String','Cancel',...
    'FontSize',fs1,...
    'Position', [Cancel_pbx Cancel_pby pbw pbh],...
    'Callback',@Cancel_callback); 

%%% @Cancel %%%%%%%%%%%%%%%%%%%%%%%%%%%
function Cancel_callback(varargin)
    uiresume
    ui_main()
    close(3)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Ok %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Ok_pbx = Cancel_pbx + pbw + gapx;
Ok_pby = 3;
Ok_pb = uicontrol(p,'Style','pushbutton',...
    'String','Ok',...
    'FontSize',fs1,...
    'Position',[Ok_pbx Ok_pby pbw pbh],...
    'Callback',@Ok_callback); 

%%% @Ok_callback %%%%%%%%%%%%%%%%%%%%%%
function [] = Ok_callback(varargin)
    
    table = get(t,'Data');
    new_global_parameters = table2globalparameters(table);
    new_size_x     = new_global_parameters.array_size_x;
    new_size_y     = new_global_parameters.array_size_y;
%     
%     default_size_x = 200; %parameters.default_global.array_size_x;
%     default_size_y = 200; %parameters.default_global.array_size_y;
    
    default_size_x = parameters.default_global.array_size_x;
    default_size_y = parameters.default_global.array_size_y;
    
    parameters.global = new_global_parameters;

    if new_size_x ~= default_size_x ||...
       new_size_y ~= default_size_y
        
%         parameters.global = new_global_parameters;
        
        %%% Cell1 %%%%%%%%%%%%%%%%%%%%%
        %%% empty locations array1
        locations_array1 = zeros(new_size_x,new_size_y);
        
        %%% make new Cell1 data
        Cell1_data = locations_array2Cell_data(...
            locations_array1,1);
        
        %%% new_simulation_data.Cells(1)
        simulation_data.Cells(1) = Cell1_data;
        
        %%% Cell2 %%%%%%%%%%%%%%%%%%%%%
        %%% empty locations array2
        locations_array2 = zeros(new_size_x,new_size_y);
        
        %%% make new Cell2 data
        Cell2_data = locations_array2Cell_data(...
            locations_array2,2);
        
        %%% new_simulation_data.Cells(2)
        simulation_data.Cells(2) = Cell2_data;
        
    end
    
    uiresume
    ui_main()
    close(3)
    
end

waitfor(Ok_pb)

end













