function global_parameters = table2globalparameters(table)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters, table
output     : global_parameters
called by  : ui_main
calling    : none
description: 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters 

%%% array
parameters.global.array_size_x          = table{1,3};
parameters.global.array_size_y          = table{2,3};
parameters.global.pixel_size            = table{3,3};
%%% times
parameters.global.iteration_time        = table{5,3};
parameters.global.simulation_time       = table{6,3};
parameters.global.experiment_frame_time = table{7,3};
parameters.global.save_rate             = table{8,3};
%%% dynamics
parameters.global.metropolis_steps      = table{10,3};
parameters.global.stick_time            = table{11,3};
%%% Poly-L-lysene  
parameters.global.PLL.binding_strength  = table{13,3};
parameters.global.PLL.use               = table{14,3};
%%% runs
parameters.global.runs                  = table{16,3};
%%% adhesive surface
parameters.global.adhesive_surface.use  = table{18,2};
parameters.global.adhesive_surface.binding_strength = table{19,2};
parameters.global.adhesive_surface.circles_radius   = table{20,2};
%%% actin
parameters.global.actin.use             = table{22,2};
parameters.global.actin.rigidity_ratio  = table{23,2};

global_parameters = parameters.global;
end


  



