function make_transport_array()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : 
output     : 
called by  : 
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters 

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;

A0 = ones(size_x,size_y);

%%% set center
center_x = 185; %0.8*size_x;
center_y = 230; %0.2*size_y;

[X0,Y0] = find(A0);

DX = center_x - X0;
DY = center_y - Y0;

%%% set magnitude
DXDY_mag = sqrt(DX.^2 + DY.^2);

DX_norm = DX./DXDY_mag;
DY_norm = DY./DXDY_mag;

DX_norm(DXDY_mag == 0) = 0;
DY_norm(DXDY_mag == 0) = 0;

%%% set in/out 
flow1 = 'in';
if strcmp(flow1,'in')
    DX_norm_dir = DX_norm;
    DY_norm_dir = DY_norm;
elseif strcmp(flow1,'out')
    DX_norm_dir = -DX_norm;
    DY_norm_dir = -DY_norm;
end


%%% Transport_x, Transport_y
Transport_x = reshape(DX_norm_dir,size_x,size_y);
Transport_y = reshape(DY_norm_dir,size_x,size_y);

parameters.global.transport.X_array = Transport_x;
parameters.global.transport.Y_array = Transport_y;
% parameters.global.transport.scale   = 0.2; 
% parameters.global.transport.use     = 1; 

end







