function default_ui_parameters = defaultUIparameters()

%%% main figure
ui.mainfig.x0 = 50;
ui.mainfig.y0 = 50;
ui.mainfig.w0 = 1200;
ui.mainfig.h0 = 900;

%%% results figures
ui.results_panels.x0 = ui.mainfig.x0 + 100;
ui.results_panels.y0 = ui.mainfig.y0 + 100;
ui.results_panels.w0 = 900;
ui.results_panels.h0 = 800;

%%% results figures subplots
ui.results_subplots.x0 = 50;
ui.results_subplots.y0 = 50;
ui.results_subplots.w0 = 320;
ui.results_subplots.h0 = 290;

default_ui_parameters = ui;

end