function run_simulation()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : start_interface_simulation
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters simulation_data

plot_data    = 1;

%%% number of runs
runs         = parameters.global.runs;
N_iterations = parameters.global.simulation_time/parameters.global.iteration_time;

% for run1 = 1:runs
results_of_run = cell(parameters.global.simulation_time+1,1); 
iter = 0;

%%% time in seconds
t = ceil(iter/parameters.global.save_rate); % sec

current_linind_experimental_data = [];

%%% batch loop %%%%%%%%%%%%%%%%%%%%%%%%
% nv = 1:length(parameters.batch.values)
numel_batch = numel(parameters.batch.values);

if isempty(parameters.batch.values)
    numel_batch = 1;
    str_values = '';
end

runs = numel_batch;
RESULTS_OF_RUNS = cell(runs,1);

parameters.break_simulation = 0;

for run1 = 1:numel_batch
    
    %%% initial conditions %%%%%%%%%%%%
    
    if ~isempty(parameters.batch.values)
        batch_value = parameters.batch.values(run1);
        eval([parameters.batch.identity,' = ',num2str(batch_value)]);
                
        figure(1); plot_ui_main(); drawnow;
        %%% batch_save_name %%%%%%%%%%%%%%%
%         batch_save_name = [parameters.batch.save_string,num2str(batch_value)];
        str_values0 = num2str(parameters.batch.values);
        str_values = strrep(str_values0, ' ', '_');
        batch_save_name = [parameters.batch.save_string];
        disp(batch_save_name)
    else
        batch_save_name = '';
        disp(batch_save_name)
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% for run1 = 1:runs
    results_of_run{t+1} = simulation_data;
    tic % measures run time
    
    for iter = 1:N_iterations
        t = ceil(iter/parameters.global.save_rate); % sec
        simulation_data.iter = iter;
        simulation_data = updatesimulationdata(simulation_data,...
            current_linind_experimental_data,parameters);
        
        %%% every 'save_rate' iterations 
        if mod(iter,parameters.global.save_rate) == 0
            disp(t)
            if plot_data
                plot_simulation_data(simulation_data,parameters,run1) % ,display_options
            end
            results_of_run{t+1} = simulation_data;
        end
        %%% break %%%%%%%%%%%%%%%%%%%%%
        if parameters.break_simulation
           break;
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end % iter
    toc
    RESULTS_OF_RUNS(run1) = {results_of_run};

    %%% save run %%%%%%%%%%%%%%%%%%%%%%
    %%% set_results_folder %%%%%%%%%%%%
    s = what;
    path1 = s.path;
    results_folder = [path1,'\Results'];
    now_str        = datestr(now,'yyyymmddHHMMSS');
    if ~isempty(parameters.batch.values)
        save_name = ['results_',now_str,batch_save_name,num2str(batch_value)];
    else
        save_name = ['results_',now_str];
    end
      mkdir([results_folder,'\',save_name]);
       save([results_folder,'\',save_name,'\','RESULTS_OF_RUNS'])
%     save([results_folder,'\',save_name,'\','RESULTS_OF_RUNS'],'-v7.3')
    addpath([results_folder,'\',save_name]);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end % runs



end








