% start_interface_simulation

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : parameters
             ui_parameters
called by  : none
calling    : defaultparameters()
             make_library(default_parameters)
             make_initial_Cell1_data(parameters)
             make_initial_Cell2_data(parameters)
             ui_main(parameters,simulation_data)
description:
This file initializes the simulation. It generates the parameters
pform pre-defined default parameters. After defining the
parameters it opens the Graphic User Interface (GUI) main panel. 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear %all
close all
clc

global parameters simulation_data
%%% initializing parameters %%%%%%%%%%%
default_parameters = defaultparameters();
library            = make_library(default_parameters);

parameters.default_global = default_parameters.global_parameters;
parameters.Tcell          = default_parameters.Tcell_parameters;
parameters.Coverslip      = default_parameters.Coverslip_parameters;
parameters.APC            = default_parameters.APC_parameters;

%%% choose cells %%%%%%%%%%%%%%%%%%%%%%
Cell1_name = 'Tcell'; 
Cell2_name = 'Coverslip';
%%% global
parameters.global   = default_parameters.global_parameters;

%%% Cells(1)
if strcmp(Cell1_name,'Tcell')
    parameters.Cells(1) = default_parameters.Tcell_parameters;
end

%%% Cells(2)
if strcmp(Cell2_name,'Coverslip')
    parameters.Cells(2) = default_parameters.Coverslip_parameters;
end
if strcmp(Cell2_name,'APC')
    parameters.Cells(2) = default_parameters.APC_parameters;
end

%%% initial simulation data / temp %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
initial_Cell1_data = make_initial_Cell1_data();
% initial_Cell1_data = make_initial_Cell1_data_4x4();
initial_Cell2_data = make_initial_Cell2_data();

%%% set initial_simulation_data %%%%%%%
simulation_data.initial_Cell1_data = initial_Cell1_data;
simulation_data.initial_Cell2_data = initial_Cell2_data;

simulation_data.Cells(1) = initial_Cell1_data;
simulation_data.Cells(2) = initial_Cell2_data;
simulation_data.iter     = 0;

%%% analyses parameters %%%%%%%%%%%%%%%
parameters.analyses = defaultANALYSESparameters();

%%% analyses parameters %%%%%%%%%%%%%%%
% parameters.batch = [];
parameters.batch.name          = [];
parameters.batch.save_string   = [];
parameters.batch.current_value = [];
parameters.batch.values        = [];
parameters.batch.identity      = [];            
            
%%% ui parameters %%%%%%%%%%%%%%%%%%%%%
parameters.ui       = defaultUIparameters();

%%% plotting_options %%%%%%%%%%%%%%%%%%
parameters.display_options = displayoptions();

%%% analyses_options %%%%%%%%%%%%%%%%%%
analyses_options = analysesoptions();

%%% set transport %%%%%%%%%%%%%%%%%%%%%
make_transport_array()

%%% start gui %%%%%%%%%%%%%%%%%%%%%%%%%
use_gui = 1; 
if use_gui
    ui_main();
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



