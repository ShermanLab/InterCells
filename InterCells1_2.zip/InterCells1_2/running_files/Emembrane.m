function E_membrane = Emembrane(DZ,K,parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : DZ, K, parameters
             simulation_data.
output     : E_membrane
called by  : start_interface_simulation
calling    : none
description: calculating the bending energy of a membrane
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a   = parameters.global.pixel_size;

DZ1 = circshift(DZ,[0 1]);
DZ2 = circshift(DZ,[1 0]);
DZ3 = circshift(DZ,[0 -1]);
DZ4 = circshift(DZ,[-1 0]);

delta_DZ  = DZ1 + DZ2 + DZ3 + DZ4 - 4*DZ;
delta_DZ2 = delta_DZ.^2;
delta_DZ3 = delta_DZ2./(2*a^2);

E_membrane = K.*delta_DZ3;


