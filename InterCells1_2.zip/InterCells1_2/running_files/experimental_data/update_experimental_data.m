function current_linind_experimental_data = update_experimental_data(experimental_data,iter)


experimental_frame = ceil((iter+1)/250); 
rect_x = experimental_data.rect_x;
rect_y = experimental_data.rect_y;
%%% reading tcrs coordinates %%%%%%
TCR_XY  = experimental_data.TCR_XY_all{experimental_frame};
linind_TCR = sub2ind([rect_x,rect_y],TCR_XY(:,1),TCR_XY(:,2));
%%%
% initial_id_linind_type_Z_E0_T_cell    = initialtcelldata(linind_TCR,linind_LFA,linind_GP,L,parameters);
% initial_id_linind_type_Z_E0_coverlsip = initialcoverslipdata(linind_alpha_CD3,linind_alpha_CD11,linind_alpha_CD45,parameters,L);

% id_linind_type_Z_E_T_cell = E18(initial_id_linind_type_Z_E0_T_cell,initial_id_linind_type_Z_E0_coverlsip,parameters);
% id_linind_type_Z_E_coverslip = initial_id_linind_type_Z_E0_coverlsip;
%%%
%%% updating L at TCR locations %%%
if isempty(linind_TCR);
    disp('linind_T is empty')
end
current_linind_experimental_data = linind_TCR;




