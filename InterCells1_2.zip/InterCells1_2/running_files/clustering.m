function idm_tnb_stay = clustering(simulation_data,parameters,cn,tna,tnb)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : start_interface_simulation
calling    : 
description: desides which molecules of type_number_b (tnb)
             can leave the vicinity of molecule of 
             type_number_a (tna).
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

size_x   = parameters.global.array_size_x; 
size_y   = parameters.global.array_size_y; 
a        = parameters.global.pixel_size;

%%% clustering in Cells(cn) %%%%%%%%%%%
idm     = simulation_data.Cells(cn).molecules(:,1);
linindm = simulation_data.Cells(cn).molecules(:,2);
typem   = simulation_data.Cells(cn).molecules(:,3);

%%% ids of molecules type a and type b
idm_tna = idm(typem == tna);
idm_tnb = idm(typem == tnb);

%%% lininds of molecules type a and type b
linindm_tna = linindm(idm_tna);
linindm_tnb = linindm(idm_tnb);

%%% mask of binding range %%%%%%%%%%%%%
locations_array_a  = zeros(size_x,size_y);

locations_array_a(linindm_tna) = 1;

%%% radius of binding range %%%%%%%%%%%
%%% logical disk of binding range %%%%%
binding_radius = parameters.Cells(cn).molecule_type(tna).self_clustering_binding_range/a;

%%% one point disk mask %%%%%%%%%%%%%%%
h = real(logical(fspecial('disk',binding_radius)));
%%% avoiding a molecule cluster to itself
h(binding_radius+1,binding_radius+1) = 0; % disk center = 0

%%% all points disk mask %%%%%%%%%%%%%%
binding_range_mask_array  = logical(conv2(locations_array_a,h,'same'));
linind_binding_range_mask = find(binding_range_mask_array);

%%% find type_b in binding range %%%%%%
%%% linindm_tnb in binding range
linindm_tnb_in_binding_range = linindm_tnb(ismember(linindm_tnb,linind_binding_range_mask));

%%% idm_tnb in binding range
idm_tnb_in_binding_range     = idm_tnb(ismember(linindm_tnb,linindm_tnb_in_binding_range));

%%% idm_tnb bound
%%% P on
P_on_tna  = parameters.Cells(cn).molecule_type(tna).self_clustering_p_on; %1;
P_on_tnb  = parameters.Cells(cn).molecule_type(tnb).self_clustering_p_on; %1;
P_on = P_on_tna;
% P_on = min([P_on_tna,P_on_tnb]);
%%% P off
P_off_tna = parameters.Cells(cn).molecule_type(tna).self_clustering_p_off; % 0.02;
P_off_tnb = parameters.Cells(cn).molecule_type(tnb).self_clustering_p_off; % 0.02;
P_off = P_off_tna;
% P_off = max([P_off_tna,P_off_tnb]);

%%% finding id_stay
idm_tnb_bound1 = ...
    idm_tnb_in_binding_range(rand(size(idm_tnb_in_binding_range)) < P_on);

idm_tnb_stay = ...
    idm_tnb_bound1(rand(size(idm_tnb_bound1)) > P_off);

end



