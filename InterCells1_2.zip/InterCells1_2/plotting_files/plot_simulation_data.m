function plot_simulation_data(simulation_data,parameters,run1)

% input      : simulation_data, parameters.
% output     : none.
% called by  : interface_simlation.
% calling    : plot_molecules_and_membrane.
% description:

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
display_options = parameters.display_options;

%%% molecules_and_membrane %%%%%%%%%%%%
if display_options.molecules_and_membranes
    plot_molecules_and_membrane(simulation_data,parameters,run1);
end

%%% molecules_energies %%%%%%%%%%%%%%%%
if display_options.molecules_energy
    plot_membrane_data(simulation_data,parameters);
end

%%% membrane rigidity %%%%%%%%%%%%%%%%%
if display_options.membrane_rigidity
    plot_molecules_energies(simulation_data,parameters);
end

%%% membrane energy %%%%%%%%%%%%%%%%%%%
if display_options.membrane_energy
    PlotMembraneEnergy2(simulation_data,parameters);
end

end