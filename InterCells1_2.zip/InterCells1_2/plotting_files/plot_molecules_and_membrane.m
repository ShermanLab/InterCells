function plot_molecules_and_membrane(simulation_data,parameters,run1)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : simulation_data, parameters
output     : none
called by  : plot_simulation_data
calling    : none
description: plotting the membrane heigh and the molecules
locations according to the simulation_data. 
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;
iter   = simulation_data.iter;

t = floor(iter/parameters.global.save_rate);
sim_time = parameters.global.simulation_time;
pw = parameters.ui.mainfig.w0;
ph = parameters.ui.mainfig.h0;

fs3 = 12;
fs4 = 14;
%%% reading data %%%%%%%%%%%%%%%%%%%%%%
%%% height of membranes %%%%%%%%%%%%%%% 
hfig2 = figure(2);
set(hfig2,'position',[300 400 1200 500])
clf
%%% location !!!
for plot_membrane_properties = 1
    %%%
    pos1 = [0.05 0.1 0.45 0.8];
    sp1 = subplot('Position',pos1);
    cla(sp1)
    size_x = parameters.global.array_size_x;
    size_y = parameters.global.array_size_y;
    
    Z0 = parameters.Cells(1).membrane.Z0;
    
    Z1 = simulation_data.Cells(1).Z;
    Z2 = simulation_data.Cells(2).Z;

    DZ = Z1 - Z2;

    h3 = pcolor(DZ');
    colormap(gray);
    set(h3,'EdgeColor','none')
    cb4 = colorbar;
    title(cb4,'Z (nm)','FontSize',fs3);
    caxis([0 Z0])

    axis equal
    axis([0 size_x 0 size_y])
    title('Inter membranes distance','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% molecules locations %%%%%%%%%%%%%%%
n_types1 = max(max(simulation_data.Cells(1).LOC));
n_types2 = max(max(simulation_data.Cells(2).LOC));

for fold_plot = 1
    
    pos2 = [0.51 0.1 0.45 0.8];
    sp2 = subplot('Position',pos2);
    cla(sp2)
    
    %%% plot DZ
    h3 = pcolor(DZ');
    colormap(gray);
    set(h3,'EdgeColor','none')
    cb3 = colorbar;
    title(cb3,'Z (nm)','FontSize',fs3);
    caxis([0 Z0])
    hold on
    ms = 5;
    
    %%% adhesivesurface %%%%%%%%%%%%%%%
    if parameters.global.adhesive_surface.use
        %%% molecules locations
        [X0,Y0] = find(parameters.global.adhesive_surface.array);
        %%% plot locations
        plot(X0,Y0,'.','MarkerSize',ms,'Color',[1 1 0])
    end
    
    %%% Cells(2)
    for t2 = 1:n_types2
        %%% molecules locations
        [X2,Y2] = find(simulation_data.Cells(2).LOC == t2);
        %%% color
        color2  = parameters.Cells(2).molecule_type(t2).color;
        %%% plot locations
        plot(X2,Y2,'.','MarkerSize',ms,'Color',color2)
    end
    
    %%% Cells(1)
    for t1 = 1:n_types1
        %%% molecules locations
        [X1,Y1] = find(simulation_data.Cells(1).LOC == t1);
        %%% color
        color1    = parameters.Cells(1).molecule_type(t1).color;
        %%% plot locations
        plot(X1,Y1,'.','MarkerSize',ms,'Color',color1)
    end
    %%% PLL %%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(parameters.Cells(2).cellname,'Coverslip'); 
        if parameters.global.PLL.use    
            set(sp2,'Color',parameters.global.PLL.color)
            alpha (0.7)
        end
    end
    hold off
    axis equal
    axis([0 size_x 0 size_y])
    
    title('Molecules locations','FontSize',fs4)
    set(gca,'XTick',0:50:size_x)
    set(gca,'YTick',0:50:size_y)
    set(gca,'XTickLabel',a*[0:50:size_x])
    set(gca,'YTickLabel',a*[0:50:size_y])
    
    xlabel('X (nm)','FontSize',fs3)
    ylabel('Y (nm)','FontSize',fs3)
end

if ~isempty(parameters.batch.values)
    suptitle(['Batch = ',parameters.batch.name,...
              ',   Value = ',num2str(parameters.batch.values(run1)),...
              ', (',num2str(run1),'/',num2str(length(parameters.batch.values)),')',...
              ',   t = ',num2str(t),'/',num2str(sim_time)])
else
    suptitle(['t = ',num2str(t),'/',num2str(sim_time)])
end
drawnow
end




        
    



