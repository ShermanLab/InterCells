function Cell1_data = make_initial_Cell1_data_4x4()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : parameters,
             simulation_data.
output     : ui_parameters.
called by  : interface_simulation.
calling    : 
description:
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global parameters

size_x = parameters.global.array_size_x;
size_y = parameters.global.array_size_y;
a      = parameters.global.pixel_size;

%%% load data %%%%%%%%%%%%%%%%%%%%%%%%%
DD = load('C:\Users\Owner\Documents\MATLAB\Weikl_Lipowsky\small_patches\Interface_simulation5\Results\intial_conditions_test\results_20180429205336.mat');
DDT0 = DD.RUNS_RESULTS{1,1}{1,1};
Cell1_list = DDT0.Cell1.id_linind_type_Z_E_Cell1;

%%% get lininds %%%%%%%%%%%%%%%%%%%%%%%
linindm1_all = Cell1_list(:,2);
typem1_all   = Cell1_list(:,3);

linindm1_1 = linindm1_all(typem1_all == 2);
linindm1_2 = linindm1_all(typem1_all == 3);
linindm1_3 = linindm1_all(typem1_all == 4);

%%% CD45 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd45_radius = 100; % pixels
t = 0:pi/10:2*pi;
polygon_x = 185 + cd45_radius*cos(t);
polygon_y = 230 + cd45_radius*sin(t);

[X0,Y0] = find(ones(size_x,size_y));

logical_in = inpolygon(X0,Y0,polygon_x,polygon_y);

X_in = X0(logical_in);
Y_in = Y0(logical_in);

rand_array = rand(size_x,size_y);
rand_inpolygon = rand_array(logical_in);

N_cd45 = 872;
N_lfa  = 82;
sorted_rand_in = sortrows([X_in,Y_in,rand_inpolygon],3);
%%% getting the X,Y coordinate of these points
points_in_cd45 = sorted_rand_in(1:N_cd45,1:2);
points_in_lfa  = sorted_rand_in(N_cd45+1:N_cd45+N_lfa,1:2);

%%% getting the linind of these points
% linindm1_2 = sub2ind([size_x,size_y],...
%     points_in_lfa(:,1),points_in_lfa(:,2));

linindm1_3 = sub2ind([size_x,size_y],...
    points_in_cd45(:,1),points_in_cd45(:,2));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

locations_array = zeros(size_x,size_y);
locations_array(linindm1_1) = 1;
locations_array(linindm1_2) = 2;
locations_array(linindm1_3) = 3;


Cell1_data = locations_array2Cell_data(locations_array,1);

end






