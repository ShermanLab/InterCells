function pmhc_parameters = defaultPMHCparameters()

%%% setting TCR default parameters
pmhc.name                = 'pMHC';
pmhc.type_number         = 1;
pmhc.color               = [0.5 1 0.5]; % RGB
%%% sizes
pmhc.vertical_size       = 10; %0; % nm
pmhc.lateral_size        = 10; % nm
pmhc.area_patches_5      = 4;  % #
pmhc.area_patches_10     = 1;  % #
%%% potentials
pmhc.potential_width     = 5;  % nm
pmhc.binding_bottom      = pmhc.vertical_size - pmhc.potential_width/2; % nm
pmhc.binding_top         = pmhc.vertical_size + pmhc.potential_width/2; % nm
pmhc.binding_strength    = -10;  % KT
pmhc.spring_k            = 0; % ?
%%% diffusion
pmhc.diffusion_constant  = 0.01; % um^2/sec
%%% clusters
pmhc.global_density      = 300;  % #/um^2
pmhc.cluster_density     = 1000; % #/um^2
pmhc.density_of_clusters = 0.8;  % #/um^2
%%% self clustering
pmhc.self_clustering               = 0;   % Yes/No
pmhc.self_clustering_binding_range = 10;  % nm
pmhc.self_clustering_p_on          = 0.0; % 0-1
pmhc.self_clustering_p_off         = 0.0; % 0-1
%%% force membrane to molecule height
pmhc.force_z = 0; % 0/1
%%% transport 
pmhc.transport.use       = 0;
pmhc.transport.speed     = 0; % nm/sec


pmhc_parameters = pmhc;
end 