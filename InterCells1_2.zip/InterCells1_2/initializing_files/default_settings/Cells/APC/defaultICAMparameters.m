function icam_parameters = defaultICAMparameters()

%%% setting TCR default parameters
icam.name                = 'ICAM';
icam.type_number         = 2;
icam.color               = [0.5 0.5 1]; % RGB
%%% sizes
icam.vertical_size       = 10; % nm
icam.lateral_size        = 10; % nm
icam.area_patches_5      = 4;  % #
icam.area_patches_10     = 1;  % #
%%% potentials
icam.potential_width     = 5;  % nm
icam.binding_bottom      = icam.vertical_size - icam.potential_width/2; % nm
icam.binding_top         = icam.vertical_size + icam.potential_width/2; % nm
icam.binding_strength    = -10;  % KT
icam.spring_k            = 0; % ?
%%% diffusion
icam.diffusion_constant  = 0.01; % um^2/sec
%%% clusters
icam.global_density      = 300;  % #/um^2
icam.cluster_density     = 1000; % #/um^2
icam.density_of_clusters = 1;    % #/um^2
%%% self clustering
icam.self_clustering               = 0;   % Yes/No
icam.self_clustering_binding_range = 10;  % nm
icam.self_clustering_p_on          = 0.0; % 0-1
icam.self_clustering_p_off         = 0.0; % 0-1
%%% force membrane to molecule height
icam.force_z = 0; % 0/1
%%% transport 
icam.transport.use       = 0;
icam.transport.speed     = 0; % nm/sec


icam_parameters = icam;
end 