function default_APC_parameters = defaultAPCparameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : default_Tcell_parameters
called by  : ?
calling    : defaultAPCmembraneparameters()
             defaultPMHCparameters()
             defaultICAMparameters()
description: makes a structure of the APC parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% name 
APC.cellname = 'APC';

%%% membrane 
APC.membrane         = defaultAPCmembraneparameters();
%%% molecules 
%%% pmhc
APC.molecule_type(1) = defaultPMHCparameters();
%%% icam 
APC.molecule_type(2) = defaultICAMparameters();

default_APC_parameters = APC;
end















