function default_COVERSLIP_parameters = defaultCOVERSLIPparameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : default_Tcell_parameters
called by  : ?
calling    : defaultTCELLmembraneparameters()
             defaultTCRparameters()
             defaultLFA1parameters()
             defaultCD45parameters()
description: makes a structure of the Coverslip parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% name 
COVERSLIP.cellname     = 'Coverslip';
%%% membrane 
COVERSLIP.membrane     = defaultCOVERSLIPmembraneparameters();
%%% molecules 
% acd3
COVERSLIP.molecule_type(1) = defaultACD3parameters();
% acd11
COVERSLIP.molecule_type(2) = defaultACD11parameters();
% acd45
COVERSLIP.molecule_type(3) = defaultACD45parameters();

default_COVERSLIP_parameters = COVERSLIP;
end















