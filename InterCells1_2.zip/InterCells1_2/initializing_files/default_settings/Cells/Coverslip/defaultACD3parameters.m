function acd3_parameters = defaultACD3parameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : acd3_parameters
called by  : defaultCOVERSLIParameters
calling    : none
description: makes a structure of the aCD3 parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% setting aCD3 default parameters
acd3.name                = 'aCD3';
acd3.type_number         = 1;
acd3.color               = [0.5 0.75 0.5]; % RGB
% sizes
acd3.vertical_size       = 1;  % 10; % nm
acd3.lateral_size        = 10; % nm
acd3.area_patches_5      = 4;  % #
acd3.area_patches_10     = 1;  % #
% potentials
acd3.potential_width     = 5;  % nm
acd3.binding_bottom      = acd3.vertical_size - acd3.potential_width/2; % nm
acd3.binding_top         = acd3.vertical_size + acd3.potential_width/2; % nm
acd3.binding_strength    = -10;  % KT
acd3.spring_k            = 0; % ?
% diffusion
acd3.diffusion_constant  = 0; % um^2/sec
% clusters
acd3.global_density      = 1000; %300;  % #/um^2
acd3.cluster_density     = 1000; % #/um^2
acd3.density_of_clusters = 1;    % #/um^2
% self clustering
acd3.self_clustering               = 0;   % Yes/No
acd3.self_clustering_binding_range = 10;  % nm
acd3.self_clustering_p_on          = 0.0; % 0-1
acd3.self_clustering_p_off         = 0.0; % 0-1
% force membrane to molecule height
acd3.force_z             = 0; % 0/1
%%% transport 
acd3.transport.use       = 0;
acd3.transport.speed     = 0; % nm/sec


acd3_parameters = acd3;
end 