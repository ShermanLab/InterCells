function default_Coverslip_membrane_parameters = defaultCOVERSLIPmembraneparameters()

%rigidity
membrane.rigidity          = 1*10^6; % KBT
membrane.min_rigidity      = 1*10^6; % KBT
membrane.max_rigidity      = 1*10^6; % 100; %250; % KT
membrane.local_rigidity    = 0; 
% diffusivity
membrane.diffusivity       = 1; 
membrane.min_diffusivity   = 0.0; 
membrane.max_diffusivity   = 0; 
membrane.local_diffusivity = 0; 
% Z
membrane.Z0                = 0; % nm
membrane.min_Z             = 0; % nm 
membrane.max_Z             = 0; % nm
membrane.dz                = 0; % nm

default_Coverslip_membrane_parameters = membrane;
end