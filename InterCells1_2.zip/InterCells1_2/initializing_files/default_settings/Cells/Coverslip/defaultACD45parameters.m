function acd45_parameters = defaultACD45parameters()

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : tcr_parameters
called by  : defaultCOVERSLIPparameters
calling    : none
description: makes a structure of the aCD45 parameters
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% setting aCD45 default parameters
acd45.name                = 'aCD45';
acd45.type_number         = 3;
acd45.color               = [1 0.8 0.8]; % RGB
%%% sizes
acd45.vertical_size       = 1;  % 10; % nm
acd45.lateral_size        = 10; % nm
acd45.area_patches_5      = 4;  % #
acd45.area_patches_10     = 1;  % #
%%% potentials
acd45.potential_width     = 5;  % nm
acd45.binding_bottom      = acd45.vertical_size - acd45.potential_width/2; % nm
acd45.binding_top         = acd45.vertical_size + acd45.potential_width/2; % nm
acd45.binding_strength    = -10; % KT
acd45.spring_k            = 0;   % KT/nm
%%% diffusion
acd45.diffusion_constant  = 0; % um^2/sec
%%% clusters
acd45.global_density      = 300;  % #/um^2
acd45.cluster_density     = 1000; % #/um^2
acd45.density_of_clusters = 0.8;  % #/um^2
%%% self clustering
acd45.self_clustering               = 0;   % Yes/No
acd45.self_clustering_binding_range = 10;  % nm
acd45.self_clustering_p_on          = 0.0; % 0-1
acd45.self_clustering_p_off         = 0.0; % 0-1
%%% force membrane to molecule height
acd45.force_z             = 0; % 0/1
%%% transport 
acd45.transport.use       = 0;
acd45.transport.speed     = 0; % nm/sec


acd45_parameters = acd45;
end 