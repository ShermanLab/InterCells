function default_global_parameters = defaultglobalparameters()

% array sizes 
default_global_parameters.array_size_x          = 200; %200;  % pixels
default_global_parameters.array_size_y          = 200; %200;  % pixels
default_global_parameters.pixel_size            = 10;   % nm
% times 
default_global_parameters.iteration_time        = 0.01; % sec
default_global_parameters.simulation_time       = 100;  % sec
default_global_parameters.experiment_frame_time = 2.5;  % sec
default_global_parameters.save_rate             = 100;  % iterations
% dynamics 
default_global_parameters.metropolis_steps      = 2;    % 1; 
default_global_parameters.e_gravity             = -0.5; % KT 
default_global_parameters.use_gravity           = 0;    % 0/1 
default_global_parameters.stick_time            = 100;    % sec
%%% polyLlysene
default_global_parameters.PLL.use               = 1;    % 0/1;
default_global_parameters.PLL.binding_strength  = -4;   % KT;
default_global_parameters.PLL.binding_top       = 0;    % nm
default_global_parameters.PLL.color             = [1 0.5 1]; % RGB
%%% number of runs 
default_global_parameters.runs                  = 1;
%%% adhesive surface
default_global_parameters.adhesive_surface.use    = 1;
default_global_parameters.adhesive_surface.color  = 0.75*[1 1 0];
default_global_parameters.adhesive_surface.binding_strength = -4;
default_global_parameters.adhesive_surface.circles_radius   = 20; %(nm)
default_global_parameters.adhesive_surface.array  = [];
default_global_parameters.adhesive_surface.linind = [];
%%% actin
default_global_parameters.actin.use               = 1;
default_global_parameters.actin.color             = [0 0 0];
default_global_parameters.actin.rigidity_ratio    = 5;

end

