function library = make_library(default_parameters)

%%% doc %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%{
input      : none
output     : library
called by  : start_interface_simulation
calling    : none
description: saves the default parameters of the simulation
%}
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% global
library.global_parameters     = default_parameters.global_parameters;
%%% Cells
library.Tcell_parameters      = default_parameters.Tcell_parameters;
library.Coverslip_parameters  = default_parameters.Coverslip_parameters;
library.APC_parameters        = default_parameters.APC_parameters;
%%% analyses
library.analyses_parameters   = default_parameters.analyses_parameters;

end




