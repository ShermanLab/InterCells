function default_analyses_parameters = defaultANALYSESparameters()

%%% analyses %%%%%%%%%%%%%%%%%%%%%%%%%%
% rings 
analyses.max_R        = 100; % pixels
analyses.rings        = rings2array(analyses.max_R);
analyses.linind_rings = linindrings(analyses.rings);
analyses.smooth_range = 5; % points


default_analyses_parameters = analyses;
end

